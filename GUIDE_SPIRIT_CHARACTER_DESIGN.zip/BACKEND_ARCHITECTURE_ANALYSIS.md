# 东里村AI导览系统 - 本地后台架构分析

## 一、架构总览

```
┌────────────────────────────────────────────┐
│ 前端（React + Zustand + Wouter）           │
│ 负责登录、路线/POI 界面、AI Agent 抽屉      │
└───────────────────────┬────────────────────┘
                        │ RESTful API
                        ↓
┌────────────────────────────────────────────┐
│ 处理层（Express + 中间件）                  │
│ · cors/bodyParser、路由划分                 │
│ · JWT 认证/权限保护                         │
│ · routes/{users, routes, pois, content, stats} │
└───────────────────────┬────────────────────┘
                        ↓
┌────────────────────────────────────────────┐
│ 数据层（SQLite + 文件系统 uploads）         │
│ · users/routes/pois/content_uploads         │
│ · visitor_records、stats                    │
│ · uploads/ 供小精灵/内容上传                 │
└────────────────────────────────────────────┘
```

### 核心原则
- **本地优先**：数据落在 `backend/data`，即使离线也能读写
- **弱网适配**：前端只依赖常规 HTTP 请求，避免复杂 IPC
- **可扩展**：Express routes 模块化，可接入新的服务（如 agent/operator APIs）

## 二、数据模型与访问

### 主表结构（示意）
```sql
CREATE TABLE users (
  id TEXT PRIMARY KEY,
  phone TEXT UNIQUE NOT NULL,
  nickname TEXT,
  password TEXT,
  role TEXT DEFAULT 'visitor',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE routes (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  description TEXT,
  duration INTEGER,
  difficulty TEXT,
  poi_sequence TEXT,
  target_audience TEXT
);

CREATE TABLE pois (
  id TEXT PRIMARY KEY,
  route_id TEXT NOT NULL,
  name TEXT,
  description TEXT,
  latitude REAL,
  longitude REAL,
  duration INTEGER,
  audio_url TEXT,
  offline_navigation TEXT,
  FOREIGN KEY(route_id) REFERENCES routes(id)
);

CREATE TABLE visitor_records (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  poi_id TEXT,
  visit_time DATETIME,
  duration INTEGER,
  action_type TEXT,
  FOREIGN KEY(user_id) REFERENCES users(id)
);

CREATE TABLE content_uploads (
  id TEXT PRIMARY KEY,
  user_id TEXT,
  content_type TEXT,
  file_path TEXT,
  status TEXT DEFAULT 'pending',
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 访问封装
- 所有数据库操作集中在 `backend/models/xxx.js`（或 services）
- `backend/utils/db.js` 负责 `sqlite3` 连接、事务、foreign_keys

## 三、服务层拆分

| 名称 | 职责 | 依赖 |
| --- | --- | --- |
| `authService` | 登录、JWT 生成与校验、权限判断 | `jsonwebtoken`, `bcryptjs`
| `routeService` | 路线+POI 查询、推荐顺序 | `sqlite3`, `apiClient` (缓存)
| `contentService` | 文件上传、审核状态、人工记录 | `multer`, `fs`
| `statsService` | `recordVisit`、热度统计、访问趋势 | `visitor_records`, `content_uploads`

### 中间件
- `middleware/auth.ts`: 校验 `Authorization: Bearer <token>`
- `middleware/error.ts`: 统一处理异常并输出 JSON
- `middleware/validation.ts`: 请求体 schema 验证（可扩展）

## 四、HTTP 接口映射

| 方法 | 路径 | 说明 | 前端调用 |
| --- | --- | --- | --- |
| `POST` | `/api/users/login` | 手机号登录 | `authStore.login` → `apiClient.login`
| `GET` | `/api/routes` | 路线列表 | `RoutesPage`, `SpiritGreeting`
| `GET` | `/api/routes/:routeId` | 路线详情 + POI IDs | `RouteDetailPage`
| `GET` | `/api/pois/:poiId` | POI 详情 | `POIDetailPage`
| `POST` | `/api/stats/record-visit` | 记录打卡/评分 | `RecordVisit` hook + `AIAgentDrawer`
| `POST` | `/api/content/upload` | 内容上传 | `ContentUploader` + `contentRoutes`
| `POST` | `/api/guide/recommend` | 路线推荐 | `AIAgentDrawer`/`useGuideStore`

## 五、数据流与断点

1. 登录：`LoginPage` → `apiClient.login` → token 存入 `localStorage` → `authStore` 设置。断点：`authStore.login` 的 `try/catch`。
2. 路线呈现：`RoutesPage` 发 `GET /api/routes` → `routeService.getRoutes` → 返回 JSON → React 渲染。
3. POI 访问：`POIDetailPage` 调 `recordVisit` + `showSpiritComment` → 后端 `statsService.recordVisit` 写 `visitor_records`。
4. 上传/审核：`apiClient.uploadContent` 传 `FormData` → Express `contentRoutes` 使用 `multer` 存文件 + SQLite 记录。
5. 推荐算法：`recommendationService` 读取 `routes` + `user profile` 判断 `target_audience` → 反馈给 `AIAgentDrawer`。

## 六、非功能性要求
- **弱网/离线**：前端仅依赖 HTTP API + 本地缓存，可配合 Service Workers later。
- **安全**：所有修改接口需授权（JWT + RBAC）。
- **可观测性**：错误中间件记录 stack，`statsService` 采集访问频率。
- **可扩展性**：新服务可通过 `routes/*.ts` 加入 `router.use`。

## 七、部署&运行

前端与后端独立部署：

```bash
# 后端
cd backend
npm install
npm run dev # nodemon + ts-node

# 前端
cd ../src
npm install
npm run dev
```

Express 默认监听 `http://localhost:3000`，与 `src/services/api.ts` 的 `API_BASE_URL` 保持一致。

未来在导游智能化层面，可在 `services/recommendationService.ts`、`services/guideService.ts` 中封装 SiliconFlow、智谱等 API 调用，并将结果写入 SQLite 或缓存，以保持 RESTful 接口的一致性。

### 附录：Agent 角色映射

为了保持“多 Agent”理念，现有服务与 Agent 的职责可做如下映射：

| Agent 角色 | Express 模块 | 说明 |
| --- | --- | --- |
| Agent A（智能导游） | `guideService`, `routeService`, `/api/guide/*` | 负责 POI 讲解、推荐语、录音回放，未来可接语音识别与 AI 回答。 |
| Agent B（知识检索） | `recommendationService`, `routeService` | 使用 `target_audience` 与 `poi_sequence` 算分，适配未来向量/RAG 接口。 |
| Agent C（运营规划） | `contentService`, `statsService` | 覆盖内容上传、审核、访客统计与运营报表。 |
| Agent D（监控协调） | `middleware/error.ts`, `statsService` | 监控异常、日志与关键指标，保持系统稳定。 |

该映射用 REST + 中间件替代原 Rust/ANP 通信，确保架构理念不变但适配当前栈.

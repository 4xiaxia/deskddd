# AI+导游 - 前端实现指南

## 核心组件架构

### 1. AIGuideContext - 导游上下文管理

```typescript
// src/context/AIGuideContext.tsx
interface GuideState {
  guideName: string;           // "小A"
  currentMood: 'warm' | 'excited' | 'thoughtful' | 'caring';
  userProfile: UserProfile;    // 用户偏好
  visitHistory: VisitRecord[]; // 访问历史
  collectedStories: Story[];   // 收集的故事
  currentLocation: POI | null; // 当前位置
}

interface AIGuideContextType {
  state: GuideState;
  greet: () => Promise<string>;           // 问候
  recommend: () => Promise<Recommendation>; // 推荐
  explain: (poi: POI) => Promise<string>; // 讲解
  respond: (query: string) => Promise<string>; // 回应
}
```

### 2. GuideGreeting - 首页问候组件

```typescript
// src/components/GuideGreeting.tsx
export const GuideGreeting: React.FC = () => {
  const [greeting, setGreeting] = useState('');
  const [isAnimating, setIsAnimating] = useState(true);

  useEffect(() => {
    // 生成个性化问候
    const generateGreeting = async () => {
      const response = await apiClient.request('/guide/greeting', {
        method: 'POST',
        body: JSON.stringify({
          timeOfDay: getTimeOfDay(),
          userPreference: getUserPreference(),
        }),
      });
      setGreeting(response.greeting);
    };
    generateGreeting();
  }, []);

  return (
    <div className="greeting-container">
      {/* 导游头像 */}
      <div className="guide-avatar">
        <img src="/guide-avatar.png" alt="小A导游" />
      </div>

      {/* 问候文本 - 逐字显示 */}
      <div className="greeting-text">
        <p className={isAnimating ? 'typing-animation' : ''}>
          {greeting}
        </p>
      </div>

      {/* 选择卡片 */}
      <div className="choice-cards">
        {choices.map((choice) => (
          <ChoiceCard
            key={choice.id}
            icon={choice.icon}
            title={choice.title}
            description={choice.description}
            onClick={() => handleChoice(choice)}
          />
        ))}
      </div>
    </div>
  );
};
```

### 3. GuideRecommendation - 导游推荐组件

```typescript
// src/components/GuideRecommendation.tsx
interface RecommendationProps {
  route: Route;
  userContext: UserContext;
}

export const GuideRecommendation: React.FC<RecommendationProps> = ({
  route,
  userContext,
}) => {
  const [recommendation, setRecommendation] = useState<Recommendation | null>(null);

  useEffect(() => {
    const generateRecommendation = async () => {
      const rec = await apiClient.request('/guide/recommend', {
        method: 'POST',
        body: JSON.stringify({
          route,
          userContext,
        }),
      });
      setRecommendation(rec);
    };
    generateRecommendation();
  }, [route, userContext]);

  return (
    <div className="recommendation-card">
      {/* 路线基本信息 */}
      <div className="route-header">
        <h2>{route.name}</h2>
        <div className="route-meta">
          <span>⏱️ {route.duration}</span>
          <span>📍 {route.poiCount}个景点</span>
          <span>⭐ {route.difficulty}</span>
        </div>
      </div>

      {/* 导游推荐语 */}
      {recommendation && (
        <div className="guide-recommendation">
          <div className="guide-avatar-small">
            <img src="/guide-avatar.png" alt="小A" />
          </div>
          <div className="recommendation-text">
            <p className="guide-label">💬 导游说：</p>
            <p className="recommendation-content">
              {recommendation.text}
            </p>
            {recommendation.tips && (
              <p className="recommendation-tips">
                💡 {recommendation.tips}
              </p>
            )}
          </div>
        </div>
      )}

      {/* 亮点列表 */}
      <div className="highlights">
        <p className="highlights-title">✨ 亮点：</p>
        <ul>
          {route.highlights.map((highlight, idx) => (
            <li key={idx}>• {highlight}</li>
          ))}
        </ul>
      </div>

      {/* 行动按钮 */}
      <button className="action-button">
        👉 开始这段旅程
      </button>
    </div>
  );
};
```

### 4. GuidedPOIDetail - 导游讲解组件

```typescript
// src/components/GuidedPOIDetail.tsx
export const GuidedPOIDetail: React.FC<{ poi: POI }> = ({ poi }) => {
  const [explanation, setExplanation] = useState<Explanation | null>(null);
  const [isPlaying, setIsPlaying] = useState(false);

  useEffect(() => {
  const generateExplanation = async () => {
    // 调用 API 生成讲解
    const exp = await apiClient.request('/api/guide/explain-poi', {
      method: 'POST',
      body: JSON.stringify({
        poi,
        userContext: getUserContext(),
      }),
    });
    setExplanation(exp);
  };
    generateExplanation();
  }, [poi]);

  return (
    <div className="guided-poi-detail">
      {/* 图片轮播 */}
      <ImageCarousel images={poi.images} />

      {/* 基本信息 */}
      <div className="poi-header">
        <h1>{poi.name}</h1>
        <div className="poi-meta">
          <span>📍 {poi.coord}</span>
          <span>⏱️ 建议停留{poi.suggestedDuration}分钟</span>
        </div>
      </div>

      {/* 导游讲解 */}
      {explanation && (
        <div className="guide-explanation">
          <div className="guide-intro">
            <img src="/guide-avatar.png" alt="小A" />
            <span>👤 导游讲解</span>
          </div>

          {/* 音频讲解 */}
          <div className="audio-player">
            <p className="audio-label">
              🎙️ 点击收听导游讲解 ({explanation.duration})
            </p>
            <AudioPlayer
              src={explanation.audioUrl}
              onPlay={() => setIsPlaying(true)}
              onPause={() => setIsPlaying(false)}
            />
            <p className="audio-transcript">
              "{explanation.text}"
            </p>
            <div className="audio-actions">
              <button>❤️ 收藏讲解</button>
              <button>📤 分享给朋友</button>
            </div>
          </div>
        </div>
      )}

      {/* 深度了解 */}
      <div className="deep-dive">
        <h3>📖 深度了解</h3>
        <div className="sections">
          {explanation?.sections.map((section, idx) => (
            <div key={idx} className="section">
              <h4>{section.title}</h4>
              <ul>
                {section.items.map((item, i) => (
                  <li key={i}>• {item}</li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>

      {/* 互动功能 */}
      <div className="interactive-actions">
        <button className="action-btn">
          📸 拍照识别
        </button>
        <button className="action-btn">
          🗺️ 导航到此
        </button>
        <button className="action-btn">
          💬 问导游
        </button>
        <button className="action-btn">
          ➡️ 下一景点
        </button>
      </div>
    </div>
  );
};
```

### 5. AIGuideChat - 导游对话组件

```typescript
// src/components/AIGuideChat.tsx
export const AIGuideChat: React.FC = () => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [input, setInput] = useState('');
  const [isListening, setIsListening] = useState(false);

  const handleSendMessage = async (text: string) => {
    // 添加用户消息
    setMessages(prev => [...prev, {
      type: 'user',
      content: text,
      timestamp: Date.now(),
    }]);

    // 调用 API 生成回应
    const response = await apiClient.request('/api/guide/chat', {
      method: 'POST',
      body: JSON.stringify({
        query: text,
        context: {
          currentLocation: getCurrentLocation(),
          userHistory: getUserHistory(),
          mood: getGuideMood(),
        },
      }),
    });

    // 添加导游回应
    setMessages(prev => [...prev, {
      type: 'guide',
      content: response.text,
      emotion: response.emotion,
      actions: response.actions,
      timestamp: Date.now(),
    }]);
  };

  return (
    <div className="guide-chat">
      {/* 聊天历史 */}
      <div className="chat-history">
        {messages.map((msg, idx) => (
          <ChatMessage
            key={idx}
            type={msg.type}
            content={msg.content}
            emotion={msg.emotion}
            actions={msg.actions}
          />
        ))}
      </div>

      {/* 输入区域 */}
      <div className="chat-input">
        {/* 文字输入 */}
        <input
          type="text"
          placeholder="问导游..."
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyPress={(e) => {
            if (e.key === 'Enter') {
              handleSendMessage(input);
              setInput('');
            }
          }}
        />

        {/* 语音输入 */}
        <button
          className={`voice-btn ${isListening ? 'listening' : ''}`}
          onMouseDown={() => startVoiceInput()}
          onMouseUp={() => stopVoiceInput()}
        >
          🎙️
        </button>

        {/* 发送按钮 */}
        <button onClick={() => {
          handleSendMessage(input);
          setInput('');
        }}>
          发送
        </button>
      </div>
    </div>
  );
};
```

### 6. VisitProgress - 游览进度组件

```typescript
// src/components/VisitProgress.tsx
export const VisitProgress: React.FC = () => {
  const { visitedPOIs, currentPOI, totalPOIs } = useRouteStore();
  const { guideMessage } = useGuideStore();

  return (
    <div className="visit-progress">
      <h3>📍 你的旅程</h3>

      {/* 进度列表 */}
      <div className="progress-list">
        {totalPOIs.map((poi, idx) => {
          const isVisited = visitedPOIs.includes(poi.id);
          const isCurrent = currentPOI?.id === poi.id;

          return (
            <div
              key={poi.id}
              className={`progress-item ${
                isVisited ? 'visited' : isCurrent ? 'current' : 'upcoming'
              }`}
            >
              {/* 状态指示 */}
              <div className="status-icon">
                {isVisited && '✅'}
                {isCurrent && '🔄'}
                {!isVisited && !isCurrent && '⏳'}
              </div>

              {/* 景点信息 */}
              <div className="poi-info">
                <h4>{poi.name}</h4>
                {isVisited && (
                  <p>⏱️ 已停留 {getVisitDuration(poi.id)} 分钟</p>
                )}
              </div>

              {/* 导游评价 */}
              {isVisited && (
                <div className="guide-comment">
                  <p>💬 小A: "{getGuideComment(poi.id)}"</p>
                </div>
              )}

              {/* 用户评分 */}
              {isVisited && (
                <div className="user-rating">
                  <StarRating rating={getUserRating(poi.id)} />
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* 收获统计 */}
      <div className="achievements">
        <h4>📊 你的收获：</h4>
        <div className="stats">
          <div className="stat">
            <span>📖 故事数</span>
            <span className="value">{getStoryCount()}</span>
          </div>
          <div className="stat">
            <span>📸 照片数</span>
            <span className="value">{getPhotoCount()}</span>
          </div>
          <div className="stat">
            <span>⭐ 平均评分</span>
            <span className="value">{getAverageRating()}</span>
          </div>
          <div className="stat">
            <span>🎁 纪念卡</span>
            <span className="value">{getMemorialCardCount()}</span>
          </div>
        </div>
      </div>

      {/* 导游鼓励 */}
      <div className="guide-encouragement">
        <p>💬 小A: "{guideMessage}"</p>
      </div>
    </div>
  );
};
```

## 样式指南

### 颜色方案
```css
/* 导游相关 */
--guide-primary: #00686bda;    /* 深青色 */
--guide-accent: #d95c0fff;     /* 橙红色 */
--guide-warm:rgb(255, 187, 132);       /* 浅橙色 */
--guide-light: #EFF4F0;      /* 浅灰绿 */

/* 情感表达 */
--emotion-warm: #FFB6C1;     /* 温暖粉 */
--emotion-excited: #FFD700;  /* 兴奋金 */
--emotion-thoughtful: #8df4ffff; /* 思考蓝 */
--emotion-caring: #FF69B4;   /* 关怀红 */
```

### 动画效果
```css
/* 打字动画 */
@keyframes typing {
  from { width: 0; }
  to { width: 100%; }
}

/* 导游出现 */
@keyframes guideAppear {
  from {
    opacity: 0;
    transform: translateY(20px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

/* 脉冲动画（表示思考） */
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}
```

## 集成建议

### 与 Zustand Store 集成
```typescript
// src/store/guideStore.ts
export const useGuideStore = create<GuideStore>((set) => ({
  guideName: '小A',
  currentMood: 'warm',
  messages: [],
  
  addMessage: (message: Message) =>
    set((state) => ({
      messages: [...state.messages, message],
    })),
  
  updateMood: (mood: Emotion) =>
    set({ currentMood: mood }),
  
  generateGreeting: async () => {
    try {
      const response = await fetch('/api/guide/greeting');
      const { greeting } = await response.json();
      set((state) => ({
        messages: [...state.messages, {
          type: 'guide',
          content: greeting,
        }],
      }));
    } catch (error) {
      console.error('获取问候语失败:', error);
    }
  },
  
  generateRecommendation: async (route: Route) => {
    try {
      const response = await fetch('/api/guide/recommend', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ route }),
      });
      const { recommendation } = await response.json();
      set((state) => ({
        messages: [...state.messages, {
          type: 'guide',
          content: recommendation,
        }],
      }));
    } catch (error) {
      console.error('获取推荐失败:', error);
    }
  },
}));

### 后端 API 实现
```typescript
// backend/routes/guide.js
import express from 'express';
import { GuideAgent } from '../agents/GuideAgent.js';

const router = express.Router();
const guideAgent = new GuideAgent();

// 获取问候语
router.get('/greeting', async (req, res) => {
  try {
    const greeting = await guideAgent.generateGreeting();
    res.json({ greeting });
  } catch (error) {
    console.error('生成问候语失败:', error);
    res.status(500).json({ error: '生成问候语失败' });
  }
});

// 获取路线推荐
router.post('/recommend', async (req, res) => {
  try {
    const { route } = req.body;
    const recommendation = await guideAgent.generateRecommendation(route);
    res.json({ recommendation });
  } catch (error) {
    console.error('生成推荐失败:', error);
    res.status(500).json({ error: '生成推荐失败' });
  }
});

export default router;
}
```

## 用户体验流程

```
1. 首页加载
   ↓
2. 导游问候 (GuideGreeting)
   ↓
3. 用户选择路线
   ↓
4. 导游推荐 (GuideRecommendation)
   ↓
5. 用户开始旅程
   ↓
6. 景点讲解 (GuidedPOIDetail)
   ↓
7. 用户提问 (AIGuideChat)
   ↓
8. 进度跟踪 (VisitProgress)
   ↓
9. 纪念册生成
   ↓
10. 温暖告别
```

这样的设计让用户感受到的是一位真实、温暖、专业的导游，而不是一个冷冰冰的应用！

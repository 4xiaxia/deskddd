# 前后端匹配分析与修复方案
## 📋 项目匹配度分析

基于对项目代码的深度遍历，我发现了**前后端不匹配**的关键问题，需要立即修复。

---

## 🚨 发现的问题

### 1. 路由映射不完整

#### 📍 当前前端路由
```typescript
// src/App.tsx
<Route path="/login" component={LoginPage} />
<Route path="/routes" component={RoutesPage} />
<Route path="/route/:routeId" component={RouteDetailPage} />
<Route path="/route/:routeId/poi/:poiId" component={POIDetailPage} />
```

#### 📍 当前后端路由
```javascript
// backend/routes/
- userRoutes.js     ✅ 存在，匹配 /login
- routeRoutes.js    ✅ 存在，匹配 /routes 和 /route/:routeId  
- poiRoutes.js     ✅ 存在，匹配 /route/:routeId/poi/:poiId
- contentRoutes.js  ✅ 存在，前端未使用
- statsRoutes.js   ✅ 存在，前端未使用
- guideRoutes.js   ✅ 存在，前端未使用
```

### 2. 前端页面缺失功能

#### ❌ RoutesPage 功能不完整
**当前代码**:
```typescript
// src/pages/RoutesPage.tsx
const { routes, fetchRoutes, isLoading } = useRouteStore();
const handleSelectRoute = (routeId: string) => {
  const route = routes.find((r) => r.id === routeId);
  if (route) {
    setCurrentRoute(route);
    setLocation(`/route/${routeId}`);
  }
};
```

**缺失功能**:
- ❌ 路线筛选功能（按类型、难度、时长）
- ❌ 搜索功能
- ❌ 路线收藏功能
- ❌ 路线预览（时长、距离、景点预览）

#### ❌ RouteDetailPage 功能不完整
**当前代码**: 只有基础路由跳转

**缺失功能**:
- ❌ 路线详细信息展示
- ❌ 景点列表和导航
- ❌ 路线开始/暂停功能
- ❌ 路线定制功能

#### ❌ POIDetailPage 功能不完整
**当前代码**: 只有基础路由接收

**缺失功能**:
- ❌ 整个POIDetailPage组件不存在
- ❌ 景点详细信息展示
- ❌ 景点图片轮播
- ❌ 音频讲解播放
- ❌ 拍照识别功能

### 3. 后端功能未使用

#### ❌ guideRoutes.js - 前端完全未调用
```javascript
// backend/routes/guideRoutes.js
router.post('/greeting', async (req, res) => { // AI问候
router.post('/recommend', async (req, res) => { // AI推荐  
// 前端完全没有调用这些API
```

#### ❌ statsRoutes.js - 前端完全未调用
```javascript
// backend/routes/statsRoutes.js
router.post('/record-visit', async (req, res) => { // 访问记录
router.get('/visit-stats', async (req, res) => { // 访问统计
// 前端完全没有使用这些功能
```

---

## 🚀 核心需求理解

### 🎯 根本需求分析
基于文档分析，东里村AI导览系统的**核心需求**是：

1. **AI导游小精灵** - 智能讲解和对话
2. **路线导览** - 红色文化+生态民俗主题路线  
3. **景点深度介绍** - 图片、文字、音频多媒体展示
4. **位置智能服务** - 导航、等时圈、距离计算
5. **游览体验优化** - 进度跟踪、个性化推荐

### 🔧 技术要求
- **剃刀思维**: 只做核心功能，移除冗余
- **一次性开发**: 统一架构，避免重复工作
- **移动端优先**: 所有界面触屏优化
- **ANP调用**: 利用现成MCP工具，不重复造轮子

---

## 🛠️ 修复方案

### 第一阶段：补全缺失页面（1周）

#### 1. 创建完整的POIDetailPage
```typescript
// src/pages/POIDetailPage.tsx
import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useRouteStore } from '../store/routeStore';
import { apiClient } from '../services/api';

interface POIDetailPageProps {
  routeId: string;
  poiId: string;
}

export const POIDetailPage: React.FC<POIDetailPageProps> = ({ routeId, poiId }) => {
  const [poi, setPoi] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const { fetchPOIDetail } = useRouteStore();

  useEffect(() => {
    fetchPOIDetail(poiId);
  }, [poiId, fetchPOIDetail]);

  const handleNextImage = () => {
    if (poi?.images && currentImageIndex < poi.images.length - 1) {
      setCurrentImageIndex(currentImageIndex + 1);
    }
  };

  const handlePrevImage = () => {
    if (currentImageIndex > 0) {
      setCurrentImageIndex(currentImageIndex - 1);
    }
  };

  const toggleAudioPlay = () => {
    setIsPlaying(!isPlaying);
  };

  const handleNavigation = () => {
    // 调用导航功能
    window.open(`https://maps.google.com/maps?q=${poi?.latitude},${poi?.longitude}`);
  };

  const handlePhotoCapture = () => {
    // 拍照识别功能
    alert('拍照识别功能开发中...');
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
      </div>
    );
  }

  return (
    <div className="app-shell min-h-screen">
      {/* 景点图片轮播 */}
      <div className="relative h-64 bg-gray-200">
        {poi?.images && poi.images.length > 0 ? (
          <>
            <img 
              src={poi.images[currentImageIndex]} 
              alt={poi.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute bottom-4 left-0 right-0 flex justify-center gap-2">
              <button 
                onClick={handlePrevImage}
                className="bg-black bg-opacity-50 text-white px-3 py-1 rounded-full"
              >
                ←
              </button>
              <button 
                onClick={handleNextImage}
                className="bg-black bg-opacity-50 text-white px-3 py-1 rounded-full"
              >
                →
              </button>
            </div>
          </>
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-300">
            <span className="text-gray-500">暂无图片</span>
          </div>
        )}
      </div>

      {/* 景点信息 */}
      <div className="p-6">
        <div className="mb-4">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">{poi?.name}</h1>
          <div className="flex items-center gap-4 text-sm text-gray-600">
            <span>📍 {poi?.latitude}, {poi?.longitude}</span>
            <span>⏱️ 建议停留{poi?.duration || 30}分钟</span>
          </div>
        </div>

        <div className="mb-6">
          <p className="text-gray-700 leading-relaxed">{poi?.description}</p>
        </div>

        {/* 音频播放器 */}
        {poi?.audioUrl && (
          <div className="bg-gray-50 rounded-lg p-4 mb-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <span className="text-sm text-gray-600">🎙️ 景点讲解</span>
                <span className="text-xs text-gray-500">时长: {poi?.audioDuration || '2分钟'}</span>
              </div>
              <button
                onClick={toggleAudioPlay}
                className="bg-brand-primary text-white px-4 py-2 rounded-lg"
              >
                {isPlaying ? '暂停' : '播放'}
              </button>
            </div>
          </div>
        )}

        {/* 互动功能 */}
        <div className="flex gap-4">
          <button 
            onClick={handleNavigation}
            className="flex-1 bg-brand-secondary text-white py-3 rounded-lg"
          >
            🗺️ 导航到此
          </button>
          <button 
            onClick={handlePhotoCapture}
            className="flex-1 bg-brand-accent text-white py-3 rounded-lg"
          >
            📸 拍照识别
          </button>
        </div>
      </div>
    </div>
  );
};
```

#### 2. 增强RouteDetailPage
```typescript
// src/pages/RouteDetailPage.tsx
import React, { useEffect, useState } from 'react';
import { useParams, useLocation } from 'wouter';
import { useRouteStore } from '../store/routeStore';
import { useAuthStore } from '../store/authStore';
import { POIDetailPage } from './POIDetailPage';

export const RouteDetailPage: React.FC = () => {
  const { routeId } = useParams();
  const { currentRoute, fetchRouteDetail, pois, fetchPOIsByRoute } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();
  const [selectedPoiId, setSelectedPoiId] = useState<string | null>(null);

  useEffect(() => {
    if (routeId) {
      fetchRouteDetail(routeId);
      fetchPOIsByRoute(routeId);
    }
  }, [routeId, fetchRouteDetail, fetchPOIsByRoute]);

  const handlePOISelect = (poiId: string) => {
    setSelectedPoiId(poiId);
    setLocation(`/route/${routeId}/poi/${poiId}`);
  };

  const handleStartTour = async () => {
    try {
      // 调用后端路线开始API
      await apiClient.request(`/routes/${routeId}/start`, {
        method: 'POST',
        body: JSON.stringify({
          userId: user?.id,
          startTime: new Date().toISOString()
        })
      });
      
      alert('导览开始！祝您游览愉快！');
    } catch (error) {
      console.error('开始导览失败:', error);
      alert('开始导览失败，请重试');
    }
  };

  if (!currentRoute) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
      </div>
    );
  }

  return (
    <div className="app-shell min-h-screen">
      {/* 路线头部信息 */}
      <div className="bg-gradient-to-r from-brand-primary to-brand-secondary text-white p-6">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold mb-2">{currentRoute.name}</h1>
          <p className="text-white text-opacity-90 mb-4">{currentRoute.description}</p>
          
          <div className="flex gap-6 text-sm">
            <span>⏱️ 预计时长: {currentRoute.duration}分钟</span>
            <span>📍 总距离: {currentRoute.distance}km</span>
            <span>🎯 景点数量: {currentRoute.poiCount}个</span>
            <span>⭐ 难度: {
              currentRoute.difficulty === 'easy' ? '简单' :
              currentRoute.difficulty === 'medium' ? '中等' : '困难'
            }</span>
          </div>
          
          <button
            onClick={handleStartTour}
            className="bg-white text-brand-primary px-6 py-3 rounded-lg font-semibold"
          >
            🚶 开始导览
          </button>
        </div>
      </div>

      {/* 景点列表 */}
      <div className="p-6">
        <h2 className="text-xl font-bold mb-4">景点列表</h2>
        <div className="space-y-4">
          {pois.map((poi, index) => (
            <div
              key={poi.id}
              onClick={() => handlePOISelect(poi.id)}
              className="bg-white rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow cursor-pointer"
            >
              <div className="flex items-center gap-4">
                <div className="flex-shrink-0 w-8 h-8 bg-brand-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                  {index + 1}
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900">{poi.name}</h3>
                  <p className="text-sm text-gray-600 line-clamp-2">{poi.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* 显示选中的景点详情 */}
      {selectedPoiId && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-xl max-w-2xl w-full max-h-screen overflow-y-auto">
            <div className="flex justify-between items-center p-4 border-b border-gray-200">
              <h2 className="text-xl font-bold">景点详情</h2>
              <button 
                onClick={() => setSelectedPoiId(null)}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>
            <div className="p-4">
              <POIDetailPage routeId={routeId} poiId={selectedPoiId} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
```

#### 3. 增强RoutesPage
```typescript
// src/pages/RoutesPage.tsx
import React, { useEffect, useState } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useAuthStore } from '../store/authStore';
import { useLocation } from 'wouter';

export const RoutesPage: React.FC = () => {
  const { routes, fetchRoutes, isLoading, setCurrentRoute } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();
  
  // 新增状态管理
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedDifficulty, setSelectedDifficulty] = useState('all');
  const [selectedType, setSelectedType] = useState('all');

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    fetchRoutes();
  }, [user, setLocation, fetchRoutes]);

  // 过滤路由
  const filteredRoutes = routes.filter(route => {
    const matchesSearch = route.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         route.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesDifficulty = selectedDifficulty === 'all' || route.difficulty === selectedDifficulty;
    const matchesType = selectedType === 'all' || route.type === selectedType;
    
    return matchesSearch && matchesDifficulty && matchesType;
  });

  const handleSelectRoute = (routeId: string) => {
    const route = routes.find((r) => r.id === routeId);
    if (route) {
      setCurrentRoute(route);
      setLocation(`/route/${routeId}`);
    }
  };

  const toggleFavorite = (routeId: string) => {
    // 收藏功能实现
    const favorites = JSON.parse(localStorage.getItem('favoriteRoutes') || '[]');
    const newFavorites = favorites.includes(routeId) 
      ? favorites.filter(id => id !== routeId)
      : [...favorites, routeId];
    localStorage.setItem('favoriteRoutes', JSON.stringify(newFavorites));
  };

  const isFavorite = (routeId: string) => {
    const favorites = JSON.parse(localStorage.getItem('favoriteRoutes') || '[]');
    return favorites.includes(routeId);
  };

  return (
    <div className="app-shell min-h-screen pb-20">
      {/* 搜索和筛选栏 */}
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-2xl font-bold text-brand-primary mb-4">选择路线</h1>
          <p className="text-sm text-gray-600">欢迎，{user?.phone}</p>
          
          <div className="flex flex-col sm:flex-row gap-4 mb-4">
            <input
              type="text"
              placeholder="搜索路线..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
            />
            
            <select
              value={selectedDifficulty}
              onChange={(e) => setSelectedDifficulty(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
            >
              <option value="all">全部难度</option>
              <option value="easy">简单</option>
              <option value="medium">中等</option>
              <option value="hard">困难</option>
            </select>
            
            <select
              value={selectedType}
              onChange={(e) => setSelectedType(e.target.value)}
              className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
            >
              <option value="all">全部类型</option>
              <option value="red_culture">红色文化</option>
              <option value="eco_culture">生态民俗</option>
            </select>
          </div>
        </div>
      </div>

      {/* 路线网格 */}
      <div className="p-4">
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
          </div>
        ) : filteredRoutes.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400">
              <div className="text-6xl mb-4">🔍</div>
              <p className="text-lg font-medium mb-2">未找到匹配的路线</p>
              <p className="text-sm">尝试调整搜索条件或筛选器</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRoutes.map((route) => (
              <div
                key={route.id}
                onClick={() => handleSelectRoute(route.id)}
                className="bg-white rounded-xl shadow-md hover:shadow-xl transition-shadow cursor-pointer overflow-hidden group"
              >
                {/* 路线图片 */}
                <div className="h-40 bg-gradient-to-br from-brand-primary/10 to-brand-secondary/10 flex items-center justify-center">
                  <div className="text-4xl text-brand-primary">🗺️</div>
                </div>
                
                {/* 路线信息 */}
                <div className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="text-lg font-semibold text-gray-900 group-hover:text-brand-primary transition-colors">
                      {route.name}
                    </h3>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleFavorite(route.id);
                      }}
                      className="text-2xl hover:scale-110 transition-transform"
                    >
                      {isFavorite(route.id) ? '❤️' : '🤍'}
                    </button>
                  </div>
                  
                  <div className="flex items-center gap-2 mb-2">
                    <span className="px-2 py-1 bg-brand-accent bg-opacity-20 text-brand-secondary text-xs rounded-full">
                      {route.difficulty === 'easy' ? '简单' : route.difficulty === 'medium' ? '中等' : '困难'}
                    </span>
                    <span className="px-2 py-1 bg-blue-100 text-blue-800 text-xs rounded-full">
                      {route.type === 'red_culture' ? '红色文化' : '生态民俗'}
                    </span>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-4 line-clamp-3">
                    {route.description}
                  </p>
                  
                  <div className="flex gap-4 text-xs text-gray-500">
                    <span>⏱️ {route.duration}分钟</span>
                    <span>📍 {route.distance}km</span>
                    <span>🎯 {route.poiCount}个景点</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
```

### 第二阶段：集成AI导游功能（1周）

#### 更新AIAgentDrawer以调用后端API
```typescript
// src/components/AIAgentDrawer.tsx
import React, { useState, useRef, useEffect } from 'react';
import { useAgentStore } from '../store/agentStore';
import { apiClient } from '../services/api';

export const AIAgentDrawer: React.FC = () => {
  const {
    isOpen,
    toggleAgent,
    conversations,
    currentConversationId,
    addMessage,
    setIsLoading,
    isLoading
  } = useAgentStore();
  
  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversations, currentConversationId]);

  const currentConversation = currentConversationId
    ? conversations.get(currentConversationId)
    : null;

  // 新增：调用AI导游API
  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !currentConversationId || isLoading) return;

    const userMessage = {
      id: `msg_${Date.now()}`,
      role: 'user' as const,
      content: input,
      timestamp: new Date().toISOString(),
    };

    addMessage(currentConversationId, userMessage);
    setInput('');
    setIsLoading(true);

    try {
      // 调用后端AI导游API
      const response = await apiClient.request('/guide/chat', {
        method: 'POST',
        body: JSON.stringify({
          message: input,
          conversationId: currentConversationId,
        }),
      });

      const aiMessage = {
        id: `msg_${Date.now() + 1}`,
        role: 'assistant' as const,
        content: response.response,
        timestamp: new Date().toISOString(),
        emotion: response.emotion || 'warm',
      };

      addMessage(currentConversationId, aiMessage);
    } catch (error) {
      console.error('AI导游回复失败:', error);
      
      const errorMessage = {
        id: `msg_${Date.now() + 1}`,
        role: 'assistant' as const,
        content: '抱歉，我暂时无法回答您的问题，请稍后再试。',
        timestamp: new Date().toISOString(),
        emotion: 'apologetic',
      };

      addMessage(currentConversationId, errorMessage);
    } finally {
      setIsLoading(false);
    }
  };

  // 新增：获取个性化问候
  const fetchGreeting = async () => {
    try {
      const response = await apiClient.request('/guide/greeting', {
        method: 'POST',
        body: JSON.stringify({
          userId: currentConversation?.userId,
        timeOfDay: new Date().getHours() < 12 ? 'morning' : 
                   new Date().getHours() < 18 ? 'afternoon' : 'evening',
        }),
      });

      // 显示问候语
      const greetingMessage = {
        id: `msg_${Date.now()}`,
        role: 'assistant' as const,
        content: response.greeting,
        timestamp: new Date().toISOString(),
        emotion: 'warm',
      };

      if (currentConversationId) {
        addMessage(currentConversationId, greetingMessage);
      }
    } catch (error) {
      console.error('获取问候语失败:', error);
    }
  };

  useEffect(() => {
    if (isOpen && currentConversationId && conversations.get(currentConversationId)?.messages.length === 0) {
      fetchGreeting();
    }
  }, [isOpen, currentConversationId]);

  return (
    <>
      {/* 浮动按钮 */}
      <button
        onClick={toggleAgent}
        className="fixed bottom-6 right-6 w-14 h-14 bg-brand-primary text-white rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all floating-agent-shadow z-40 flex items-center justify-center text-2xl"
        title="AI导游助手"
      >
        🤖
      </button>

      {/* 对话抽屉 */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex flex-col">
          {/* 背景遮罩 */}
          <div
            className="absolute inset-0 bg-black bg-opacity-30"
            onClick={toggleAgent}
          />

          {/* 抽屉内容 */}
          <div className="absolute bottom-0 right-0 w-full sm:w-96 h-3/4 bg-white rounded-t-2xl shadow-2xl flex flex-col">
            {/* 头部 */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-brand-primary rounded-full flex items-center justify-center text-white">
                  🤖
                </div>
                <div>
                  <h2 className="text-lg font-semibold text-gray-900">AI导游小A</h2>
                  <p className="text-sm text-gray-600">有什么可以帮助您的吗？</p>
                </div>
              </div>
              <button
                onClick={toggleAgent}
                className="text-gray-400 hover:text-gray-600"
              >
                ✕
              </button>
            </div>

            {/* 消息区域 */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {currentConversation?.messages.map((message) => (
                <div
                  key={message.id}
                  className={`flex ${
                    message.role === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  <div
                    className={`max-w-xs px-3 py-2 rounded-lg ${
                      message.role === 'user'
                        ? 'bg-brand-primary text-white rounded-br-none'
                        : 'bg-gray-100 text-gray-900 rounded-bl-none'
                    }`}
                  >
                    <p className="text-sm">{message.content}</p>
                    <p
                      className={`text-xs mt-1 ${
                        message.role === 'user'
                          ? 'text-brand-accent'
                          : 'text-gray-500'
                      }`}
                    >
                      {new Date(message.timestamp).toLocaleTimeString('zh-CN', {
                        hour: '2-digit',
                        minute: '2-digit',
                      })}
                    </p>
                  </div>
                </div>
              ))}
              
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 text-gray-900 px-3 py-2 rounded-lg rounded-bl-none">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100"></div>
                      <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* 输入区域 */}
            <form
              onSubmit={handleSendMessage}
              className="border-t border-gray-200 p-4 flex gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="输入您的问题..."
                disabled={isLoading}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent text-sm"
              />
              <button
                type="submit"
                disabled={!input.trim() || isLoading}
                className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-opacity-90 disabled:opacity-50 transition-colors text-sm font-medium"
              >
                {isLoading ? (
                  <div className="flex items-center gap-1">
                    <div className="w-4 h-4 border-2 border-current border-t-transparent border-l-transparent border-r-transparent border-b-brand-primary rounded-full animate-spin"></div>
                  </div>
                ) : (
                  '发送'
                )}
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
};
```

### 第三阶段：集成统计和访问记录（0.5周）

#### 在相关页面中添加访问记录
```typescript
// src/services/visitService.ts
import { apiClient } from './api';

export class VisitService {
  // 记录景点访问
  static async recordPOIVisit(poiId: string, userId?: string) {
    try {
      await apiClient.request('/stats/record-visit', {
        method: 'POST',
        body: JSON.stringify({
          poiId,
          userId,
          timestamp: new Date().toISOString(),
          actionType: 'view',
        }),
      });
    } catch (error) {
      console.error('记录景点访问失败:', error);
    }
  }

  // 记录路线开始
  static async recordRouteStart(routeId: string, userId?: string) {
    try {
      await apiClient.request('/stats/record-route-start', {
        method: 'POST',
        body: JSON.stringify({
          routeId,
          userId,
          timestamp: new Date().toISOString(),
        }),
      });
    } catch (error) {
      console.error('记录路线开始失败:', error);
    }
  }

  // 获取访问统计
  static async getVisitStats(timeRange?: string) {
    try {
      return await apiClient.request(`/stats/visit-stats${timeRange ? `?timeRange=${timeRange}` : ''}`);
    } catch (error) {
      console.error('获取访问统计失败:', error);
      return null;
    }
  }
}
```

#### 在POIDetailPage中集成访问记录
```typescript
// 在POIDetailPage中添加
import { VisitService } from '../services/visitService';

useEffect(() => {
  if (poi?.id) {
    // 记录景点访问
    VisitService.recordPOIVisit(poi.id, user?.id);
  }
}, [poi?.id, user?.id]);
```

---

## 🎯 修复完成后的功能映射

### ✅ 完整的前后端API映射

| 前端页面 | 后端API | 状态 | 修复方案 |
|----------|----------|------|----------|
| LoginPage | `/api/users/login` | ✅ 已匹配 | 无需修改 |
| RoutesPage | `/api/routes` | ✅ 已匹配 | 增强筛选搜索功能 |
| RouteDetailPage | `/api/routes/:routeId` | ✅ 已匹配 | 增强路线详情和开始功能 |
| POIDetailPage | `/api/pois/:poiId` | ✅ 已匹配 | 创建完整组件 |
| AIAgentDrawer | `/api/guide/*` | ❌ 前端未调用 | 集成AI导游API |
| 统计功能 | `/api/stats/*` | ❌ 前端未调用 | 集成访问记录API |

### ✅ 未使用的后端功能
- `guideRoutes.js` - AI导游问候和推荐
- `statsRoutes.js` - 访问记录和统计
- `contentRoutes.js` - 内容上传（预留）

---

## 🚀 实施计划

### 第一周：补全核心页面
1. ✅ 创建完整的POIDetailPage组件
2. ✅ 增强RouteDetailPage功能
3. ✅ 增强RoutesPage搜索筛选
4. ✅ 测试页面导航和数据显示

### 第二周：集成AI导游功能
1. ✅ 更新AIAgentDrawer调用后端API
2. ✅ 实现个性化问候功能
3. ✅ 集成AI对话和推荐
4. ✅ 测试AI导游交互

### 第三周：集成访问统计
1. ✅ 创建访问记录服务
2. ✅ 在页面中集成访问统计
3. ✅ 实现统计数据展示
4. ✅ 测试数据收集功能

### 第四周：优化和测试
1. ✅ 性能优化和错误处理
2. ✅ 移动端适配测试
3. ✅ 端到端功能测试
4. ✅ 用户体验优化

---

## 📱 移动端优化

### 响应式设计
- 所有组件采用TailwindCSS响应式类
- 移动端优先的布局设计
- 触摸友好的交互元素

### 性能优化
- 图片懒加载和压缩
- API请求防抖和缓存
- 组件级别的React.memo优化

---

## 🎯 预期成果

### 功能完整性
- ✅ 100% 前后端API匹配
- ✅ 完整的景点导览功能
- ✅ 智能AI导游对话系统
- ✅ 完善的访问统计分析

### 用户体验
- ✅ 流畅的页面导航
- ✅ 智能的搜索和筛选
- ✅ 丰富的多媒体展示
- ✅ 个性化的AI交互

### 技术质量
- ✅ 统一的错误处理
- ✅ 完善的加载状态
- ✅ 移动端优化适配
- ✅ 代码结构清晰维护

---

**通过这个修复方案，我们将彻底解决前后端不匹配的问题，实现一个功能完整、用户体验优秀的东里村AI导览系统。**

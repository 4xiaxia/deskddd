# 最小化旅游路线基础填充方案
## 🎯 核心原则

根据您的要求，采用**最小化开发**策略：
- **先数据填充**: 暂不依赖后端管理员更新
- **移除筛选功能**: 用户按制定路线游览，无需复杂筛选
- **剃刀思维**: 最小代码实现最大功能
- **一次性搭建**: 快速完成基础框架

---

## 🗺️ 路线数据基础填充

### 1. 简化的路线数据结构

```typescript
// src/data/dongliRoutes.ts - 最小化数据定义
export const DONGILI_ROUTES = [
  {
    id: "route_red_light",
    name: "红色革命轻量级路线",
    description: "东里村红色文化精华游，适合初次参观",
    duration: 240, // 4小时
    distance: 5.2,
    difficulty: "easy",
    type: "red_culture",
    pois: [
      "poi_donglired_xinhaijinianguan001",
      "poi_donglired_jingyizhuang001", 
      "poi_red_guntou",
      "poi_red_jiqing",
      "poi_red_yangwei",
      "poi_red_wanzhu"
    ]
  },
  {
    id: "route_red_full", 
    name: "红色革命一日游路线",
    description: "深度体验东里村红色历史文化，全面了解革命传统",
    duration: 480, // 8小时
    distance: 12.5,
    difficulty: "medium", 
    type: "red_culture",
    pois: [
      "poi_donglired_xinhaijinianguan001",
      "poi_donglired_jingyizhuang001",
      "poi_red_guntou", 
      "poi_red_jiqing",
      "poi_red_yangwei",
      "poi_red_wanzhu",
      // 额外景点
      "poi_red_extramemorial",
      "poi_red_extradefense",
      "poi_red_extraculture",
      "poi_red_extrahistory",
      "poi_red_extralandscape"
    ]
  },
  {
    id: "route_eco_half",
    name: "生态民俗休闲半日路线", 
    description: "东里村自然生态与民俗文化体验，轻松愉快的半日游",
    duration: 240, // 4小时
    distance: 4.8,
    difficulty: "easy",
    type: "eco_culture",
    pois: [
      "poi_ecology_xianling",
      "poi_ecology_doumo",
      "poi_ecology_shuiku", 
      "poi_ecology_farm",
      "poi_basic_yth"
    ]
  },
  {
    id: "route_eco_full",
    name: "生态民俗文化一日游路线",
    description: "深度体验东里村自然生态与民俗文化，全方位乡村魅力",
    duration: 480, // 8小时
    distance: 8.5,
    difficulty: "medium",
    type: "eco_culture", 
    pois: [
      "poi_ecology_xianling",
      "poi_ecology_doumo",
      "poi_ecology_shuiku",
      "poi_ecology_farm", 
      "poi_basic_yth",
      // 额外景点
      "poi_ecology_tea",
      "poi_ecology_agriculture",
      "poi_ecology_folk",
      "poi_ecology_nature",
      "poi_ecology_village"
    ]
  }
];
```

### 2. 景点数据精确定义

```typescript
// src/data/dongliPOIs.ts - 对应路线的景点数据
export const DONGILI_POIS = {
  // 红色文化景点
  "poi_donglired_xinhaijinianguan001": {
    id: "poi_donglired_xinhaijinianguan001",
    name: "辛亥革命纪念馆",
    description: "展示郑玉指等东里华侨革命先烈事迹，了解辛亥革命在永春的重要影响。纪念馆通过珍贵的历史文物、照片和文献，生动再现了那段波澜壮阔的革命岁月。",
    latitude: 25.234167,
    longitude: 118.204032,
    images: [
      "/images/xinhai_memorial_01.jpg",
      "/images/xinhai_memorial_02.jpg", 
      "/images/xinhai_memorial_03.jpg"
    ],
    audioUrl: "/audio/xinhai_memorial.mp3",
    audioDuration: 180, // 3分钟
    order: 1,
    highlights: ["珍贵历史文物", "革命先烈事迹", "辛亥革命史料"],
    visitTips: ["建议参观时间30-45分钟", "可拍照记录历史"],
    relatedStories: ["郑玉指革命经历", "孙中山旌义状背景", "永春华侨爱国史"]
  },
  
  "poi_donglired_jingyizhuang001": {
    id: "poi_donglired_jingyizhuang001", 
    name: "旌义状石碑",
    description: "1912年孙中山先生亲笔题写的旌义状，表彰郑玉指等永春华侨对辛亥革命的贡献。石碑见证了华侨华人的爱国热情和革命精神，是东里村革命历史的重要标志。",
    latitude: 25.234892,
    longitude: 118.206045,
    images: [
      "/images/jingyi_stele_01.jpg",
      "/images/jingyi_stele_02.jpg"
    ],
    audioUrl: "/audio/jingyi_stele.mp3",
    audioDuration: 120, // 2分钟
    order: 2,
    highlights: ["孙中山亲笔题字", "革命功绩表彰", "华侨爱国见证"],
    visitTips: ["建议仔细阅读碑文", "可听讲解了解背景"],
    relatedStories: ["旌义状获得经过", "郑玉指爱国事迹", "永春华侨革命贡献"]
  },
  
  "poi_red_guntou": {
    id: "poi_red_guntou",
    name: "古炮楼",
    description: "明代抗倭防御工事，体现了东里村悠久的历史传统和村民的防卫智慧。炮楼历经数百年风雨，是研究古代军事防御建筑和地方历史的重要实物资料。",
    latitude: 25.231456,
    longitude: 118.209874,
    images: [
      "/images/gun_tower_01.jpg",
      "/images/gun_tower_02.jpg",
      "/images/gun_tower_03.jpg"
    ],
    audioUrl: "/audio/gun_tower.mp3", 
    audioDuration: 150, // 2.5分钟
    order: 3,
    highlights: ["古代军事防御", "建筑历史文化", "地方传统工艺"],
    visitTips: ["可登上炮楼俯瞰", "注意安全防护措施"],
    relatedStories: ["明代抗倭历史", "东里村防卫体系", "古建筑保护意义"]
  },

  "poi_red_jiqing": {
    id: "poi_red_jiqing",
    name: "集庆廊桥", 
    description: "典型的闽南传统廊桥建筑，集交通、休憩、社交功能于一体，体现了闽南地区独特的建筑艺术和民俗文化。",
    latitude: 25.232486,
    longitude: 118.205823,
    images: [
      "/images/jiqing_bridge_01.jpg",
      "/images/jiqing_bridge_02.jpg"
    ],
    audioUrl: "/audio/jiqing_bridge.mp3",
    audioDuration: 120, // 2分钟
    order: 4,
    highlights: ["闽南建筑艺术", "传统廊桥文化", "村民生活场景"],
    visitTips: ["可在桥上漫步休憩", "感受传统建筑之美"],
    relatedStories: ["廊桥建造历史", "闽南建筑特色", "村民生活变迁"]
  },

  // 生态景点
  "poi_ecology_xianling": {
    id: "poi_ecology_xianling",
    name: "仙灵瀑布",
    description: "高达120米的壮观瀑布，水势汹涌，声震山谷，是东里村最著名的自然景观。瀑布周围绿树成荫，空气清新，是夏季避暑和休闲的理想场所。",
    latitude: 25.230123,
    longitude: 118.199234,
    images: [
      "/images/xianling_waterfall_01.jpg",
      "/images/xianling_waterfall_02.jpg", 
      "/images/xianling_waterfall_03.jpg"
    ],
    audioUrl: "/audio/xianling_waterfall.mp3",
    audioDuration: 180, // 3分钟
    order: 1,
    highlights: ["壮观瀑布景观", "自然生态美景", "清新空气环境"],
    visitTips: ["最佳观赏时间雨后", "可近距离感受水雾", "注意防滑安全"],
    relatedStories: ["瀑布形成传说", "生态环境特点", "周边自然景观"]
  },

  "poi_ecology_doumo": {
    id: "poi_ecology_doumo",
    name: "豆磨古寨",
    description: "明代抗倭军事防御遗址，见证了东里村人民保家卫国的英勇历史。古寨保存完好，是研究明代军事设施和地方历史的重要文化遗产。",
    latitude: 25.237834,
    longitude: 118.211457,
    images: [
      "/images/doumo_fortress_01.jpg", 
      "/images/doumo_fortress_02.jpg",
      "/images/doumo_fortress_03.jpg"
    ],
    audioUrl: "/audio/doumo_fortress.mp3",
    audioDuration: 150, // 2.5分钟
    order: 2,
    highlights: ["明代军事遗址", "抗倭历史见证", "古建筑群保护"],
    visitTips: ["建议提前了解历史背景", "注意文物保护规定", "可拍照但不要触摸"],
    relatedStories: ["古寨建造历史", "明代抗倭策略", "东里村防卫体系"]
  },

  "poi_ecology_shuiku": {
    id: "poi_ecology_shuiku", 
    name: "东里水库",
    description: "东里村主要水源地，为村民提供生活用水和农田灌溉。水库风景秀丽，山水相依，是休闲垂钓和观赏自然风光的好去处。",
    latitude: 25.237483,
    longitude: 118.202896,
    images: [
      "/images/dongli_reservoir_01.jpg",
      "/images/dongli_reservoir_02.jpg"
    ],
    audioUrl: "/audio/dongli_reservoir.mp3",
    audioDuration: 120, // 2分钟
    order: 3,
    highlights: ["重要水源地", "自然生态景观", "水利工程文化"],
    visitTips: ["可沿岸散步观光", "注意水深安全", "春季景色最美"],
    relatedStories: ["水库建设历史", "村民生活变迁", "水利设施作用"]
  },

  "poi_ecology_farm": {
    id: "poi_ecology_farm",
    name: "功能农业基地",
    description: "种植防癌作物和特色农产品的现代农业基地，体现了东里村农业发展新方向。基地集生态农业、科技示范、教育培训于一体。",
    latitude: 25.231567,
    longitude: 118.203124,
    images: [
      "/images/eco_farm_01.jpg",
      "/images/eco_farm_02.jpg"
    ],
    audioUrl: "/audio/eco_farm.mp3", 
    audioDuration: 120, // 2分钟
    order: 4,
    highlights: ["现代农业生产", "生态农业技术", "特色作物种植"],
    visitTips: ["可了解现代农业技术", "体验田园生活", "注意防护措施"],
    relatedStories: ["农业发展历程", "生态种植技术", "村民创业故事"]
  },

  "poi_basic_yth": {
    id: "poi_basic_yth",
    name: "油桐花海",
    description: "春季油桐花开满山，白色花海与青山相映成趣，构成东里村独特的自然景观。油桐不仅是观赏植物，还是当地传统经济作物。",
    latitude: 25.238984,
    longitude: 118.204563,
    images: [
      "/images/tung_flower_sea_01.jpg",
      "/images/tung_flower_sea_02.jpg",
      "/images/tung_flower_sea_03.jpg"
    ],
    audioUrl: "/audio/tung_flower_sea.mp3",
    audioDuration: 120, // 2分钟
    order: 5,
    highlights: ["季节性自然景观", "油桐花海盛景", "乡村田园风光"],
    visitTips: ["最佳观赏时间3-4月", "可拍照留念", "注意交通安排"],
    relatedStories: ["油桐种植历史", "乡村经济作物", "村民生活场景"]
  }
};
```

---

## 🚀 最小化RoutesPage实现

### 移除所有筛选功能，直接展示制定路线

```typescript
// src/pages/RoutesPage.tsx - 最简化版本
import React, { useEffect } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useAuthStore } from '../store/authStore';
import { useLocation } from 'wouter';
import { DONGILI_ROUTES } from '../data/dongliRoutes';

export const RoutesPage: React.FC = () => {
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();
  
  // 移除所有复杂状态，直接使用静态数据
  const handleSelectRoute = (routeId: string) => {
    const selectedRoute = DONGILI_ROUTES.find(route => route.id === routeId);
    if (selectedRoute) {
      // 直接导航到路线详情
      setLocation(`/route/${routeId}`);
    }
  };

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    // 不需要fetchRoutes，直接使用本地数据
  }, [user, setLocation]);

  return (
    <div className="app-shell min-h-screen pb-20">
      {/* 简化的头部 */}
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl font-bold text-brand-primary mb-2">选择游览路线</h1>
          <p className="text-lg text-gray-700">欢迎来到东里村，请选择您感兴趣的游览路线</p>
          <p className="text-sm text-gray-600 mt-1">我们已为您精心安排了最佳游览体验</p>
        </div>
      </div>

      {/* 简化的路线网格 */}
      <div className="p-6">
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 gap-8">
          {DONGILI_ROUTES.map((route) => (
            <div
              key={route.id}
              onClick={() => handleSelectRoute(route.id)}
              className="bg-white rounded-xl shadow-lg hover:shadow-xl hover:scale-105 transition-all duration-300 cursor-pointer overflow-hidden group"
            >
              {/* 路线图片 */}
              <div className="relative h-48 bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 flex items-center justify-center">
                <div className="text-5xl text-brand-primary group-hover:scale-110 transition-transform">
                  {route.type === 'red_culture' ? '🏮' : '🌿'}
                </div>
              </div>
              
              {/* 路线信息 */}
              <div className="p-6">
                <div className="flex items-start justify-between mb-3">
                  <h3 className="text-xl font-bold text-gray-900 group-hover:text-brand-primary transition-colors">
                    {route.name}
                  </h3>
                  <div className="flex items-center gap-2">
                    <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                      route.difficulty === 'easy' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {route.difficulty === 'easy' ? '轻松' : '中等'}
                    </span>
                    <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-medium">
                      {route.type === 'red_culture' ? '红色文化' : '生态民俗'}
                    </span>
                  </div>
                </div>
                
                <p className="text-gray-700 leading-relaxed mb-4">
                  {route.description}
                </p>
                
                <div className="flex flex-col sm:flex-row gap-4 text-sm text-gray-600">
                  <div className="flex items-center gap-1">
                    <span className="text-lg">⏱️</span>
                    <span>{route.duration}分钟</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-lg">📍</span>
                    <span>{route.distance}公里</span>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-lg">🎯</span>
                    <span>{route.pois.length}个景点</span>
                  </div>
                </div>
              </div>
              
              {/* 开始按钮 */}
              <div className="pt-2">
                <button 
                  className="w-full bg-brand-primary text-white py-3 px-4 rounded-lg font-medium hover:bg-brand-primary/90 transition-colors"
                  onClick={() => handleSelectRoute(route.id)}
                >
                  开始游览
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
```

---

## 🚀 最小化数据服务层

### 直接使用本地数据，不依赖API调用

```typescript
// src/services/routeDataService.ts - 最小化数据服务
import { DONGILI_ROUTES, DONGILI_POIS } from '../data/dongliData';

export class RouteDataService {
  // 直接返回路线数据
  static getRoutes() {
    return Promise.resolve(DONGILI_ROUTES);
  }

  // 根据ID获取路线
  static getRouteById(routeId: string) {
    const route = DONGILI_ROUTES.find(r => r.id === routeId);
    if (!route) {
      return Promise.reject(new Error('路线不存在'));
    }
    
    // 获取路线下的景点详情
    const routePOIs = route.pois
      .map(poiId => DONGILI_POIS[poiId])
      .filter(poi => poi); // 过滤掉未定义的
    
    return Promise.resolve({
      ...route,
      pois: routePOIs
    });
  }

  // 根据ID获取景点
  static getPOIById(poiId: string) {
    const poi = DONGILI_POIS[poiId];
    if (!poi) {
      return Promise.reject(new Error('景点不存在'));
    }
    
    return Promise.resolve(poi);
  }

  // 获取路线推荐（简化版本）
  static getRouteRecommendations() {
    // 暂时返回推荐的前3条路线
    return Promise.resolve(DONGILI_ROUTES.slice(0, 3));
  }
}
```

---

## 🚀 简化的Store实现

### 最小化状态管理

```typescript
// src/store/routeStore.ts - 简化版本
import { create } from 'zustand';
import { RouteDataService } from '../services/routeDataService';
import type { Route, POI } from '../types';

interface RouteState {
  routes: Route[];
  currentRoute: Route | null;
  currentPOI: POI | null;
  isLoading: boolean;
  error: string | null;
}

interface RouteActions {
  getRoutes: () => Promise<void>;
  getRouteDetail: (routeId: string) => Promise<void>;
  getPOIDetail: (poiId: string) => Promise<void>;
  setCurrentRoute: (route: Route | null) => void;
  setCurrentPOI: (poi: POI | null) => void;
  clearError: () => void;
}

export const useRouteStore = create<RouteState & RouteActions>((set, get) => ({
  routes: [],
  currentRoute: null,
  currentPOI: null,
  isLoading: false,
  error: null,

  getRoutes: async () => {
    set({ isLoading: true, error: null });
    try {
      const routes = await RouteDataService.getRoutes();
      set({ routes, isLoading: false });
    } catch (error) {
      set({ error: error.message, isLoading: false });
    }
  },

  getRouteDetail: async (routeId: string) => {
    set({ isLoading: true, error: null });
    try {
      const route = await RouteDataService.getRouteById(routeId);
      set({ currentRoute: route, isLoading: false });
    } catch (error) {
      set({ error: error.message, isLoading: false });
    }
  },

  getPOIDetail: async (poiId: string) => {
    set({ isLoading: true, error: null });
    try {
      const poi = await RouteDataService.getPOIById(poiId);
      set({ currentPOI: poi, isLoading: false });
    } catch (error) {
      set({ error: error.message, isLoading: false });
    }
  },

  setCurrentRoute: (route) => set({ currentRoute: route }),
  setCurrentPOI: (poi) => set({ currentPOI: poi }),
  clearError: () => set({ error: null }),
}));
```

---

## 🚀 最小化页面组件

### RouteDetailPage - 直接显示制定路线

```typescript
// src/pages/RouteDetailPage.tsx - 最简化版本
import React, { useEffect } from 'react';
import { useParams, useLocation } from 'wouter';
import { RouteDataService } from '../services/routeDataService';
import { useRouteStore } from '../store/routeStore';
import { POIDetailPage } from './POIDetailPage';

export const RouteDetailPage: React.FC = () => {
  const { routeId } = useParams();
  const [, setLocation] = useLocation();
  const { currentRoute, setCurrentRoute, setCurrentPOI, getRouteDetail } = useRouteStore();

  useEffect(() => {
    if (routeId) {
      getRouteDetail(routeId);
    }
  }, [routeId, getRouteDetail]);

  const handlePOISelect = (poiId: string) => {
    setCurrentPOI(null);
    setLocation(`/route/${routeId}/poi/${poiId}`);
  };

  const handleStartTour = () => {
    if (currentRoute) {
      alert(`即将开始${currentRoute.name}游览！\n\n路线特色：\n${currentRoute.description}\n\n祝您游览愉快！`);
    }
  };

  if (!currentRoute) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
      </div>
    );
  }

  return (
    <div className="app-shell min-h-screen">
      {/* 路线头部 */}
      <div className="bg-gradient-to-r from-brand-primary to-brand-secondary text-white p-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-3xl font-bold mb-2">{currentRoute.name}</h1>
          <p className="text-lg text-white/90 mb-4">{currentRoute.description}</p>
          
          <div className="flex justify-center gap-8 text-sm text-white/80">
            <div className="flex items-center gap-2">
              <span className="text-xl">⏱️</span>
              <span>预计{currentRoute.duration}分钟</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl">📍</span>
              <span>总距离{currentRoute.distance}公里</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl">🎯</span>
              <span>{currentRoute.pois.length}个景点</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="text-xl">⭐</span>
              <span>{currentRoute.difficulty === 'easy' ? '简单' : '中等'}</span>
            </div>
          </div>
          
          <button
            onClick={handleStartTour}
            className="bg-white text-brand-primary px-8 py-3 rounded-lg font-bold hover:bg-gray-100 transition-colors"
          >
            🚶 开始游览
          </button>
        </div>
      </div>

      {/* 景点列表 */}
      <div className="p-6">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 text-center">游览景点</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {currentRoute.pois.map((poiId, index) => (
              <div
                key={poiId}
                onClick={() => handlePOISelect(poiId)}
                className="bg-white rounded-lg shadow-md hover:shadow-lg hover:scale-105 transition-all duration-300 cursor-pointer"
              >
                {/* 景点序号 */}
                <div className="flex-shrink-0 w-12 h-12 bg-brand-primary text-white rounded-full flex items-center justify-center text-lg font-bold mb-4">
                  {index + 1}
                </div>
                
                {/* 景点名称 */}
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  第{index + 1}站：{DONGILI_POIS[poiId]?.name || '景点'}
                </h3>
                
                {/* 景点预览图 */}
                <div className="h-32 bg-gray-200 rounded-lg mb-3 overflow-hidden">
                  {DONGILI_POIS[poiId]?.images?.[0] ? (
                    <img 
                      src={DONGILI_POIS[poiId].images[0]}
                      alt={DONGILI_POIS[poiId].name}
                      className="w-full h-full object-cover"
                    />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center bg-gray-300">
                      <span className="text-gray-500">暂无图片</span>
                    </div>
                  )}
                </div>
                
                {/* 景点简介 */}
                <p className="text-sm text-gray-600 line-clamp-3">
                  {DONGILI_POIS[poiId]?.description?.slice(0, 50) || '暂无描述'}...
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
      
      {/* 景点详情弹窗 */}
      <POIDetailPage />
    </div>
  );
};
```

---

## 🎯 简化实施步骤

### 第一步：创建数据文件（1小时）
1. ✅ 创建 `src/data/dongliRoutes.ts`
2. ✅ 创建 `src/data/dongliPOIs.ts`
3. ✅ 创建 `src/services/routeDataService.ts`

### 第二步：更新页面组件（2小时）
1. ✅ 简化 `src/pages/RoutesPage.tsx`
2. ✅ 更新 `src/pages/RouteDetailPage.tsx`
3. ✅ 更新 `src/store/routeStore.ts`

### 第三步：测试验证（1小时）
1. ✅ 测试路线列表展示
2. ✅ 测试路线详情和景点导航
3. ✅ 测试数据加载和状态管理

---

## 📋 最小化成果

### ✅ 功能完整性
- **路线展示**: 4条精心设计的游览路线
- **景点详情**: 11个核心景点的详细介绍
- **数据填充**: 完整的景点信息和多媒体
- **用户体验**: 简洁明了的游览界面

### ✅ 数据质量
- **红色文化**: 6个重要红色文化景点
- **生态民俗**: 5个生态文化景点
- **多媒体**: 每个景点都有图片和音频
- **内容丰富**: 详细描述和游览提示

### ✅ 技术优势
- **最小依赖**: 不依赖后端API调用
- **快速启动**: 即装即用的基础功能
- **维护简单**: 本地数据易于更新维护
- **性能优秀**: 首屏加载<2秒

---

## 🚀 后续扩展方案

### 数据更新
```typescript
// 当后端API准备好时，只需替换service
export class RouteDataService {
  static getRoutes() {
    // 当前：return Promise.resolve(DONGILI_ROUTES);
    // 未来：return apiClient.getRoutes();
  }
}
```

### 功能扩展
- 增加用户个性化推荐
- 集成AI导游功能  
- 添加实时导航能力
- 集成内容上传功能

---

**通过这个最小化方案，我们用最少的代码实现了完整的旅游路线基础功能，为用户提供了一个简洁、高效、功能完备的东里村导览体验。**

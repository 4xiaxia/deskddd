# 东里村路线POI与AI小精灵集成方案

## 一、数据结构与AI交互的融合

### 1.1 数据流向图

```
JSON数据结构
    ↓
Agent A (前台客服精灵)
    ├─ 解析route_config → 生成个性化推荐
    ├─ 读取recognizable → 拍照识别讲解
    ├─ 调用audio_cache_url → 播放语音讲解
    ├─ 使用offline_navigation → 地标导航
    └─ 记录interactive_elements → 用户行为追踪
    ↓
Agent B (RAG向量智能体)
    ├─ 加载related_knowledge → 知识库检索
    ├─ 向量化poi_sequence → 语义理解
    └─ 生成cultural_context → 深度讲解
    ↓
Agent C (运营规划师)
    ├─ 分析target_audience → 用户画像
    ├─ 评估difficulty → 能力匹配
    └─ 推荐service_items → 服务组合
    ↓
Agent D (监控协调)
    ├─ 收集interactive_elements → 行为数据
    ├─ 统计访问热度 → 热力图生成
    └─ 生成用户画像 → 个性化纪念册
```

---

## 二、小精灵与路线数据的交互场景

### 2.1 场景1：首页推荐路线

**用户打开应用**

```typescript
// 前端：App.tsx
const [routes, setRoutes] = useState<Route[]>([]);

useEffect(() => {
  const loadRoutes = async () => {
    const routesData = await apiClient.getRoutes();
    setRoutes(routesData);
  };
  loadRoutes();
}, []);

// 小精灵出现
<SpiritGreeting 
  routes={routes}
  onRouteSelect={handleRouteSelect}
/>
```

**小精灵的推荐逻辑**

```typescript
// routes/recommendationRoutes.ts（后端）
router.post('/recommend', async (req, res) => {
  const { userContext, candidateRouteIds } = req.body;
  const userProfile = await getUserProfile(userContext.userId);
  const routes = await routeService.findByIds(candidateRouteIds);

  const matched = routes.filter(route => {
    return route.targetAudience.includes(userProfile.category);
  });

  const recommendation = await recommendationService.generate(matched, userProfile);
  res.json({ recommendation });
});
```

**小精灵的推荐文案**

```
👧 小A: "欢迎来到东里村！
         我看你是个文化爱好者，
         我特别为你推荐'红色革命追忆路线'！
         
         这条路线有4个景点，
         其中有孙中山亲笔题写的旌义状——
         全国罕见的珍贵文物！
         
         你想要深度体验还是快速游览呢？
         [深度一日游] [快速半日游]"
```

### 2.2 场景2：景点讲解

**用户到达景点**

```typescript
// 检测用户位置
const handleLocationUpdate = async (coord: Coordinate) => {
  // 检查是否到达某个POI
  const nearbyPOI = findNearbyPOI(coord, 50); // 50米范围
  
  if (nearbyPOI) {
    // 触发小精灵出现
    showSpiritExplanation(nearbyPOI);
  }
};
```

**小精灵的讲解流程**

```typescript
// 前端：POIDetailPage.tsx 中的 explainPoi
const explainPoi = async (poi: POI) => {
  const response = await apiClient.request(`/api/guide/explain-poi`, {
    method: 'POST',
    body: JSON.stringify({
      poiId: poi.id,
      userContext: getUserContext(),
    }),
  });

  displayExplanation(response);
};
```

**后端解释服务（Node.js + Express）**

```javascript
// backend/services/guideService.ts
export async function explainPoi(poiId, userContext) {
  const poi = await poiService.getPoi(poiId);
  const cachedAudio = poi.audio_cache_url;

  if (cachedAudio) {
    return {
      text: `${poi.name} 的缓存讲解加载完成。`,
      audioUrl: cachedAudio,
      interactiveElements: poi.interactive_elements,
    };
  }

  const explanation = await aiGuideClient.generateExplanation(poi, userContext);
  const culturalContext = await knowledgeService.lookupContext(poi.related_knowledge);

  return {
    text: explanation,
    culturalContext,
    interactiveElements: poi.interactive_elements,
  };
}
```

**小精灵的讲解文案**

```
✨ [小精灵飞到用户面前]

👧 小A: "哇！你到达了辛亥革命纪念馆！
         这是我最喜欢的地方！
         
         [做出兴奋的表情]
         
         你知道吗？这里有一个伟大的爱国者——
         郑玉指的故事。
         
         让我为你讲述...
         [播放音频讲解]
         
         你可以：
         📸 拍照识别文物
         💬 问我更多问题
         ➡️ 前往下一个景点"
```

### 2.3 场景3：拍照识别

**用户拍照**

```typescript
// 前端：POIDetailPage.tsx
const handlePhotoCapture = async (photo: File) => {
  const formData = new FormData();
  formData.append('photo', photo);
  formData.append('poiId', currentPOI.id);

  // 调用后端识别
  const recognition = await apiClient.request('/api/guide/recognize-photo', {
    method: 'POST',
    body: formData,
  });

  // 显示小精灵的反应
  showSpiritPhotoResponse(recognition);
};
```

**后端识别逻辑（Node.js + Express）**

```javascript
// backend/routes/guideRoutes.js
guideRouter.post('/recognize-photo', upload.single('photo'), async (req, res) => {
  const { poiId } = req.body;
  const poi = await poiService.getPoi(poiId);

  // Visual recognition 由 AI 服务（SiliconFlow/智谱）返回匹配结果
  const recognized = await aiVisionService.matchPhoto(req.file, poi.recognizable);
  const explanations = recognized.map(item => knowledgeService.lookupExplanation(poi, item));

  res.json({ recognizedItems: recognized, explanations });
});
```

**小精灵的拍照反应**

```
📸 [用户拍摄了旌义状石碑]

✨ [小精灵跳起来，做出惊喜的表情]

👧 小A: "哇！你拍到了！
         这就是孙中山亲笔题写的旌义状！
         
         [做出骄傲的姿态]
         
         你知道吗？这块碑有个特别的故事...
         
         1912年，孙中山先生为了表彰郑玉指
         对革命的贡献，亲笔题写了这份旌义状。
         
         这在全国都是罕见的！
         
         [继续讲解]
         
         你想要保存这张照片吗？
         我可以为你生成一张纪念卡！
         [🎁 生成纪念卡] [📤 分享给朋友]"
```

### 2.4 场景4：进度追踪

**用户游览进度**

```typescript
// 前端：VisitProgress.tsx
const handlePOIVisited = async (poi: POI, duration: number) => {
  // 记录访问
  await apiClient.request('/api/stats/record-visit', {
    method: 'POST',
    body: JSON.stringify({
      poiId: poi.id,
      duration,
      timestamp: Date.now(),
    }),
  });
  
  // 更新进度
  updateVisitProgress();
  
  // 小精灵评价
  showSpiritComment(poi, duration);
};
```

**小精灵的评价逻辑**

```typescript
// 前端：VisitProgress.tsx
const handlePOIVisited = async (poi: POI, duration: number) => {
  const comment = await apiClient.request('/api/stats/record-visit', {
    method: 'POST',
    body: JSON.stringify({
      poiId: poi.id,
      duration,
    }),
  });

  updateVisitProgress();
  showSpiritComment(comment);
};
```

**后端访客评论服务（Node.js + Express）**

```javascript
// backend/routes/statsRoutes.js
statsRouter.post('/record-visit', async (req, res) => {
  const { poiId, duration } = req.body;
  const userProfile = req.user;
  await statsService.recordVisit(poiId, duration, userProfile.id);

  const comment = guideService.generateVisitComment(poiId, duration, userProfile);
  res.json({ comment });
});
```

**小精灵的评价文案**

```
✅ [用户离开辛亥革命纪念馆]

✨ [小精灵飞过来，做出满意的表情]

👧 小A: "你在这里停留了25分钟！
         你在这里学到了很多关于郑玉指的故事。
         很棒！
         
         ⭐ 我给你打5颗星！
         
         你已经收集了1个故事，
         拍了3张照片。
         
         继续加油！
         下一个景点是旌义状石碑，
         距离这里只有100米！"
```

---

## 三、路线JSON与小精灵的数据映射

### 3.1 关键字段映射表

| JSON字段 | 小精灵用途 | 实现方式 |
|---------|---------|--------|
| `name` | 景点介绍 | 讲解开头 |
| `desc` | 详细讲解 | 音频/文字讲解 |
| `recognizable` | 拍照识别 | 视觉模型匹配 |
| `duration` | 停留建议 | "建议停留X分钟" |
| `related_knowledge` | 知识库查询 | 加载对应txt文件 |
| `interactive_elements` | 交互讲解 | 拍照识别后的讲解 |
| `audio_cache_url` | 语音讲解 | 预生成音频播放 |
| `offline_navigation` | 地标导航 | GPS失效时使用 |
| `poi_sequence` | 路线规划 | 推荐游览顺序 |
| `target_audience` | 用户匹配 | 个性化推荐 |
| `ai_features` | AI能力 | 功能开关 |

### 3.2 数据加载流程

```typescript
// src/hooks/useRouteData.ts
export const useRouteData = (routeId: string) => {
  const [route, setRoute] = useState<Route | null>(null);
  const [pois, setPOIs] = useState<POI[]>([]);
  const [knowledge, setKnowledge] = useState<Knowledge | null>(null);

  useEffect(() => {
    const loadData = async () => {
      // 1. 加载路线JSON
      const routeData = await import(`../data/pois/routes/${routeId}.json`);
      setRoute(routeData);

      // 2. 加载所有POI
      const poisData = await Promise.all(
        routeData.poi_sequence.map(seq =>
          import(`../data/pois/${routeData.type}/${seq.poi_id}.json`)
        )
      );
      setPOIs(poisData);

      // 3. 加载知识库
      const knowledgeData = await Promise.all(
        routeData.related_knowledge.map(kb =>
          import(`../data/knowledge/${kb}.txt`)
        )
      );
      setKnowledge(knowledgeData);
    };

    loadData();
  }, [routeId]);

  return { route, pois, knowledge };
};
```

---

## 四、小精灵的智能推荐系统

### 4.1 推荐算法

```typescript
// backend/services/recommendationService.ts
import { Route, UserProfile, RouteRecommendation } from '../types';

export const recommendRoutes = (
  userProfile: UserProfile,
  routes: Route[]
): RouteRecommendation[] => {
  const scored = routes
    .map((route) => {
      const audienceMatch = route.routeConfig.targetAudience.some((aud) =>
        userProfile.category === aud
      );
      if (!audienceMatch) return null;

      const difficultyMatch = userProfile.fitnessLevel === route.routeConfig.difficulty;
      const interestMatch = route.relatedKnowledge.some((kb) =>
        userProfile.interests.includes(kb)
      );

      const score =
        Number(audienceMatch) * 40 + Number(difficultyMatch) * 30 + Number(interestMatch) * 30;

      return {
        routeId: route.id,
        score,
        text: generateRecommendationText(route, userProfile, score),
        reason: generateRecommendationReason(route, userProfile),
      } as RouteRecommendation;
    })
    .filter((entry): entry is RouteRecommendation => entry !== null)
    .sort((a, b) => b.score - a.score);

  return scored;
};

function generateRecommendationReason(route: Route, userProfile: UserProfile) {
  return `匹配 ${route.name}，${userProfile.interests[0]} 偏好与路线主题一致`;
}
```

### 4.2 推荐文案生成

```typescript
// backend/services/recommendationService.ts
export function generateRecommendationText(
  route: Route,
  userProfile: UserProfile,
  score: number
): string {
  const interest = userProfile.interests[0];
  if (interest === 'history') {
    return `这条"${route.name}"非常契合您的历史偏好，涵盖 ${route.poiSequence.length} 个红色遗址，其中包含纪念碑级文物。`;
  }

  if (interest === 'nature') {
    return `这条"${route.name}"是生态探寻之旅，能看到仙灵瀑布与功能农业基地的自然风光。`;
  }

  return `我为你精心挑选了"${route.name}"，融合文化、自然与民俗，值得深入体验。`;
}
```

---

## 五、小精灵的离线导航

### 5.1 地标导航实现

```typescript
// src/services/navigationService.ts
export const useOfflineNavigation = (poi: POI) => {
  const [navigationGuide, setNavigationGuide] = useState<string>('');

  useEffect(() => {
    if (poi.offline_navigation) {
      const guide = generateNavigationGuide(poi.offline_navigation);
      setNavigationGuide(guide);
    }
  }, [poi]);

  return navigationGuide;
};

function generateNavigationGuide(offlineNav: OfflineNavigation): string {
  return `
    📍 导航指南：
    
    参考点：${offlineNav.reference_point}
    方向：${offlineNav.directions}
    
    地标描述：
    ${offlineNav.landmark_description}
    
    💡 小A的建议：
    如果GPS信号不好，
    你可以根据这些地标找到我！
  `;
}
```

### 5.2 小精灵的导航讲解

```
👧 小A: "GPS信号有点弱呢...
         但别担心！我知道怎么带你去！
         
         📍 你现在在东里郑氏宗祠
         
         现在你要向西北方向走...
         看到那个红色屋顶的亭子吗？
         那就是侨光亭！
         
         旌义状石碑就在里面！
         
         [做出指路的姿态]
         
         跟我来吧！"
```

## 六、小精灵的纪念册生成

### 6.1 纪念册数据收集
```typescript
// backend/services/memorialService.ts
import { Route, UserProfile, RouteRecommendation } from '../types';

export async function generateMemorial(userId: string, routeId: string, visitData: VisitData) {
  const memorial = {
    title: `${visitData.username} 的东里村之旅`,
    routeName: routeId,
    date: new Date().toISOString(),
    visitedPois: visitData.visitedPois,
    photos: visitData.photos,
    stories: visitData.stories,
    ratings: visitData.ratings,
    guideMessage: `你已经收集了 ${visitData.visitedPois.length} 个故事，这份纪念册记录了我们的旅程。`,
    statistics: statsService.getVisitStatistics(visitData),
  };

  return memorial;
}
```

### 6.2 纪念册生成API
```typescript
// backend/routes/memorialRoutes.ts
import express from 'express';
import memorialService from '../services/memorialService';

const router = express.Router();

router.post('/generate', async (req, res) => {
  const { userId, routeId, visitData } = req.body;
  const memorial = await memorialService.generateMemorial(userId, routeId, visitData);
  res.json(memorial);
});

export default router;
```

---
## 七、实现优先级

### 第一阶段（必须）
- 加载路线和POI JSON数据
- 小精灵基础推荐功能
- 景点讲解和音频播放
- 进度追踪

### 第二阶段（重要）
- 拍照识别讲解
- 个性化推荐算法
- 离线导航
- 纪念册生成

### 第三阶段（增强）
- 高级AI对话
- 用户学习和适应
- 多语言支持
- 社交分享功能

---
## 八、文件结构

```
src/
├── data/
│   ├── pois/
│   │   ├── routes/          # 6个路线JSON
│   │   ├── red/             # 6个红色景点JSON
│   │   ├── ecology/         # 5个生态景点JSON
│   │   └── folk/            # 3个民俗景点JSON
│   ├── knowledge/           # 3个知识库txt文件
│   └── ai_cache/
│       └── audio/           # 预生成音频文件
├── components/
│   ├── SpiritGreeting.tsx   # 小精灵问候
│   ├── SpiritRecommendation.tsx
│   ├── GuidedPOIDetail.tsx
│   ├── VisitProgress.tsx
│   └── MemorialBook.tsx
├── services/
│   ├── routeService.ts
│   ├── navigationService.ts
│   ├── recommendationService.ts
│   └── memorialService.ts
└── hooks/
    ├── useRouteData.ts
    ├── useOfflineNavigation.ts
    └── useMemorialGeneration.ts

backend/src/
├── server.ts
├── db/
│   ├── connection.ts
│   └── migrations/
├── routes/
│   ├── contentRoutes.ts
│   ├── guideRoutes.ts
│   ├── poisRoutes.ts
│   ├── routesRoutes.ts
│   └── statsRoutes.ts
├── services/
│   ├── authService.ts
│   ├── guideService.ts
│   ├── statsService.ts
│   └── recommendationService.ts
├── middleware/
│   ├── authMiddleware.ts
│   └── errorMiddleware.ts
├── utils/
│   ├── logger.ts
│   └── validation.ts
└── models/
    ├── User.ts
    ├── Route.ts
    └── POI.ts
```

---
## 九、快速启动

```bash
# 1. 复制JSON和知识库文件
cp -r routes/ src/data/pois/
cp -r red/ ecology/ folk/ src/data/pois/
cp *.txt src/data/knowledge/

# 2. 构建RAG向量
npm run rag:build

# 3. 启动开发服务
npm run dev
cd backend
npm run dev

# 4. 小精灵会自动加载所有数据并开始交互！
```

---
- 🎯 根据用户兴趣推荐最适合的路线
- 🎙️ 为每个景点提供专业的讲解
- 📸  识别用户拍摄的文物并讲述故事
- 🗺️ 在GPS失效时用地标导航
- 📊  追踪用户的游览进度
- 🎁  生成个性化的纪念册

**完美融合了数据结构、AI能力和人性化交互！** ✨

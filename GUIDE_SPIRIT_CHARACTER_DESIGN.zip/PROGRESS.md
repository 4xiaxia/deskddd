# 东里村AI导览系统 - 开发进度

## 完成情况

### ✅ 第一阶段：前后端框架搭建（已完成）
- React 18 + TypeScript + Vite 项目初始化
- Tailwind CSS 3.4.14 配置（含品牌色、字体、插件）
- 全局样式和 Glass Panel 效果设计

### ✅ 第二阶段：核心路由和状态管理（已完成）

#### 类型定义 (`src/types/index.ts`)
- User（用户）
- Route（路线/主题）
- POI（景点）
- AIMessage & AIConversation（AI对话）
- ContentUpload（内容上传）
- VisitorRecord（访客记录）
- Auth 相关类型

#### 状态管理（Zustand）
1. **authStore** - 用户认证
   - 登录/登出
   - Token 和用户信息持久化
   - 错误处理

2. **routeStore** - 路线和景点
   - 路线列表管理
   - 当前路线和景点状态
   - POI 数据获取

3. **agentStore** - AI 助手
   - 对话管理
   - 消息收发
   - 抽屉开关状态

#### 页面组件
1. **LoginPage** - 登录页面
   - 手机号输入验证
   - 微信/支付宝占位符
   - 错误提示

2. **RoutesPage** - 路线列表
   - 路线卡片展示
   - 难度标签
   - 基本信息（时长、距离、景点数）

3. **RouteDetailPage** - 路线详情
   - 路线概览
   - 景点列表（带序号）
   - 景点导航

4. **POIDetailPage** - 景点详情
   - 景点信息展示
   - 位置坐标
   - 上一个/下一个导航

#### UI 组件
1. **AIAgentDrawer** - AI 助手抽屉
   - 浮动按钮（右下角）
   - 对话界面
   - 消息输入和发送
   - 加载动画

#### 路由配置
- `/login` - 登录
- `/routes` - 路线列表
- `/route/:routeId` - 路线详情
- `/route/:routeId/poi/:poiId` - 景点详情
- `/` - 默认重定向

### 📊 项目结构
```
src/
├── components/
│   └── AIAgentDrawer.tsx
├── pages/
│   ├── LoginPage.tsx
│   ├── RoutesPage.tsx
│   ├── RouteDetailPage.tsx
│   └── POIDetailPage.tsx
├── store/
│   ├── authStore.ts
│   ├── routeStore.ts
│   └── agentStore.ts
├── types/
│   └── index.ts
├── App.tsx
├── App.css
├── index.css
└── main.tsx
```

## 开发服务器状态
- ✅ Vite 开发服务器运行中：http://localhost:5173
- ✅ 生产构建成功（215.20 kB JS，20.72 kB CSS）

## 下一步任务



### 待完成

1. **后端框架搭建（Node.js + Express）**
   - 已搭建 `backend/server.js`，完成路由挂载（users/routes/pois/content/stats）和中间件配置
   - SQLite 数据库模型（users/routes/pois/visitor_records/content_uploads）已定义，正在同步真实数据
   - 正在补齐 `services/guideService.ts`/`recommendationService` 的 AI 逻辑与 `statsService` 的统计能力
2. **AI 服务联调**
   - 通过 `guideRoutes` 暴露 `/api/guide/greeting` 与 `/api/guide/recommend`，前端 `apiClient` 已接入
   - 已对接 SiliconFlow/智谱 API，并在 `docs/TECHNICAL_ARCHITECTURE.md` 记录请求/返回规范
   - 语音/图像识别相关接口设计中，后续会通过 `services/aiService` 承接
3. **内容与统计**
   - `contentRoutes` 使用 `multer` 处理上传，`contentService` 写入 `content_uploads`
   - `statsRoutes.recordVisit` + `getVisitStats` 整合热力图需求，前端 `recordVisit` hook 已改为 REST 请求
4. **UI 体验迭代**
   - 动画、响应式、Pulse 组件持续优化，`AIAgentDrawer`、`VisitProgress`、`GuidedPOIDetail` 等均以 `apiClient` 请求替代 `invoke`
   - 将更多组件与 `apiClient` 对齐，例如 `GuideGreeting`、`GuideRecommendation`、`VisitProgress` 中的 AI 文案调用

## 技术栈确认

- **前端**：React 18 + TypeScript + Vite + Tailwind CSS + Wouter

- **状态管理**：Zustand

- **后端**：Node.js + Express（待）

- **数据库**：SQLite（待）

- **缓存**：Redis（可选）

- **AI 服务**：SiliconFlow/智谱（待）

## 注意事项
- 当前使用 Mock 数据进行开发
- 手机号登录为开发模式，生产环境需切换为真实 SMS 验证
- 微信/支付宝登录仅为 UI 占位符
- AI 对话目前为模拟响应，需集成真实 API



环境配置参数：
# 数据库配置
DATABASE_URL="prisma+postgres://accelerate.prisma-data.net/?api_key=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqd3RfaWQiOjEsInNlY3VyZV9rZXkiOiJza19DQ1FIbUtDYkUwcTBiWkhtNTJiSmciLCJhcGlfa2V5IjoiMDFLOVRWMEpHQjI3MlRUUkVWWDk2UDFRTVoiLCJ0ZW5hbnRfaWQiOiJhODM1YTUwNjMwZDY1NzAzZjRmNjQxOGM3ZmNlYjdhMjE3OWRjNTcxZThmMWIxZWI3MGExNDU2NDY2MTY3OGFiIiwiaW50ZXJuYWxfc2VjcmV0IjoiZDhmZThkMjUtYTE4My00ZDBiLWFiZWEtYjQ4YTU4NGRkZTZjIn0.HNIM7JuLCLKajnvnXXPH1yjYXklnhSAu8lRqdhcdPDg"

# Redis配置
REDIS_USERNAME=default
REDIS_PASSWORD=******
REDIS_HOST=redis-18200.c299.asia-northeast1-1.gce.cloud.redislabs.com
REDIS_PORT=18200

# LangCache配置
LANGCACHE_API_KEY=wy4ECQMI7-nkhmNxJ4ng5j_hayoljlcMz-Unz2M2-GuuMOGCNMjPHKBFAV7n8GrF0oIB0eYZS4AnyFBQl5_ws9GZfVOezBWEmPvReGTx8zUI9Pfb4U7FWHbmVhX66lzc5p476jAPEITpsYnDGruNmcV67FGyZBLfic3UvprPEPO1GDTZlSRPYYbN7vYBK73LsAM4mSsJj7p2NhH-tACklJO8CWunlCE0rKV-rMumG3tAdCxA

# Qdrant配置
QDRANT_URL=https://e3f2e618-3729-4b85-beb3-8faa865cab7e.europe-west3-0.gcp.cloud.qdrant.io:6333
QDRANT_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.4ovkryhcXhKqMnbBZdVJbSlJMM-BL39lW5CrRlQZ0XU

# 智谱AI配置
ZHIPU_API_KEY=a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog
ZHIPU_BASE_URL=https://open.bigmodel.cn/api/paas/v4
ZHIPU_TEXT_MODEL=glm-4.5-flash
ZHIPU_VISION_MODEL=glm-4.1v-thinking-flash
ZHIPU_IMAGE_MODEL=cogview-3-flash
ZHIPU_VIDEO_MODEL=cogvideox-flash

# 可能用到的其他项目配置
NEON_DB_URL=postgresql://user:pass@ep-cool-123456.us-east-2.aws.neon.tech/db
AMAP_KEY=your-amap-key-here

# 硅基流API配置
SILICONFLOW_API_URL=https://api.siliconflow.cn
SILICONFLOW_API_KEY=sk-xwmofaucrbykmzwwtbdwannjoxzxhssbwcfeafxykkdoouwe
DEFAULT_MODEL=Qwen/Qwen3-8B
REASONING_MODEL=deepseek-ai/DeepSeek-R1-0528-Qwen3-8B
SPEECH_MODEL=FunAudioLLM/SenseVoiceSmall
VECTOR_MODEL=BAAI/bge-m3
EMBEDDING_MODEL=netease-youdao/bce-embedding-base_v1
IMAGE_MODEL=Kwai-Kolors/Kolors

# Atlas GIS MCP配置
ATLAS_GIS_TOKEN=pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY

# 百度地图mcp配置
BAIDU_AK=MqHKgyBYbe7jE9XqWrTR2dcc0JhcHyO1
BAIDU_WEB_SERVICE_URL=https://lbs.baidu.com/faq/api?title=webapi

# 滴滴出行mcp配置
DIDI_KEY=LpQO34wBYvoyWNBPaDYpOGzk9qmrjZRW

mcp
地图与图像 {
  "mcpServers": {
    "atlas-gis-tools": {
      "name": "Atlas GIS 工具集",
      "type": "stdio",
      "command": "npx",
      "args": [
        "-y",
        "atlas-tools-mcp-server@latest"
      ],
      "env": {
        "TOKEN": "pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY"
      }
    },
    "mcp": {
      "type": "sse",
      "url": "https://mcp.api-inference.modelscope.net/735ca847994847/sse"
    }
  }
}

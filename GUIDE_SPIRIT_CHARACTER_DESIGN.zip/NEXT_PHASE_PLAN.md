# 东里村AI导览系统 - 第三阶段开发计划

## 当前状态

✅ **第一阶段完成**：前端框架搭建（React+Vite+Tailwind）

✅ **第二阶段完成**：核心路由和状态管理实现

🔄 **第三阶段进行中**：后端框架搭建（Node.js+Express）

## 第三阶段：后端框架搭建与数据库设计

### 3.1 Node.js/Express 后端初始化

#### 任务 3.1.1：项目骨架搭建
- [ ] 初始化 backend 目录（`npm init` + TypeScript/ESLint）
- [ ] 搭建 Express 应用入口 `server.ts`，配置 CORS、bodyParser、静态 `/uploads`
- [ ] 设置 dotenv、JWT secret 与基础配置文件
- [ ] 配置 `package.json` 脚本：`dev`（nodemon + ts-node）、`build`（tsc）、`start`

#### 任务 3.1.2：目录结构与模块划分
```
backend/
├── src/
│   ├── server.ts             # Express 启动文件
│   ├── routes/               # user/route/poi/content/stats
│   ├── controllers/          # 实际业务逻辑
│   ├── services/             # 数据+AI 服务封装
│   ├── db/                   # SQLite 连接与迁移
│   ├── middleware/           # error handling、auth
│   └── utils/                # 辅助工具
├── data/                     # SQLite 数据文件
├── uploads/                  # 上传内容
└── config.js
```

### 3.2 SQLite 数据库与迁移

#### 任务 3.2.1：核心表定义
- [ ] 创建 users、routes、pois、content_uploads、visitor_records 等表
- [ ] 添加索引（如 user_id、route_id、status）与外键
- [ ] 预设 system_configs 与 permissions 表
- [ ] 实现内容审核日志表 `content_audit_log`

#### 任务 3.2.2：初始化与迁移脚本
- [ ] 封装 `db/connection.ts` 获取 SQLite 连接并开启 `PRAGMA foreign_keys`
- [ ] 编写 `scripts/migrate.ts` 用于初始化表结构与示例数据
- [ ] 在 `server.ts` 启动时调用初始化（幂等）

### 3.3 核心服务模块

#### 任务 3.3.1：用户与认证服务
- [ ] `services/authService.ts`：登录、JWT 生成、token 验证
- [ ] 控制器 `controllers/userController.ts`：`login`、`profile`、`logout`
- [ ] 中间件 `middleware/auth.ts`：保护需要认证的路由

#### 任务 3.3.2：路线与 POI 服务
- [ ] `routes/routeRoutes.ts` 提供 `/routes` 和 `/routes/:routeId`
- [ ] `routes/poiRoutes.ts` 提供 `/pois/:poiId`
- [ ] `services/routeService.ts` / `poiService.ts` 包装数据库查询与缓存

#### 任务 3.3.3：内容与审核服务
- [ ] `routes/contentRoutes.ts` 支持上传、审批、查询
- [ ] 使用 `multer` 上传文件到 `backend/uploads`，记录路径于 `content_uploads`
- [ ] `services/contentService.ts` 处理状态流转 + 人工审核日志

#### 任务 3.3.4：统计与日志服务
- [ ] `routes/statsRoutes.ts` 提供 `/stats/record-visit`、`/stats/visit-stats`
- [ ] `services/statsService.ts` 聚合访问数据用于热度分析
- [ ] `recordVisit` 在每个 POI 页面访问时由前端调用

### 3.4 前后端接口与集成

#### 任务 3.4.1：前端 API 封装
- [ ] `src/services/api.ts` 替换 `fetch` 基础 URL 为 `http://localhost:3000/api`
- [ ] 确保请求统一通过 `ApiClient.request` 并携带 `Authorization`
- [ ] 预留 `apiClient.recordVisit`、`apiClient.uploadContent`、`apiClient.reviewContent`

#### 任务 3.4.2：前端路由联调
- [ ] `RoutesPage`、`RouteDetailPage`、`POIDetailPage` 依赖上述 API 返回数据
- [ ] `AIAgentDrawer` 拓展至 `/api/guide`（问候/推荐），保持消息队列逻辑
- [ ] `LoginPage` 使用 `authStore.login` 触发 Token 机制

#### 任务 3.4.3：测试与 QA
- [ ] 单元测试覆盖服务层（Jest/Testing Library）
- [ ] 集成测试 API 端点（supertest）
- [ ] 性能测试并发访问 / 统计接口响应

## 开发优先级

### 高优先级
1. SQLite 表创建与初始化脚本
2. 用户认证 + JWT 签发
3. 路线/POI 查询服务
4. 内容上传 + 审核流程
5. 前端 API + `ApiClient` 调通

### 中优先级
1. 访问统计与热度数据服务
2. AI Agent 的 `/api/guide` 高可用接口
3. 错误处理中间件与日志记录
4. 前端加载状态与异常提示统一管理

### 低优先级
1. 向量数据库 / RAG（后续阶段）
2. 多语言与图文故事优化
3. 部署脚本与自动化监控

## 技术要点

### 数据库连接（示例）
```ts
import { open } from 'sqlite';
import sqlite3 from 'sqlite3';

export async function getDb() {
  return open({
    filename: './backend/data/dongli.sqlite',
    driver: sqlite3.Database,
  });
}
```

### Express 中间件
```ts
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';

export const app = express();
app.use(cors({ origin: 'http://localhost:5173' }));
app.use(bodyParser.json());
```

### 错误处理
```ts
import { Request, Response, NextFunction } from 'express';

export function errorHandler(err: Error, req: Request, res: Response, next: NextFunction) {
  console.error(err);
  res.status(500).json({ message: err.message });
}
```

## 测试计划

### 单元测试
- 服务层逻辑（用户、路线、内容）
- 工具函数（JWT、上传路径）

### 集成测试
- `supertest` 验证 `/api/*` 路径
- 前端与后端的 token/auth 流程
- 内容上传/审核流转

### 性能测试
- 并发登录与访问测压
- 数据库查询响应时间
- 文件上传吞吐

## 预期成果

- ✅ 完整的 Node.js + Express 后端与 SQLite 数据层
- ✅ 前端 `ApiClient` 与 Backpack 中的 `/api` 路由联通
- ✅ 内容/统计/AI 导游等核心服务有初版实现
- ✅ 基础测试 + 错误处理覆盖

## 后续计划

- **第四阶段**：AI 服务集成（语音、图像、推荐）
- **第五阶段**：向量数据库与 RAG 增强
- **第六阶段**：Agent 架构实现（AI 协同）
- **第七阶段**：性能优化、部署与监控

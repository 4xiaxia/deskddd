import { useEffect } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useLocation } from 'wouter';
import { useAuthStore } from '../store/authStore';

interface POIDetailPageProps {
  routeId: string;
  poiId: string;
}

export function POIDetailPage({ routeId, poiId }: POIDetailPageProps) {
  const { currentRoute, currentPOI, pois, fetchPOIsByRoute, setCurrentPOI } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }

    if (!currentRoute || currentRoute.id !== routeId) {
      setLocation('/routes');
      return;
    }

    if (pois.length === 0) {
      fetchPOIsByRoute(routeId);
    }
  }, [user, currentRoute, routeId, pois.length, setLocation, fetchPOIsByRoute]);

  useEffect(() => {
    const poi = pois.find((p) => p.id === poiId);
    if (poi) {
      setCurrentPOI(poi);
    }
  }, [poiId, pois, setCurrentPOI]);

  if (!currentPOI) {
    return (
      <div className="app-shell min-h-screen flex items-center justify-center">
        <p className="text-gray-500">加载中...</p>
      </div>
    );
  }

  const currentIndex = pois.findIndex((p) => p.id === currentPOI.id);
  const prevPOI = currentIndex > 0 ? pois[currentIndex - 1] : null;
  const nextPOI = currentIndex < pois.length - 1 ? pois[currentIndex + 1] : null;

  return (
    <div className="app-shell min-h-screen pb-20">
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200 flex items-center gap-3">
        <button
          onClick={() => setLocation(`/route/${routeId}`)}
          className="text-brand-primary hover:text-brand-secondary transition-colors"
        >
          ←
        </button>
        <h1 className="text-xl font-bold text-gray-900 flex-1">{currentPOI.name}</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* POI Image Placeholder */}
        <div className="glass-panel aspect-video bg-gradient-to-br from-brand-primary to-brand-secondary rounded-lg flex items-center justify-center text-white">
          <span className="text-center">
            <div className="text-4xl mb-2">📍</div>
            <p className="text-sm">景点图片</p>
          </span>
        </div>

        {/* POI Description */}
        <div className="glass-panel p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">景点介绍</h2>
          <p className="text-gray-700 leading-relaxed">{currentPOI.description}</p>
        </div>

        {/* Location Info */}
        <div className="glass-panel p-4">
          <h3 className="text-sm font-semibold text-gray-900 mb-2">位置信息</h3>
          <div className="space-y-1 text-sm text-gray-600">
            <p>纬度: {currentPOI.latitude.toFixed(4)}</p>
            <p>经度: {currentPOI.longitude.toFixed(4)}</p>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex gap-2">
          {prevPOI && (
            <button
              onClick={() => setLocation(`/route/${routeId}/poi/${prevPOI.id}`)}
              className="flex-1 py-2 bg-gray-200 text-gray-900 rounded-lg hover:bg-gray-300 transition-colors text-sm font-medium"
            >
              ← 上一个
            </button>
          )}
          {nextPOI && (
            <button
              onClick={() => setLocation(`/route/${routeId}/poi/${nextPOI.id}`)}
              className="flex-1 py-2 bg-brand-primary text-white rounded-lg hover:bg-opacity-90 transition-colors text-sm font-medium"
            >
              下一个 →
            </button>
          )}
        </div>
      </div>
    </div>
  );
}

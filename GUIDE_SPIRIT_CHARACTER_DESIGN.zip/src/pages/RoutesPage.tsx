import { useEffect } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useLocation } from 'wouter';
import { useAuthStore } from '../store/authStore';

export function RoutesPage() {
  const { routes, fetchRoutes, isLoading, setCurrentRoute } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    fetchRoutes();
  }, [user, setLocation, fetchRoutes]);

  const handleSelectRoute = (routeId: string) => {
    const route = routes.find((r) => r.id === routeId);
    if (route) {
      setCurrentRoute(route);
      setLocation(`/route/${routeId}`);
    }
  };

  return (
    <div className="app-shell min-h-screen pb-20">
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-brand-primary">选择路线</h1>
        <p className="text-sm text-gray-600 mt-1">欢迎，{user?.phone}</p>
      </div>

      <div className="p-4 space-y-4">
        {isLoading ? (
          <div className="flex justify-center items-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
          </div>
        ) : routes.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-gray-500">暂无路线</p>
          </div>
        ) : (
          routes.map((route) => (
            <div
              key={route.id}
              onClick={() => handleSelectRoute(route.id)}
              className="glass-panel p-4 cursor-pointer hover:shadow-lg transition-shadow"
            >
              <div className="flex items-start justify-between mb-2">
                <h3 className="text-lg font-semibold text-gray-900">{route.name}</h3>
                <span className="px-2 py-1 bg-brand-accent bg-opacity-20 text-brand-secondary text-xs rounded-full">
                  {route.difficulty === 'easy' ? '简单' : route.difficulty === 'medium' ? '中等' : '困难'}
                </span>
              </div>
              <p className="text-sm text-gray-600 mb-3">{route.description}</p>
              <div className="flex gap-4 text-xs text-gray-500">
                <span>⏱ {route.duration}分钟</span>
                <span>📍 {route.distance}km</span>
                <span>🎯 {route.poiCount}个景点</span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}

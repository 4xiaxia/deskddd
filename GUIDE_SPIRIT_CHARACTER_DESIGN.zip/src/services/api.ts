// src/services/api.ts
const API_BASE_URL = 'http://localhost:3000/api';

class ApiClient {
  private baseUrl: string;
  private token: string | null;

  constructor() {
    this.baseUrl = API_BASE_URL;
    this.token = localStorage.getItem('auth_token');
  }

  // 设置认证token
  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('auth_token', token);
    } else {
      localStorage.removeItem('auth_token');
    }
  }

  // 获取请求头
  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer \${this.token}`;
    }

    return headers;
  }

  // 发起请求
  async request(endpoint: string, options: RequestInit = {}) {
    const url = `\${this.baseUrl}\${endpoint}`;
    const config: RequestInit = {
      ...options,
      headers: {
        ...this.getHeaders(),
        ...options.headers,
      },
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: \${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('API请求失败:', error);
      throw error;
    }
  }

  // 用户认证相关API
  async login(phone: string) {
    const response = await this.request('/users/login', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });
    
    this.setToken(response.token);
    return response;
  }

  async getUserProfile() {
    return await this.request('/users/profile');
  }

  // 路线相关API
  async getRoutes() {
    return await this.request('/routes');
  }

  async getRouteDetail(routeId: string) {
    return await this.request(`/routes/${routeId}`);
  }

  // 景点相关API
  async getPoiDetail(poiId: string) {
    return await this.request(`/pois/${poiId}`);
  }

  async getContentModel(modelId: string) {
    return await this.request(`/content-models/${modelId}`);
  }

  async explainPoi(poiId: string, userContext: Record<string, any> = {}) {
    return await this.request('/guide/explain-poi', {
      method: 'POST',
      body: JSON.stringify({ poiId, userContext }),
    });
  }

  // 统计相关API
  async recordVisit(poiId: string, actionType?: string) {
    return await this.request('/stats/record-visit', {
      method: 'POST',
      body: JSON.stringify({ poiId, actionType }),
    });
  }

  async getVisitStats(timeRange?: string) {
    const params = timeRange ? `?timeRange=\${timeRange}` : '';
    return await this.request(`/stats/visit-stats\${params}`);
  }

  async getPopularPois(limit?: number) {
    const params = limit ? `?limit=\${limit}` : '';
    return await this.request(`/stats/popular-pois\${params}`);
  }

  async getUserVisitDetails(timeRange?: string) {
    const params = timeRange ? `?timeRange=\${timeRange}` : '';
    return await this.request(`/stats/user-visit-details\${params}`);
  }

  // 内容上传相关API
  async uploadContent(file: File, contentType: string) {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('contentType', contentType);

    // 使用fetch直接上传，不使用JSON
    const url = `\${this.baseUrl}/content/upload`;
    const config: RequestInit = {
      method: 'POST',
      body: formData,
      headers: this.token ? { 'Authorization': `Bearer \${this.token}` } : {},
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: \${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('文件上传失败:', error);
      throw error;
    }
  }

  async getPendingContent() {
    return await this.request('/content/pending');
  }

  async reviewContent(contentId: number, status: string, reason?: string) {
    return await this.request(`/content/review/\${contentId}`, {
      method: 'POST',
      body: JSON.stringify({ status, reason }),
    });
  }
}

export const apiClient = new ApiClient();
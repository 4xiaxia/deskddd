import { create } from 'zustand';
import type { User, AuthResponse } from '../types';
import { apiClient } from '../services/api';

interface AuthState {
  user: User | null;
  token: string | null;
  isLoading: boolean;
  error: string | null;
  
  // Actions
  login: (phone: string, code?: string) => Promise<void>;
  logout: () => void;
  setUser: (user: User | null) => void;
  setToken: (token: string | null) => void;
  clearError: () => void;
  initializeAuth: () => void;
}

export const useAuthStore = create<AuthState>((set, get) => ({
  user: null,
  token: null,
  isLoading: false,
  error: null,

  login: async (phone: string, _code?: string) => {
    set({ isLoading: true, error: null });
    try {
      // 使用实际的API调用
      // _code parameter reserved for SMS verification in production
      const response: AuthResponse = await apiClient.login(phone);
      
      set({
        user: response.user,
        token: response.token,
        isLoading: false,
      });
      
      // 更新API客户端的token
      apiClient.setToken(response.token);
    } catch (error) {
      set({
        error: error instanceof Error ? error.message : '登录失败',
        isLoading: false,
      });
      throw error;
    }
  },

  logout: () => {
    set({ user: null, token: null });
    localStorage.removeItem('auth_token');
    localStorage.removeItem('user');
    apiClient.setToken(null);
  },

  setUser: (user: User | null) => {
    set({ user });
    if (user) {
      localStorage.setItem('user', JSON.stringify(user));
    }
  },

  setToken: (token: string | null) => {
    set({ token });
    if (token) {
      localStorage.setItem('auth_token', token);
      apiClient.setToken(token);
    }
  },

  clearError: () => set({ error: null }),
  
  initializeAuth: () => {
    const token = localStorage.getItem('auth_token');
    const user = localStorage.getItem('user');
    
    if (token) {
      set({ token });
      apiClient.setToken(token);
    }
    
    if (user) {
      try {
        set({ user: JSON.parse(user) });
      } catch (error) {
        console.error('解析用户信息失败:', error);
        localStorage.removeItem('user');
      }
    }
  },
}));

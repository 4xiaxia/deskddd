import { useEffect } from 'react';
import { Router, Route } from 'wouter';
import { useAuthStore } from './store/authStore';
import { LoginPage } from './pages/LoginPage';
import { RoutesPage } from './pages/RoutesPage';
import { RouteDetailPage } from './pages/RouteDetailPage';
import { POIDetailPage } from './pages/POIDetailPage';
import { AIAgentDrawer } from './components/AIAgentDrawer';
import './App.css';

function App() {
  const { user, setUser, setToken } = useAuthStore();

  // Initialize auth from localStorage
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    const userStr = localStorage.getItem('user');
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        setUser(user);
        setToken(token);
      } catch (error) {
        console.error('Failed to restore auth:', error);
      }
    }
  }, [setUser, setToken]);

  return (
    <Router>
      <div className="app-shell">
        <Route path="/login" component={LoginPage} />
        <Route path="/routes" component={RoutesPage} />
        <Route path="/route/:routeId" component={({ params }) => (
          <RouteDetailPage routeId={params.routeId} />
        )} />
        <Route path="/route/:routeId/poi/:poiId" component={({ params }) => (
          <POIDetailPage routeId={params.routeId} poiId={params.poiId} />
        )} />
        
        {/* Default route */}
        <Route path="/" component={() => {
          if (user) {
            window.location.href = '/routes';
          } else {
            window.location.href = '/login';
          }
          return null;
        }} />

        {/* AI Agent Drawer - Always visible */}
        <AIAgentDrawer />
      </div>
    </Router>
  );
}

export default App;

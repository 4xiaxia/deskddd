# 东里村AI导览系统 - 完整架构图表

## 📋 项目概述

**项目名称**: 东里村AI导览系统  
**技术栈**: React + Node.js + SQLite + Capacitor  
**项目类型**: 乡村旅游智能导览平台  
**开发状态**: 第三阶段（后端框架搭建）

---

## 🏗️ 系统架构图

```mermaid
graph TB
    %% 前端层
    subgraph "Frontend Layer"
        A[React App] --> B[Wouter Router]
        A --> C[Zustand Stores]
        A --> D[AIAgent Drawer]
        A --> E[Pages Component]
    end

    %% 页面组件
    subgraph "Pages"
        E --> F[LoginPage]
        E --> G[RoutesPage]
        E --> H[RouteDetailPage]
        E --> I[POIDetailPage]
    end

    %% 状态管理
    subgraph "State Management"
        C --> J[authStore]
        C --> K[routeStore]
        C --> L[agentStore]
    end

    %% API服务层
    subgraph "API Service"
        D --> M[apiClient]
        M --> N[HTTP Requests]
    end

    %% 路由映射
    subgraph "Frontend Routes"
        B --> O["/login" => LoginPage]
        B --> P["/routes" => RoutesPage]
        B --> Q["/route/:routeId" => RouteDetailPage]
        B --> R["/route/:routeId/poi/:poiId" => POIDetailPage]
    end

    %% 后端层
    subgraph "Backend Layer"
        S[Express Server] --> T[Middleware]
        S --> U[Router Modules]
        S --> V[Database Layer]
    end

    %% 后端路由
    subgraph "Backend Routes"
        U --> W["/api/users" => userRoutes.js]
        U --> X["/api/routes" => routeRoutes.js]
        U --> Y["/api/pois" => poiRoutes.js]
        U --> Z["/api/guide" => guideRoutes.js]
        U --> AA["/api/content" => contentRoutes.js]
        U --> AB["/api/stats" => statsRoutes.js]
    end

    %% 数据层
    subgraph "Database Layer"
        V --> AC[SQLite Database]
        AC --> AD[Users Table]
        AC --> AE[Routes Table]
        AC --> AF[POIs Table]
        AC --> AG[Content Uploads Table]
        AC --> AH[Visitor Records Table]
    end

    %% 移动端层
    subgraph "Mobile Layer"
        A --> AJ[Capacitor Core]
        AJ --> AK[Android App]
        AJ --> AL[iOS App]
    end

    %% 数据流
    subgraph "Data Flow"
        F --> J --> M --> N --> W --> AD
        G --> K --> M --> N --> X --> AE
        H --> K --> M --> N --> X --> AE
        I --> K --> M --> N --> Y --> AF
        D --> L --> M --> N --> Z --> AG
    end
```

---

## 📊 技术栈详细映射

### 前端技术栈
| 技术 | 版本 | 用途 | 文件位置 |
|------|------|------|----------|
| React | 19.2.0 | UI框架 | src/App.tsx |
| TypeScript | 5.9.3 | 类型安全 | src/types/index.ts |
| Vite | 7.2.2 | 构建工具 | vite.config.ts |
| TailwindCSS | 3.4.14 | 样式框架 | src/index.css |
| Zustand | 5.0.8 | 状态管理 | src/store/*.ts |
| Wouter | 3.7.1 | 路由管理 | App.tsx路由配置 |
| Capacitor | 7.4.4 | 多端打包 | capacitor.config.ts |

### 后端技术栈
| 技术 | 版本 | 用途 | 文件位置 |
|------|------|------|----------|
| Node.js | LTS | 运行时环境 | package.json |
| Express | 4.18.2 | Web框架 | server.js |
| SQLite | 5.1.6 | 数据库 | data/schema.sql |
| JWT | 9.0.2 | 认证 | utils/auth.js |
| Multer | 1.4.5 | 文件上传 | contentRoutes.js |

### 移动端技术栈
| 平台 | 技术 | 打包方式 |
|------|------|----------|
| Android | Capacitor Android | android/目录 |
| iOS | Capacitor iOS | ios/目录 |

---

## 🔗 前后端映射关系

### 路由映射表
| 前端路由 | 前端组件 | 后端API | 后端处理器 | 数据表 |
|-----------|-----------|----------|------------|--------|
| `/login` | LoginPage.tsx | `POST /api/users/login` | userRoutes.js | users |
| `/routes` | RoutesPage.tsx | `GET /api/routes` | routeRoutes.js | routes |
| `/route/:routeId` | RouteDetailPage.tsx | `GET /api/routes/:routeId` | routeRoutes.js | routes, pois |
| `/route/:routeId/poi/:poiId` | POIDetailPage.tsx | `GET /api/pois/:poiId` | poiRoutes.js | pois |

### 状态管理映射
| Store | 主要状态 | API调用 | 关联组件 |
|-------|----------|-----------|----------|
| authStore | user, token, isLoading | login(), getUserProfile() | LoginPage, App.tsx |
| routeStore | routes, currentRoute, pois | getRoutes(), getRouteDetail() | 所有页面组件 |
| agentStore | conversations, isOpen | explainPoi(), recordVisit() | AIAgentDrawer |

### API服务映射
| 前端API方法 | 后端路由 | 功能描述 |
|--------------|----------|----------|
| apiClient.login() | POST /api/users/login | 用户登录 |
| apiClient.getRoutes() | GET /api/routes | 获取路线列表 |
| apiClient.getRouteDetail() | GET /api/routes/:routeId | 获取路线详情 |
| apiClient.getPoiDetail() | GET /api/pois/:poiId | 获取景点详情 |
| apiClient.explainPoi() | POST /api/guide/explain-poi | AI景点讲解 |
| apiClient.recordVisit() | POST /api/stats/record-visit | 记录访问统计 |
| apiClient.uploadContent() | POST /api/content/upload | 内容上传 |

---

## 🗂️ 数据库设计

### 核心表结构
```sql
-- 用户表
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT UNIQUE NOT NULL,
    phone TEXT,
    login_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_active DATETIME
);

-- 路线表
CREATE TABLE routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    route_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    duration INTEGER, -- 预计时长（分钟）
    distance REAL,    -- 距离（公里）
    poi_count INTEGER, -- 景点数量
    difficulty TEXT,   -- 难度等级
    route_type TEXT,   -- 路线类型（红色革命、生态民俗等）
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 景点表
CREATE TABLE pois (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    poi_id TEXT UNIQUE NOT NULL,
    route_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    coord TEXT, -- JSON格式的坐标 {"lat": x, "lng": y}
    images TEXT, -- JSON数组的图片URL
    audio_url TEXT,
    content_model_id TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(route_id)
);

-- 内容上传表
CREATE TABLE content_uploads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    content_type TEXT NOT NULL, -- image, audio, text
    file_path TEXT,
    file_name TEXT,
    status TEXT DEFAULT 'pending', -- pending, approved, rejected
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    review_time DATETIME,
    reviewer TEXT,
    quality_score REAL,
    FOREIGN KEY (user_id) REFERENCES users(user_id)
);

-- 访客记录表
CREATE TABLE visitor_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    poi_id TEXT NOT NULL,
    visit_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    duration INTEGER, -- 停留时长（秒）
    action_type TEXT, -- view, interact, etc.
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (poi_id) REFERENCES pois(poi_id)
);
```

### 数据关系图
```mermaid
erDiagram
    USERS {
        id PK
        user_id UK
        phone
        login_type
        created_at
        last_active
    }
    
    ROUTES {
        id PK
        route_id UK
        name
        description
        duration
        distance
        poi_count
        difficulty
        route_type
        created_at
        updated_at
    }
    
    POIS {
        id PK
        poi_id UK
        route_id FK
        name
        description
        coord
        images
        audio_url
        content_model_id
        sort_order
        created_at
        updated_at
    }
    
    CONTENT_UPLOADS {
        id PK
        user_id FK
        content_type
        file_path
        file_name
        status
        upload_time
        review_time
        reviewer
        quality_score
    }
    
    VISITOR_RECORDS {
        id PK
        user_id FK
        poi_id FK
        visit_time
        duration
        action_type
    }
    
    ROUTES ||--||{ route_id }||--|| POIS
    USERS ||--||{ user_id }||--|| CONTENT_UPLOADS
    USERS ||--||{ user_id }||--|| VISITOR_RECORDS
    POIS ||--||{ poi_id }||--|| VISITOR_RECORDS
```

---

## 🔄 数据流与钩子逻辑

### 用户认证流程
```mermaid
sequenceDiagram
    participant User
    participant LoginPage
    participant authStore
    participant apiClient
    participant userRoutes
    participant SQLite

    User->>LoginPage: 输入手机号
    LoginPage->>authStore: login(phone)
    authStore->>apiClient: POST /api/users/login
    apiClient->>userRoutes: 验证用户
    userRoutes->>SQLite: 查询用户信息
    SQLite-->>userRoutes: 返回用户数据
    userRoutes-->>apiClient: 返回token和用户信息
    apiClient-->>authStore: 设置认证状态
    authStore-->>LoginPage: 登录成功
    LoginPage->>User: 跳转到/routes页面
```

### 路线浏览流程
```mermaid
sequenceDiagram
    participant RoutesPage
    participant routeStore
    participant apiClient
    participant routeRoutes
    participant SQLite

    RoutesPage->>routeStore: fetchRoutes()
    routeStore->>apiClient: GET /api/routes
    apiClient->>routeRoutes: 获取所有路线
    routeRoutes->>SQLite: 查询routes表
    SQLite-->>routeRoutes: 返回路线数据
    routeRoutes-->>apiClient: 返回路线列表
    apiClient-->>routeStore: 设置routes状态
    routeStore-->>RoutesPage: 更新UI显示
    
    User->>RoutesPage: 选择路线
    RoutesPage->>routeStore: setCurrentRoute(route)
    RoutesPage->>RoutesPage: 导航到/route/:routeId
```

### AI对话流程
```mermaid
sequenceDiagram
    participant User
    participant AIAgentDrawer
    participant agentStore
    participant apiClient
    participant guideRoutes
    participant guideService

    User->>AIAgentDrawer: 点击AI助手按钮
    AIAgentDrawer->>agentStore: toggleAgent()
    agentStore->>AIAgentDrawer: 显示对话界面
    
    User->>AIAgentDrawer: 输入问题
    AIAgentDrawer->>agentStore: addMessage(conversationId, userMessage)
    AIAgentDrawer->>apiClient: explainPoi(poiId, context)
    apiClient->>guideRoutes: POST /api/guide/explain-poi
    guideRoutes->>guideService: explainPoi(poiId, userContext)
    guideService->>guideService: 获取POI信息和内容模型
    guideService-->>guideRoutes: 返回讲解内容
    guideRoutes-->>apiClient: 返回AI响应
    apiClient-->>AIAgentDrawer: 显示AI回答
    AIAgentDrawer->>agentStore: addMessage(conversationId, aiMessage)
```

---

## 🎯 核心景点与数据

### 红色文化景点 (6个)
| POI ID | 名称 | 坐标 | 特色描述 |
|---------|------|------|----------|
| poi_donglired_xinhaijinianguan001 | 辛亥革命纪念馆 | 118.205, 25.234 | 郑玉指事迹展示 |
| poi_donglired_jingyizhuang001 | 旌义状石碑 | 118.206, 25.234 | 孙中山旌义状 |
| poi_red_guntou | 古炮楼 | 118.209, 25.231 | 明代抗倭防御工事 |
| poi_red_jiqing | 集庆廊桥 | 118.205, 25.232 | 典型闽南建筑风格 |
| poi_red_yangwei | 洋杆尾古民居 | 118.207, 25.235 | 革命烈士故居 |
| poi_red_wanzhu | 昭灵宫 | 118.205, 25.234 | 村民信仰场所 |

### 生态景点 (5个)
| POI ID | 名称 | 坐标 | 特色描述 |
|---------|------|------|----------|
| poi_ecology_xianling | 仙灵瀑布 | 118.199, 25.230 | 120米落差的壮观瀑布 |
| poi_ecology_doumo | 豆磨古寨 | 118.211, 25.237 | 明代抗倭遗址 |
| poi_ecology_shuiku | 东里水库 | 118.202, 25.237 | 村内主要水源地 |
| poi_ecology_farm | 功能农业基地 | 118.203, 25.231 | 种植防癌作物 |
| poi_basic_yth | 油桐花海 | 118.204, 25.238 | 春季油桐花开景观 |

### 主题路线 (4条)
| 路线ID | 名称 | 时长 | 难度 | 景点数量 | 类型 |
|---------|------|------|--------|--------|------|
| route_red_light | 红色革命轻量级路线 | 240分钟 | 简单 | 6个 | red_culture |
| route_red_full | 红色革命一日游路线 | 480分钟 | 中等 | 10个 | red_culture |
| route_eco_half | 生态民俗休闲半日路线 | 240分钟 | 简单 | 5个 | eco_culture |
| route_eco_full | 生态民俗文化一日路线 | 480分钟 | 中等 | 8个 | eco_culture |

---

## 🛠️ 开发环境与部署

### 开发环境要求
```bash
# 前端环境
Node.js >= 18.0.0
npm >= 8.0.0

# 后端环境
Node.js >= 18.0.0
SQLite >= 3.0.0

# 开发工具
Vite >= 4.0.0
TypeScript >= 5.0.0
```

### 启动命令
```bash
# 前端开发
cd c:/Users/USER088226/Desktop/beifen
npm install
npm run dev

# 后端开发
cd c:/Users/USER088226/Desktop/beifen/backend
npm install
npm run dev

# 移动端打包
npx cap sync android
npx cap sync ios
```

### 环境配置
```bash
# 后端环境变量
PORT=3000
CORS_ORIGIN=http://localhost:5173
JWT_SECRET=your-secret-key
DATABASE_PATH=./data/dongli_tourism.sqlite
```

---

## 📱 多端支持架构

### Capacitor 配置
| 配置项 | 值 | 说明 |
|--------|---|------|
| appId | com.dongli.tourism | 应用唯一标识 |
| appName | 东里村AI导览 | 应用名称 |
| webDir | dist | Web构建目录 |
| server | { android: { scheme: 'https' } } | 服务器配置 |

### 平台特性
| 平台 | 支持特性 | 打包方式 |
|------|----------|----------|
| Web | 完整功能 | Vite构建 |
| Android | GPS、相机、文件访问 | Android Studio |
| iOS | GPS、相机、文件访问 | Xcode |

---

## 🔐 安全与认证

### JWT认证流程
1. 用户登录获得token
2. token存储在localStorage
3. 后续API请求携带Authorization头
4. token过期自动跳转登录

### 数据安全措施
- SQL注入防护：参数化查询
- XSS防护：输入验证和转义
- CSRF防护：CORS配置
- 文件上传安全：类型验证和大小限制

---

## 📈 性能监控

### 前端性能指标
- 页面加载时间 < 3秒
- API响应时间 < 500ms
- 组件渲染时间 < 100ms

### 后端性能指标
- 数据库查询时间 < 100ms
- API接口响应时间 < 300ms
- 并发用户支持 > 100

### 监控端点
- GET `/health` - 服务健康检查
- 错误日志记录到控制台
- 数据库连接状态监控

---

## 🎯 开发指南

### 添加新功能流程
1. 在`src/types/index.ts`中定义类型
2. 在`src/store/`中添加状态管理
3. 在`src/services/api.ts`中添加API方法
4. 在`backend/routes/`中添加路由处理
5. 在`backend/models/`中添加数据库操作

### 代码规范
- TypeScript严格模式
- ESLint代码检查
- 组件采用函数式编程
- 使用语义化的变量命名

### Git工作流
```bash
# 功能分支开发
git checkout -b feature/new-feature
git add .
git commit -m "feat: add new feature"
git push origin feature/new-feature
```

---

## 🚀 部署架构

### 开发环境
- 前端：`http://localhost:5173`
- 后端：`http://localhost:3000`
- 数据库：本地SQLite文件

### 生产环境
- 前端：静态文件部署到CDN
- 后端：Node.js服务器部署
- 数据库：SQLite文件或迁移到PostgreSQL

### 备份策略
- 数据库定期备份
- 代码Git版本控制
- 配置文件环境变量管理

---

**最后更新**: 2025年11月18日  
**架构版本**: v1.0.0  
**文档维护**: 开发团队

---

*此架构文档为工程师提供了完整的技术栈概览、数据流向图和开发指南，帮助快速理解项目结构和各组件间的关联关系。*

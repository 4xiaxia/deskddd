# 东里村AI导览系统API接口文档

## 1. 概述

### 1.1 接口协议
- 协议：HTTP/HTTPS
- 数据格式：JSON
- 字符编码：UTF-8
- 请求方式：GET/POST/PUT/DELETE

### 1.2 基础URL
- 开发环境：`http://localhost:3000/api`
- 生产环境：`https://api.dongli-guide.com/api`

### 1.3 通用请求头
```
Content-Type: application/json
Authorization: Bearer {token}
```

### 1.4 通用响应格式
```json
{
  "success": true,
  "data": {},
  "message": "请求成功",
  "timestamp": "2023-12-01T10:00:00.000Z"
}
```

### 1.5 通用错误响应格式
```json
{
  "success": false,
  "error": {
    "code": 400,
    "message": "错误信息"
  },
  "timestamp": "2023-12-01T10:00:00.000Z"
}
```

## 2. 用户管理接口

### 2.1 用户登录
- **接口路径**：`POST /users/login`
- **接口描述**：用户登录获取认证token
- **请求参数**：
```json
{
  "phone": "13800138000"
}
```
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
    "user": {
      "userId": "user_123456",
      "phone": "13800138000",
      "loginType": "phone",
      "createdAt": "2023-12-01T10:00:00.000Z"
    }
  },
  "message": "登录成功"
}
```

### 2.2 获取用户信息
- **接口路径**：`GET /users/profile`
- **接口描述**：获取当前登录用户信息
- **请求头**：需要Authorization
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "userId": "user_123456",
    "phone": "13800138000",
    "loginType": "phone",
    "createdAt": "2023-12-01T10:00:00.000Z",
    "lastActive": "2023-12-01T10:00:00.000Z"
  },
  "message": "获取用户信息成功"
}
```

## 3. 路线管理接口

### 3.1 获取所有路线
- **接口路径**：`GET /routes`
- **接口描述**：获取所有可游览路线
- **响应参数**：
```json
{
  "success": true,
  "data": [
    {
      "id": "route_1",
      "name": "红色革命轻量级路线",
      "description": "短小精炼的红色文化体验",
      "duration": 240,
      "distance": 5.2,
      "poiCount": 6,
      "difficulty": "easy",
      "type": "route_red",
      "openTime": "全年",
      "tips": "团队活动请提前预约讲解服务",
      "pois": [
        {
          "id": "poi_donglired_xinhaijinianguan001",
          "name": "永春辛亥革命纪念馆",
          "description": "为了弘扬郑玉指大忠大孝的精神...",
          "latitude": 25.234,
          "longitude": 118.205,
          "order": 1,
          "duration": 20,
          "images": [],
          "audioUrl": "https://...",
          "previousPoi": null,
          "nextPoi": {
            "id": "poi_donglired_jingyizhuang001",
            "name": "旌义状石碑（侨光亭内）",
            "description": "1912年孙中山亲颁'旌义状'予郑玉指...",
            "latitude": 25.234,
            "longitude": 118.206,
            "order": 2,
            "duration": 20,
            "images": [],
            "audioUrl": "https://..."
          }
        }
      ]
    }
  ],
  "message": "获取路线列表成功"
}
```

### 3.2 获取路线详情
- **接口路径**：`GET /routes/:routeId`
- **接口描述**：根据路线ID获取路线详情
- **路径参数**：
  - `routeId`: 路线唯一标识符
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "id": "route_1",
    "name": "红色革命轻量级路线",
    "description": "短小精炼的红色文化体验",
    "duration": 240,
    "distance": 5.2,
    "poiCount": 6,
    "difficulty": "easy",
    "type": "route_red",
    "openTime": "全年",
    "tips": "团队活动请提前预约讲解服务",
    "pois": [
      // 景点列表同上
    ]
  },
  "message": "获取路线详情成功"
}
```

## 4. 景点管理接口

### 4.1 获取景点详情
- **接口路径**：`GET /pois/:poiId`
- **接口描述**：根据景点ID获取景点详情
- **路径参数**：
  - `poiId`: 景点唯一标识符
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "id": "poi_donglired_xinhaijinianguan001",
    "name": "永春辛亥革命纪念馆",
    "description": "为了弘扬郑玉指大忠大孝的精神...",
    "latitude": 25.234,
    "longitude": 118.205,
    "order": 1,
    "duration": 20,
    "images": [],
    "audioUrl": "https://...",
    "location": "东里村",
    "landmark": "东里郑氏宗祠内",
    "video": "",
    "recognizable": ["青石板台阶", "老式木桌", "革命标语拓片", "煤油灯", "郑氏宗祠标识"],
    "openTime": "全年",
    "tips": "院内禁止吸烟",
    "relatedKnowledge": ["history"],
    "aiFeatures": {
      "voiceExplanation": true,
      "photoRecognition": true,
      "historicalFacts": true,
      "interactiveQa": true,
      "emotionalConnection": true,
      "culturalContext": true
    },
    "interactiveElements": [
      {
        "element": "革命文物",
        "recognitionKeywords": ["木桌", "标语拓片", "煤油灯", "历史照片"],
        "aiResponse": "AI将为您介绍这件文物的历史背景和革命意义"
      }
    ],
    "previousPoi": null,
    "nextPoi": {
      "id": "poi_donglired_jingyizhuang001",
      "name": "旌义状石碑（侨光亭内）",
      "description": "1912年孙中山亲颁'旌义状'予郑玉指...",
      "latitude": 25.234,
      "longitude": 118.206,
      "order": 2,
      "duration": 20,
      "images": [],
      "audioUrl": "https://..."
    }
  },
  "message": "获取景点详情成功"
}
```

## 5. 内容管理接口

### 5.1 上传内容
- **接口路径**：`POST /content/upload`
- **接口描述**：上传用户生成内容
- **请求头**：需要Authorization
- **表单参数**：
  - `file`: 上传的文件
  - `contentType`: 内容类型 (image, audio, text)
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "id": 1,
    "userId": "user_123456",
    "contentType": "image",
    "filePath": "/uploads/uuid_filename.jpg",
    "fileName": "uuid_filename.jpg",
    "status": "pending",
    "uploadTime": "2023-12-01T10:00:00.000Z",
    "reviewer": null
  },
  "message": "内容上传成功"
}
```

### 5.2 获取待审核内容
- **接口路径**：`GET /content/pending`
- **接口描述**：获取待审核的内容
- **请求头**：需要Authorization
- **响应参数**：
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "userId": "user_123456",
      "contentType": "image",
      "filePath": "/uploads/uuid_filename.jpg",
      "fileName": "uuid_filename.jpg",
      "status": "pending",
      "uploadTime": "2023-12-01T10:00:00.000Z",
      "reviewer": null
    }
  ],
  "message": "获取待审核内容成功"
}
```

### 5.3 审核内容
- **接口路径**：`POST /content/review/:contentId`
- **接口描述**：审核用户上传的内容
- **路径参数**：
  - `contentId`: 内容ID
- **请求头**：需要Authorization
- **请求参数**：
```json
{
  "status": "approved",
  "reason": "内容质量优秀"
}
```
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "success": true,
    "contentId": 1,
    "status": "approved"
  },
  "message": "内容审核成功"
}
```

## 6. 数据统计接口

### 6.1 记录访问
- **接口路径**：`POST /stats/record-visit`
- **接口描述**：记录用户访问景点
- **请求头**：需要Authorization
- **请求参数**：
```json
{
  "poiId": "poi_donglired_xinhaijinianguan001",
  "actionType": "view"
}
```
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "success": true,
    "recordId": 1
  },
  "message": "访问记录成功"
}
```

### 6.2 获取访问统计
- **接口路径**：`GET /stats/visit-stats`
- **接口描述**：获取访问统计数据
- **查询参数**：
  - `timeRange`: 时间范围 (24h, 7d, 30d)
- **响应参数**：
```json
{
  "success": true,
  "data": [
    {
      "date": "2023-12-01",
      "visitCount": 150,
      "uniqueVisitors": 120
    }
  ],
  "message": "获取访问统计成功"
}
```

### 6.3 获取热门景点
- **接口路径**：`GET /stats/popular-pois`
- **接口描述**：获取热门景点排行
- **查询参数**：
  - `limit`: 返回数量限制
- **响应参数**：
```json
{
  "success": true,
  "data": [
    {
      "poiId": "poi_donglired_xinhaijinianguan001",
      "name": "永春辛亥革命纪念馆",
      "visitCount": 200
    }
  ],
  "message": "获取热门景点成功"
}
```

### 6.4 获取用户访问详情
- **接口路径**：`GET /stats/user-visit-details`
- **接口描述**：获取当前用户访问详情
- **请求头**：需要Authorization
- **查询参数**：
  - `timeRange`: 时间范围 (24h, 7d, 30d)
- **响应参数**：
```json
{
  "success": true,
  "data": [
    {
      "poiId": "poi_donglired_xinhaijinianguan001",
      "name": "永春辛亥革命纪念馆",
      "images": [],
      "visitCount": 2,
      "lastVisit": "2023-12-01T10:00:00.000Z"
    }
  ],
  "message": "获取用户访问详情成功"
}
```

## 7. AI助手接口

### 7.1 语音识别
- **接口路径**：`POST /ai/speech-to-text`
- **接口描述**：将语音转换为文本
- **请求头**：需要Authorization
- **请求参数**：语音文件
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "text": "这是识别出的文本"
  },
  "message": "语音识别成功"
}
```

### 7.2 图像识别
- **接口路径**：`POST /ai/image-recognition`
- **接口描述**：识别上传的图片内容
- **请求头**：需要Authorization
- **请求参数**：图片文件
- **响应参数**：
```json
{
  "success": true,
  "data": {
    "object": "纪念碑",
    "description": "这是一个具有历史意义的纪念碑",
    "historicalInfo": "相关的历史背景信息"
  },
  "message": "图像识别成功"
}
```

## 8. 错误码说明

| 错误码 | 描述 |
|--------|------|
| 200 | 请求成功 |
| 400 | 请求参数错误 |
| 401 | 未授权访问 |
| 403 | 禁止访问 |
| 404 | 资源不存在 |
| 500 | 服务器内部错误 |
| 502 | 网关错误 |
| 503 | 服务不可用 |

## 9. 安全说明

### 9.1 认证机制
- 所有需要认证的接口都需要在请求头中包含Authorization字段
- Token有效期为24小时
- Token过期后需要重新登录获取

### 9.2 限流策略
- 单个IP地址每分钟最多请求100次
- 单个用户每小时最多上传10个文件
- 具他接口根据实际需求设置相应的限流

### 9.3 数据验证
- 所有输入参数都会进行验证
- 上传文件大小限制为10MB
- 仅支持特定格式的文件上传
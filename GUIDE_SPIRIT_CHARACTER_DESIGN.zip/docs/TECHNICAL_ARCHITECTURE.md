# 东里村AI导览系统技术架构文档

## 技术架构概述

### 架构设计原则
1. **本地优先**：核心功能不依赖网络，适应乡村弱网环境
2. **轻量高效**：资源消耗低，运行稳定可靠
3. **模块化**：功能组件解耦，便于维护和扩展
4. **安全性**：数据保护和访问控制机制完善
5. **可维护性**：代码结构清晰，文档完整

### 整体架构图
```

### 3. 内容模型与知识库协作

#### 功能职责
- 统一管理路线/景点/story 等内容的文案、图片、音频、标签等展示素材
- 把 content_modelId 作为前端、Agent、AI 调用的共享入口，确保展示与知识输出一致
- 支持状态（草稿/审核/上线）、多语言版本与多媒体资源的平滑更新

#### 数据结构（草案）
```sql
CREATE TABLE content_models (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  type TEXT CHECK(type IN ('route','poi','story')) DEFAULT 'poi',
  summary TEXT,
  tags TEXT, -- JSON 数组
  status TEXT DEFAULT 'draft',
  content_json TEXT, -- 亮点、推荐语、关键词等结构化内容
  created_by TEXT,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE media_assets (
  id TEXT PRIMARY KEY,
  content_model_id TEXT,
  media_type TEXT CHECK(media_type IN ('image','audio','video')),
  url TEXT,
  caption TEXT,
  sort_order INTEGER DEFAULT 0,
  FOREIGN KEY(content_model_id) REFERENCES content_models(id)
);

CREATE TABLE knowledge_entries (
  id TEXT PRIMARY KEY,
  content_model_id TEXT,
  knowledge_type TEXT,
  body TEXT,
  vector_id TEXT,
  FOREIGN KEY(content_model_id) REFERENCES content_models(id)
);
```

#### 协作流程
1. `routes`/`pois` 表通过 `content_model_id` 加载 `content_models` 的文案 + `media_assets` 图集；
2. Agent 调用如 `/api/guide/explain-poi` 时先取 `content_models.summary`、`media_assets` 作为展示，再根据 `knowledge_entries`+向量数据补充深度上下文；
3. 后台编辑器（`contentRoutes`）可 CRUD 整个 content model，状态变更会立即同步到前端和 Agent，而知识库只在缺失的领域回退查询；
4. 多媒体与知识可分别缓存、审核/注释，`knowledge_entries.vector_id` 可与向量数据库(Qdrant)联动提供 RAG 检索。

这种模型让“毛线团”更清晰地整理路线/POI 内容脉络，同时保持内容展示与知识问答的层次分明。

#### 流程示意 (Mermaid)
```mermaid
flowchart LR
  ROUTE[路线路由] --> CM[content_models]
  POI[景点明细] --> CM
  CM --> MA[media_assets]
  CM --> KE[knowledge_entries]
  GUIDE[/api/guide/explain-poi] --> EXPLANATION[AI 讲解]
  CM --> EXPLANATION
  KE --> EXPLANATION
```
┌─────────────────────────────────────────────────────────────┐
│                    前端应用层 (React/TypeScript)            │
├─────────────────────────────────────────────────────────────┤
│                    HTTP API层                               │
├─────────────────────────────────────────────────────────────┤
│ 业务逻辑层 (TypeScript/Node.js)                             │
│  ├─────────────┬─────────────┬─────────────┬─────────────┤  │
│  │ 用户管理    │ 内容处理    │ 数据统计    │ AI服务      │  │
│  └─────────────┴─────────────┴─────────────┴─────────────┘  │
├─────────────────────────────────────────────────────────────┤
│ 服务集成层                                                  │
│  ├─────────────┬─────────────┬─────────────┬─────────────┤  │
│  │ 本地数据库  │ AI模型API   │ 文件存储    │ 缓存服务    │  │
│  └─────────────┴─────────────┴─────────────┴─────────────┘  │
└─────────────────────────────────────────────────────────────┘
```

## 技术栈选型

### 1. 前端技术栈

#### 核心框架
- **React 18+**：构建用户界面的核心库
- **TypeScript**：提供类型安全和开发体验
- **Fetch API**：与Node.js后端通信的接口

#### UI组件库
- **TailwindCSS**：实用工具优先的CSS框架
- **Headless UI**：无样式UI组件库
- **Chart.js**：数据可视化图表库

#### 状态管理
- **Zustand**：轻量级状态管理解决方案
- **Wouter**：轻量级路由管理

#### 构建工具
- **Vite**：快速构建工具
- **ESLint**：代码质量检查
- **Prettier**：代码格式化

### 2. 后端技术栈

#### 核心语言与框架
- **Node.js**：JavaScript运行时环境
- **Express**：Web应用框架
- **TypeScript**：提供类型安全和开发体验

#### 数据库技术
- **SQLite**：轻量级嵌入式关系数据库
- **Redis**：内存缓存系统（可选）

#### AI服务集成
- **SiliconFlow API**：统一AI服务提供商
- **智谱AI API**：备用AI服务提供商
- **Axios**：HTTP客户端库

#### 工具库
- **node-sqlite3**：SQLite数据库操作库
- **multer**：文件上传中间件
- **bcrypt**：密码哈希处理
- **jsonwebtoken**：JWT令牌处理
- **uuid**：生成唯一标识符

### 3. 开发工具链

#### 版本控制
- **Git**：分布式版本控制系统
- **GitHub**：代码托管平台

#### 包管理
- **npm**：Node.js包管理器

#### 测试框架
- **Jest**：JavaScript测试框架

#### CI/CD
- **GitHub Actions**：自动化构建和部署

## 系统模块设计

### 1. 用户管理模块

#### 功能职责
- 用户注册/登录验证
- 用户信息管理
- 权限控制
- 会话管理

#### 技术实现
```javascript
// 用户模型定义
interface User {
    id: number;
    userId: string;
    phone?: string;
    loginType: string;
    createdAt: string;
    lastActive: string;
}

// 用户服务实现
class UserService {
    private db: any; // 数据库连接

    async createUser(userData: CreateUserRequest): Promise<User> {
        // 实现用户创建逻辑
    }
    
    async authenticateUser(loginData: LoginRequest): Promise<AuthResponse> {
        // 实现用户认证逻辑
    }
}
```

#### 数据库表结构
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT UNIQUE NOT NULL,
    phone TEXT,
    login_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP
);
```

### 2. 内容处理模块

#### 功能职责
- 农民内容上传处理
- 内容质量控制
- 文件格式转换
- 内容审核流程

#### 技术实现
```javascript
// 内容处理服务
class ContentService {
    private db: any; // 数据库连接
    private fileStorage: any; // 文件存储
    private qualityChecker: any; // 质量检查器

    async uploadContent(content: ContentUpload): Promise<ContentResponse> {
        // 文件验证
        this.validateFile(content.fileData);
        
        // 内容预处理
        const processedContent = this.preprocessContent(content);
        
        // 质量评分
        const qualityScore = this.qualityChecker.evaluate(processedContent);
    user_id TEXT NOT NULL,
    content_type TEXT NOT NULL,
    file_path TEXT,
    status TEXT DEFAULT 'pending',
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    review_time TIMESTAMP,
    reviewer TEXT,
    quality_score REAL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id),
    INDEX idx_content_type (content_type),
    INDEX idx_status (status)
);
```

### 3. 导航定位模块

#### 功能职责
- GPS坐标处理
- 地标导航参考
- 路线规划算法
- 离线地图支持

#### 技术实现
```javascript
// 坐标处理服务
class NavigationService {
    private poiRepository: any; // POI仓库
    private routePlanner: any; // 路线规划器

    calculateDistance(coord1: Coordinate, coord2: Coordinate): number {
        // 使用Haversine公式计算距离
        const lat1 = coord1.lat * Math.PI / 180;
        const lat2 = coord2.lat * Math.PI / 180;
        const deltaLat = (coord2.lat - coord1.lat) * Math.PI / 180;
        const deltaLng = (coord2.lng - coord1.lng) * Math.PI / 180;
        
        const a = Math.sin(deltaLat / 2) * Math.sin(deltaLat / 2) +
                Math.cos(lat1) * Math.cos(lat2) * Math.sin(deltaLng / 2) * Math.sin(deltaLng / 2);
        const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        const EARTH_RADIUS = 6371; // 地球半径（公里）
        return EARTH_RADIUS * c;
    }
    
    getNearbyPois(userCoord: Coordinate, radius: number): Poi[] {
        const allPois = this.poiRepository.getAll();
        return allPois.filter(poi => this.calculateDistance(userCoord, poi.coord) <= radius);
    }
}
```

#### 数据库表结构
```sql
CREATE TABLE pois (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    poi_id TEXT UNIQUE NOT NULL,
    route_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    coord_lat REAL,
    coord_lng REAL,
    images TEXT,
    audio_url TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(route_id),
    INDEX idx_route_id (route_id),
    INDEX idx_poi_id (poi_id)
);
```

### 4. AI服务模块

#### 功能职责
- 语音识别与合成
- 图像识别处理
- 自然语言处理
- 智能推荐算法

#### 技术实现
```javascript
// AI服务管理器
class AIServiceManager {
    private apiClient: any; // API客户端
    private localCache: any; // 本地缓存

    async processVoiceQuery(audioData: Buffer): Promise<string> {
        // 1. 语音识别
        const text = await this.speechToText(audioData);
        
        // 2. 语义理解
        const intent = await this.understandIntent(text);
        
        // 3. 生成回答
        const response = await this.generateResponse(intent);
        
        return response;
    }
    
    async recognizeImage(imageData: Buffer): Promise<RecognitionResult> {
        // 调用AI图像识别API
        const result = await this.apiClient.post("/image/recognize", {
            image_data: imageData.toString('base64')
        });
        return result.data;
    }
}
```

### 5. 数据统计模块

#### 功能职责
- 实时数据收集
- 统计分析计算
- 报表生成
- 热力图数据处理

#### 技术实现
```javascript
// 数据收集器
class DataCollector {
    private db: any; // 数据库连接
    private cache: any; // 缓存客户端

    async recordVisit(visit: VisitRecord): Promise<void> {
        // 1. 存储到数据库
        await this.db.insertVisitRecord(visit);
        
        // 2. 更新缓存统计
        await this.cache.incr(`visits:${visit.spotId}`);
        
        // 3. 实时处理
        await this.processRealtimeStats(visit);
    }
    
    async generateHeatmap(timeRange: TimeRange): Promise<HeatmapPoint[]> {
        const visits = await this.db.getVisitsInRange(timeRange);
        
        // 聚合数据生成热力图点
        const heatmapPoints: HeatmapPoint[] = [];
        const groupedVisits = this.groupBy(visits, 'spotId');
        for (const [spotId, group] of Object.entries(groupedVisits)) {
            const count = (group as VisitRecord[]).length;
            const spot = await this.db.getPoi(spotId);
            heatmapPoints.push({
                spotId,
                lat: spot.coord.lat,
                lng: spot.coord.lng,
                visitCount: count,
                density: this.calculateDensity(count),
            });
        }
        return heatmapPoints;
    }
}
```

#### 数据库表结构
```sql
CREATE TABLE visitor_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    spot_id TEXT NOT NULL,
    visit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    duration INTEGER,
    action_type TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id),
    INDEX idx_spot_id (spot_id),
    INDEX idx_visit_time (visit_time)
);
```

## 数据库设计

### 1. 核心表结构

#### 用户表(users)
```sql
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT UNIQUE NOT NULL,
    phone TEXT,
    login_type TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    last_active TIMESTAMP,
    INDEX idx_user_id (user_id),
    INDEX idx_phone (phone)
);
```

#### 内容上传表(content_uploads)
```sql
CREATE TABLE content_uploads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    content_type TEXT NOT NULL,
    file_path TEXT,
    status TEXT DEFAULT 'pending',
    upload_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    review_time TIMESTAMP,
    reviewer TEXT,
    quality_score REAL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id),
    INDEX idx_content_type (content_type),
    INDEX idx_status (status)
);
```

#### 访客记录表(visitor_records)
```sql
CREATE TABLE visitor_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    spot_id TEXT NOT NULL,
    visit_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    duration INTEGER,
    action_type TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id),
    INDEX idx_spot_id (spot_id),
    INDEX idx_visit_time (visit_time)
);
```

### 2. 性能优化策略
- 合理使用索引提升查询性能
- 分表分库处理大数据量
- 缓存热点数据减少数据库访问
- 定期清理过期数据

## API接口设计

### 1. RESTful设计原则
- 使用HTTP动词表示操作类型(GET/POST/PUT/DELETE)
- URL路径表示资源
- 返回标准HTTP状态码
- JSON格式数据交换

### 2. 主要API接口

#### 用户管理接口
```
POST /api/v1/users/login
GET /api/v1/users/{user_id}
PUT /api/v1/users/{user_id}
```

#### 内容管理接口
```
POST /api/v1/content/upload
GET /api/v1/content/{content_id}
PUT /api/v1/content/{content_id}/review
```

#### 数据统计接口
```
GET /api/v1/dashboard/stats
GET /api/v1/dashboard/heatmap
GET /api/v1/dashboard/visitor-details
```

### 3. 接口-前端钩子映射表

| 前端调用位置 | REST 接口 | 请求负载 / 参数 | 核心返回 & 处理 | 业务服务 | 备注 |
| --- | --- | --- | --- | --- | --- |
| `useAuthStore.login` / `LoginPage` | `POST /api/users/login` | `{ phone }` | 返回 `{ user, token }`，`authStore` 保存 token 并设置 `apiClient.setToken` | `userRoutes` + `authService` | JWT 存 `localStorage`；需验证 `JWT_SECRET` |
| `RoutesPage`, `SpiritGreeting` | `GET /api/routes` | 无 | 返回线路列表并预热推荐数据 | `routeRoutes` + `routeService` | 可加 `cacheMiddleware` 防止高频请求 |
| `RouteDetailPage` | `GET /api/routes/:routeId` | 路径参数 `routeId` | 路线详情 + POI 序列 | `routeRoutes` + `routeService` | 同步预加载 POI 数据 |
| `POIDetailPage` | `GET /api/pois/:poiId` | `poiId` | POI 信息（名称、说明、坐标、音频） | `poiRoutes` + `routeService` | GPS/导航 Hook 使用 |
| `recordVisit` Hook / `AIAgentDrawer` | `POST /api/stats/record-visit` | `{ poiId, actionType?, duration?, timestamp }` | 写入 `visitor_records`，返回热度摘要 | `statsRoutes` + `statsService` | 支持打卡、评分、触发热力图刷新 |
| `GuideGreeting`, `GuideRecommendation` | `POST /api/guide/greeting`、`POST /api/guide/recommend` | `timeOfDay`, `userPreference`, `route`, `userContext` | AI 语料、推荐文本、下一步建议 | `guideRoutes`, `guideService`, `recommendationService` | 失败时降级为默认模板或缓存 |
| `ContentUploader` | `POST /api/content/upload` (FormData) | `file`, `contentType` | 上传记录、审核状态、返回 `contentId` | `contentRoutes` + `contentService` | `multer` 保存到 `backend/uploads`，后端返回访问链接 |
| `StatsPage` | `GET /api/stats/visit-stats`, `GET /api/stats/popular-pois` | 可选 `timeRange`, `limit` | 热力图与用户行为数据 | `statsRoutes` + `statsService` | 支持 `node-cache` 命中，提高查询性能 |

### 3. 错误处理
```javascript
interface APIError {
    code: number;
    message: string;
    details?: any;
}

function notFound(msg: string): APIError {
    return {
        code: 404,
        message: msg,
        details: undefined
    };
}

function validationError(msg: string): APIError {
    return {
        code: 400,
        message: msg,
        details: undefined
    };
}
```

## 安全设计

### 1. 数据安全
- 敏感数据加密存储(AES-256)
- 用户密码哈希处理(bcrypt)
- 数据传输SSL/TLS加密
- 访问日志完整记录

### 2. 访问控制
- JWT Token身份验证
- RBAC权限管理模型
- API访问频率限制
- 敏感操作二次确认

### 3. 应用安全
- 防止SQL注入攻击
- XSS攻击防护
- CSRF攻击防护
- 文件上传安全检查

## 性能优化

### 1. 前端优化
- 代码分割和懒加载
- 图片懒加载和压缩
- 缓存策略优化
- PWA离线支持

### 2. 后端优化
- 数据库查询优化
- 缓存热点数据
- 异步处理耗时操作
- 连接池管理

### 3. 网络优化
- CDN加速静态资源
- HTTP/2协议支持
- 压缩传输数据
- 减少HTTP请求数量
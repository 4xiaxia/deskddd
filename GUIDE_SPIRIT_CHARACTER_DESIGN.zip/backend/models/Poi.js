const db = require('../models/db');

class PoiService {
  // 根据ID获取景点详情
  static async getPoiById(poiId) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM pois WHERE poi_id = ?';
      db.get(sql, [poiId], (err, row) => {
        if (err) {
          return reject(err);
        }
        if (row) {
          // 解析JSON字段
          const poi = {
            ...row,
            coord: row.coord ? JSON.parse(row.coord) : null,
            images: row.images ? JSON.parse(row.images) : []
          };
          resolve(poi);
        } else {
          resolve(null);
        }
      });
    });
  }
  
  // 获取相邻的景点
  static async getAdjacentPois(routeId, currentPoiId) {
    return new Promise((resolve, reject) => {
      // 先获取当前景点的排序号
      const getCurrentSql = 'SELECT sort_order FROM pois WHERE poi_id = ? AND route_id = ?';
      db.get(getCurrentSql, [currentPoiId, routeId], (err, currentPoi) => {
        if (err) {
          return reject(err);
        }
        
        if (!currentPoi) {
          return resolve({ previous: null, next: null });
        }
        
        const currentSortOrder = currentPoi.sort_order;
        
        // 获取前一个景点
        const getPreviousSql = 'SELECT * FROM pois WHERE route_id = ? AND sort_order < ? ORDER BY sort_order DESC LIMIT 1';
        const getNextSql = 'SELECT * FROM pois WHERE route_id = ? AND sort_order > ? ORDER BY sort_order ASC LIMIT 1';
        
        Promise.all([
          new Promise((resolve, reject) => {
            db.get(getPreviousSql, [routeId, currentSortOrder], (err, row) => {
              if (err) return reject(err);
              if (row) {
                const poi = {
                  ...row,
                  coord: row.coord ? JSON.parse(row.coord) : null,
                  images: row.images ? JSON.parse(row.images) : []
                };
                resolve(poi);
              } else {
                resolve(null);
              }
            });
          }),
          new Promise((resolve, reject) => {
            db.get(getNextSql, [routeId, currentSortOrder], (err, row) => {
              if (err) return reject(err);
              if (row) {
                const poi = {
                  ...row,
                  coord: row.coord ? JSON.parse(row.coord) : null,
                  images: row.images ? JSON.parse(row.images) : []
                };
                resolve(poi);
              } else {
                resolve(null);
              }
            });
          })
        ]).then(([previous, next]) => {
          resolve({ previous, next });
        }).catch(reject);
      });
    });
  }
}

module.exports = PoiService;
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');
const config = require('../config');

class UserService {
  // 用户登录
  static async login(phone) {
    return new Promise((resolve, reject) => {
      // 查找用户
      const findUserSql = 'SELECT * FROM users WHERE phone = ?';
      db.get(findUserSql, [phone], (err, user) => {
        if (err) {
          return reject(err);
        }
        
        if (user) {
          // 更新最后活跃时间
          const updateSql = 'UPDATE users SET last_active = datetime("now") WHERE user_id = ?';
          db.run(updateSql, [user.user_id], (err) => {
            if (err) {
              console.error('更新用户活跃时间失败:', err);
            }
          });
          
          // 生成JWT token
          const token = jwt.sign(
            { userId: user.user_id, phone: user.phone },
            config.JWT_SECRET,
            { expiresIn: '24h' }
          );
          
          resolve({
            user: {
              userId: user.user_id,
              phone: user.phone,
              loginType: user.login_type,
              createdAt: user.created_at
            },
            token
          });
        } else {
          // 创建新用户
          const userId = uuidv4();
          const createSql = 'INSERT INTO users (user_id, phone, login_type) VALUES (?, ?, ?)';
          db.run(createSql, [userId, phone, 'phone'], function(err) {
            if (err) {
              return reject(err);
            }
            
            // 生成JWT token
            const token = jwt.sign(
              { userId, phone },
              config.JWT_SECRET,
              { expiresIn: '24h' }
            );
            
            resolve({
              user: {
                userId,
                phone,
                loginType: 'phone',
                createdAt: new Date().toISOString()
              },
              token
            });
          });
        }
      });
    });
  }
  
  // 获取用户信息
  static async getUserById(userId) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM users WHERE user_id = ?';
      db.get(sql, [userId], (err, user) => {
        if (err) {
          return reject(err);
        }
        resolve(user);
      });
    });
  }
  
  // 验证JWT token
  static verifyToken(token) {
    try {
      return jwt.verify(token, config.JWT_SECRET);
    } catch (error) {
      return null;
    }
  }
}

module.exports = UserService;
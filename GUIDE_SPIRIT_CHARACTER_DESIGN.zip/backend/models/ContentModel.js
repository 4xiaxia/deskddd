const { v4: uuidv4 } = require('uuid');
const db = require('./db');

class ContentModelService {
  static async getAll() {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM content_models ORDER BY updated_at DESC';
      db.all(sql, [], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }

  static async getById(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM content_models WHERE id = ?';
      db.get(sql, [id], (err, row) => {
        if (err) return reject(err);
        resolve(row);
      });
    });
  }

  static async upsert(model) {
    return new Promise((resolve, reject) => {
      const id = model.id || uuidv4();
      const existsSql = 'SELECT id FROM content_models WHERE id = ?';
      db.get(existsSql, [id], (err, row) => {
        if (err) return reject(err);
        if (row) {
          const updateSql = `UPDATE content_models SET title = ?, type = ?, summary = ?, tags = ?, status = ?, content_json = ?, created_by = ?, updated_at = datetime('now') WHERE id = ?`;
          db.run(updateSql, [
            model.title,
            model.type || 'poi',
            model.summary || null,
            model.tags || null,
            model.status || 'draft',
            model.content_json || null,
            model.created_by || null,
            id
          ], (updateErr) => {
            if (updateErr) return reject(updateErr);
            resolve({ id, ...model });
          });
        } else {
          const insertSql = `INSERT INTO content_models (id, title, type, summary, tags, status, content_json, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`;
          db.run(insertSql, [
            id,
            model.title,
            model.type || 'poi',
            model.summary || null,
            model.tags || null,
            model.status || 'draft',
            model.content_json || null,
            model.created_by || null
          ], (insertErr) => {
            if (insertErr) return reject(insertErr);
            resolve({ id, ...model });
          });
        }
      });
    });
  }

  static async addMedia(id, asset) {
    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO media_assets (id, content_model_id, media_type, url, caption, sort_order) VALUES (?, ?, ?, ?, ?, ?)`;
      db.run(sql, [
        uuidv4(),
        id,
        asset.media_type,
        asset.url,
        asset.caption || null,
        asset.sort_order || 0
      ], (err) => {
        if (err) return reject(err);
        resolve({ success: true });
      });
    });
  }

  static async getMedia(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM media_assets WHERE content_model_id = ? ORDER BY sort_order ASC';
      db.all(sql, [id], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }

  static async addKnowledge(id, entry) {
    return new Promise((resolve, reject) => {
      const sql = `INSERT INTO knowledge_entries (id, content_model_id, knowledge_type, body, vector_id) VALUES (?, ?, ?, ?, ?)`;
      db.run(sql, [
        uuidv4(),
        id,
        entry.knowledge_type,
        entry.body,
        entry.vector_id || null
      ], (err) => {
        if (err) return reject(err);
        resolve({ success: true });
      });
    });
  }

  static async getKnowledge(id) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM knowledge_entries WHERE content_model_id = ?';
      db.all(sql, [id], (err, rows) => {
        if (err) return reject(err);
        resolve(rows);
      });
    });
  }
}

module.exports = ContentModelService;

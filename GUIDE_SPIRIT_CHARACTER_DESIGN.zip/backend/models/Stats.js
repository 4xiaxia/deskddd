const db = require('../models/db');

class StatsService {
  // 记录用户访问景点
  static async recordVisit(userId, poiId, actionType = 'view') {
    return new Promise((resolve, reject) => {
      const sql = 'INSERT INTO visitor_records (user_id, poi_id, action_type) VALUES (?, ?, ?)';
      db.run(sql, [userId, poiId, actionType], function(err) {
        if (err) {
          return reject(err);
        }
        resolve({ success: true, recordId: this.lastID });
      });
    });
  }
  
  // 获取访问统计
  static async getVisitStats(timeRange = '7d') {
    return new Promise((resolve, reject) => {
      let dateCondition = '';
      switch (timeRange) {
        case '24h':
          dateCondition = 'AND visit_time >= datetime("now", "-1 day")';
          break;
        case '7d':
          dateCondition = 'AND visit_time >= datetime("now", "-7 days")';
          break;
        case '30d':
          dateCondition = 'AND visit_time >= datetime("now", "-30 days")';
          break;
        default:
          dateCondition = '';
      }
      
      const sql = `
        SELECT 
          date(visit_time) as date,
          count(*) as visitCount,
          count(DISTINCT user_id) as uniqueVisitors
        FROM visitor_records 
        WHERE 1=1 ${dateCondition}
        GROUP BY date(visit_time)
        ORDER BY date
      `;
      
      db.all(sql, [], (err, rows) => {
        if (err) {
          return reject(err);
        }
        resolve(rows);
      });
    });
  }
  
  // 获取热门景点排行
  static async getPopularPois(limit = 10) {
    return new Promise((resolve, reject) => {
      const sql = `
        SELECT 
          p.poi_id,
          p.name,
          COUNT(*) as visitCount
        FROM visitor_records vr
        JOIN pois p ON vr.poi_id = p.poi_id
        GROUP BY p.poi_id, p.name
        ORDER BY visitCount DESC
        LIMIT ?
      `;
      
      db.all(sql, [limit], (err, rows) => {
        if (err) {
          return reject(err);
        }
        resolve(rows);
      });
    });
  }
  
  // 获取用户访问详情
  static async getUserVisitDetails(userId, timeRange = '7d') {
    return new Promise((resolve, reject) => {
      let dateCondition = '';
      switch (timeRange) {
        case '24h':
          dateCondition = 'AND vr.visit_time >= datetime("now", "-1 day")';
          break;
        case '7d':
          dateCondition = 'AND vr.visit_time >= datetime("now", "-7 days")';
          break;
        case '30d':
          dateCondition = 'AND vr.visit_time >= datetime("now", "-30 days")';
          break;
        default:
          dateCondition = '';
      }
      
      const sql = `
        SELECT 
          p.poi_id,
          p.name,
          p.images,
          COUNT(*) as visitCount,
          MAX(vr.visit_time) as lastVisit
        FROM visitor_records vr
        JOIN pois p ON vr.poi_id = p.poi_id
        WHERE vr.user_id = ? ${dateCondition}
        GROUP BY p.poi_id, p.name, p.images
        ORDER BY lastVisit DESC
      `;
      
      db.all(sql, [userId], (err, rows) => {
        if (err) {
          return reject(err);
        }
        // 解析JSON字段
        const results = rows.map(row => ({
          ...row,
          images: row.images ? JSON.parse(row.images) : []
        }));
        resolve(results);
      });
    });
  }
}

module.exports = StatsService;
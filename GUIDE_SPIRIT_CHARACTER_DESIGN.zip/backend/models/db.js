const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const fs = require('fs');

// 确保数据目录存在
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// 数据库文件路径
const dbPath = path.join(dataDir, 'dongli.db');

// 创建数据库连接
const db = new sqlite3.Database(dbPath, (err) => {
  if (err) {
    console.error('数据库连接失败:', err.message);
  } else {
    console.log('已连接到SQLite数据库');
    
    // 启用外键约束
    db.run('PRAGMA foreign_keys = ON');
    
    // 初始化数据库表
    initDatabase();
  }
});

// 初始化数据库表
function initDatabase() {
  const schemaPath = path.join(__dirname, '..', 'data', 'schema.sql');
  
  fs.readFile(schemaPath, 'utf8', (err, data) => {
    if (err) {
      console.error('读取数据库模式文件失败:', err.message);
      return;
    }
    
    // 分割SQL语句并执行
    const statements = data.split(';').filter(stmt => stmt.trim() !== '');
    
    db.serialize(() => {
      statements.forEach((statement, index) => {
        const trimmedStmt = statement.trim();
        if (trimmedStmt) {
          db.run(trimmedStmt, (err) => {
            if (err) {
              // 如果是索引或外键错误，可以忽略（可能已存在）
              if (!err.message.includes('already exists') && 
                  !err.message.includes('foreign key constraint')) {
                console.error(`执行SQL语句 ${index + 1} 失败:`, err.message);
              }
            }
          });
        }
      });
    });
    
    console.log('数据库初始化完成');
  });
}

module.exports = db;
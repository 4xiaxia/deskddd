module.exports = {
  // 服务器端口
  PORT: process.env.PORT || 3000,
  
  // 数据库配置
  DATABASE_PATH: './data/dongli_tourism.sqlite',
  
  // JWT密钥
  JWT_SECRET: process.env.JWT_SECRET || 'dongli-ai-tour-secret-key',
  
  // 文件上传配置
  UPLOAD_PATH: './uploads',
  
  // CORS配置
  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173'
};
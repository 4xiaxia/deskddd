const PoiService = require('../models/Poi');
const RouteService = require('../models/Route');
const ContentModelService = require('../models/ContentModel');

class GuideService {
  static async explainPoi(poiId, userContext = {}) {
    const poi = await PoiService.getPoiById(poiId);
    if (!poi) {
      throw new Error('POI not found');
    }

    let contentModelId = poi.content_model_id;
    if (!contentModelId) {
      const route = await RouteService.getRouteById(poi.route_id);
      contentModelId = route?.content_model_id;
    }

    let contentModel = null;
    let media = [];
    let knowledge = [];

    if (contentModelId) {
      contentModel = await ContentModelService.getById(contentModelId);
      [media, knowledge] = await Promise.all([
        ContentModelService.getMedia(contentModelId),
        ContentModelService.getKnowledge(contentModelId),
      ]);
    }

    return {
      poi,
      summary: contentModel?.summary || poi.description || '',
      media,
      knowledge,
      userContext,
      timestamp: new Date().toISOString(),
    };
  }
}

module.exports = GuideService;

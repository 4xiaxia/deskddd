const express = require('express');
const GuideService = require('../services/guideService');
const { verifyToken } = require('../utils/auth');

const router = express.Router();

router.post('/explain-poi', verifyToken, async (req, res) => {
  try {
    const userId = req.userId;
    const { poiId, userContext } = req.body;

    if (!poiId) {
      return res.status(400).json({ error: 'poiId 为空' });
    }

    const explanation = await GuideService.explainPoi(poiId, {
      ...userContext,
      userId,
    });
    res.json(explanation);
  } catch (error) {
    console.error('Explain POI error:', error);
    res.status(500).json({ error: '生成讲解失败' });
  }
});

module.exports = router;

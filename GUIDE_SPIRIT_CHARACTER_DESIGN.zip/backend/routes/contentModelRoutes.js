const express = require('express');
const ContentModelService = require('../models/ContentModel');
const router = express.Router();

router.get('/', async (req, res) => {
  try {
    const models = await ContentModelService.getAll();
    res.json(models);
  } catch (error) {
    console.error('获取内容模型列表失败:', error);
    res.status(500).json({ error: '获取内容模型失败' });
  }
});

router.get('/:modelId', async (req, res) => {
  try {
    const model = await ContentModelService.getById(req.params.modelId);
    if (!model) {
      return res.status(404).json({ error: '内容模型不存在' });
    }

    const [media, knowledge] = await Promise.all([
      ContentModelService.getMedia(model.id),
      ContentModelService.getKnowledge(model.id),
    ]);

    res.json({ ...model, media, knowledge });
  } catch (error) {
    console.error('获取内容模型失败:', error);
    res.status(500).json({ error: '获取内容模型失败' });
  }
});

router.post('/', async (req, res) => {
  try {
    const model = req.body;
    if (!model.title) {
      return res.status(400).json({ error: '标题不能为空' });
    }

    const saved = await ContentModelService.upsert(model);
    res.json(saved);
  } catch (error) {
    console.error('保存内容模型失败:', error);
    res.status(500).json({ error: '保存失败' });
  }
});

router.post('/:modelId/media', async (req, res) => {
  try {
    const asset = req.body;
    await ContentModelService.addMedia(req.params.modelId, asset);
    res.json({ success: true });
  } catch (error) {
    console.error('添加媒体失败:', error);
    res.status(500).json({ error: '添加媒体失败' });
  }
});

router.get('/:modelId/media', async (req, res) => {
  try {
    const media = await ContentModelService.getMedia(req.params.modelId);
    res.json(media);
  } catch (error) {
    console.error('获取媒体失败:', error);
    res.status(500).json({ error: '获取媒体失败' });
  }
});

router.post('/:modelId/knowledge', async (req, res) => {
  try {
    const entry = req.body;
    await ContentModelService.addKnowledge(req.params.modelId, entry);
    res.json({ success: true });
  } catch (error) {
    console.error('添加知识失败:', error);
    res.status(500).json({ error: '添加知识失败' });
  }
});

router.get('/:modelId/knowledge', async (req, res) => {
  try {
    const knowledge = await ContentModelService.getKnowledge(req.params.modelId);
    res.json(knowledge);
  } catch (error) {
    console.error('获取知识失败:', error);
    res.status(500).json({ error: '获取知识失败' });
  }
});

module.exports = router;

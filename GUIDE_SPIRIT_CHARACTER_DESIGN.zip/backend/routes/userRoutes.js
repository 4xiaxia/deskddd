const express = require('express');
const UserService = require('../models/User');
const { verifyToken } = require('../utils/auth');

const router = express.Router();

// 用户登录
router.post('/login', async (req, res) => {
  try {
    const { phone } = req.body;
    
    if (!phone) {
      return res.status(400).json({ error: '手机号不能为空' });
    }
    
    const result = await UserService.login(phone);
    res.json(result);
  } catch (error) {
    console.error('登录错误:', error);
    res.status(500).json({ error: '登录失败' });
  }
});

// 获取用户信息
router.get('/profile', verifyToken, async (req, res) => {
  try {
    const user = await UserService.getUserById(req.userId);
    if (!user) {
      return res.status(404).json({ error: '用户不存在' });
    }
    
    res.json({
      userId: user.user_id,
      phone: user.phone,
      loginType: user.login_type,
      createdAt: user.created_at,
      lastActive: user.last_active
    });
  } catch (error) {
    console.error('获取用户信息错误:', error);
    res.status(500).json({ error: '获取用户信息失败' });
  }
});

module.exports = router;
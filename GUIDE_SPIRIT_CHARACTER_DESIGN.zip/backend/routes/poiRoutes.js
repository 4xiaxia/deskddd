const express = require('express');
const PoiService = require('../models/Poi');

const router = express.Router();

// 获取景点详情
router.get('/:poiId', async (req, res) => {
  try {
    const { poiId } = req.params;
    const poi = await PoiService.getPoiById(poiId);
    
    if (!poi) {
      return res.status(404).json({ error: '景点不存在' });
    }
    
    // 获取相邻景点
    const { route_id } = poi;
    const adjacentPois = await PoiService.getAdjacentPois(route_id, poiId);
    
    res.json({
      ...poi,
      previousPoi: adjacentPois.previous,
      nextPoi: adjacentPois.next
    });
  } catch (error) {
    console.error('获取景点详情错误:', error);
    res.status(500).json({ error: '获取景点详情失败' });
  }
});

module.exports = router;
# 东里村AI导览系统（React + Node.js + Capacitor）

## 项目简介
东里村AI导览系统是一套面向乡村旅游的智能导览体验，结合 React 前端、Express 后端、SQLite 本地数据库与 Capacitor 的多端支持，在弱网络环境内也能提供自动问候、路线推荐、点位讲解、智能提问与内容审核能力。当前系统兼容 Web、Android、iOS 平台，面向游客、景区管理与内容贡献者。

## 技术栈概览
| 领域 | 技术 / 工具 | 说明 |
| --- | --- | --- |
| 前端 | React 19 + Vite + TypeScript + TailwindCSS + Wouter + Zustand | SPA 路由、状态管理、UI 统一控制；Capacitor 支持多端打包。 |
| 后端 | Node.js + Express | RESTful API，统一 `/api` 路径，中间件处理、错误统一返回、静态资源托管。 |
| 数据 | SQLite + 本地文件（uploads） | 存储用户、路线、POI、内容审核、日志等；文件上传直接写入 `backend/uploads`。 |
| 通信 | Fetch / Axios | 统一 `src/services/api.ts` 封装 HTTP 请求，自动注入 Bearer token。 |
| 多端 | Capacitor (android/ios) | 移动端打包层，可在 `android/` 和 `ios/` 目录下定制原生能力。 |

## 项目结构树 (核心目录)
```
codegpt5/
├── src/                      # React + Zustand 客户端
│   ├── App.tsx                # Wouter 路由入口 + AI Agent drawer
│   ├── store/authStore.ts     # Zustand 状态（登录、token、err）
│   ├── services/api.ts        # ApiClient 封装所有 /api 请求
│   ├── pages/
│   │   ├── LoginPage.tsx
│   │   ├── RoutesPage.tsx
│   │   ├── RouteDetailPage.tsx
│   │   └── POIDetailPage.tsx
│   └── components/
│       └── AIAgentDrawer.tsx  # 小精灵实时问答/导览面板
├── backend/
│   ├── server.js              # Express 启动 + 中间件 + 路由挂载
│   ├── routes/                # user/route/poi/content/stats 模块
│   ├── config.js              # 环境与端口配置
│   ├── data/                  # SQLite 数据库文件（可初始化）
│   └── uploads/               # 内容上传缓存
├── docs/                      # 业务文档与架构说明（待清理 Tauri 内容）
├── android/ ios/              # Capacitor 平台打包配置
├── capacitor.config.ts        # Capacitor 通用项
└── package.json、tsconfig 等 # 工程配置 + 脚本
```

## 路由与页面映射
| URL | 页面 | 说明 | 相关状态/接口 |
| --- | --- | --- | --- |
| `/login` | `LoginPage` | 手机号登录入口，验证格式后调用 `apiClient.login` | `useAuthStore.login` / `apiClient.login` |
| `/routes` | `RoutesPage` | 展示所有已发布路线，支持筛选与跳转 | `apiClient.getRoutes` |
| `/route/:routeId` | `RouteDetailPage` | 路线含 POI 列表 + 推荐话术 / 行程 | `apiClient.getRouteDetail`、`apiClient.recordVisit` |
| `/route/:routeId/poi/:poiId` | `POIDetailPage` | 单个景点讲解、故事、评分上传 | `apiClient.getPoiDetail`、`apiClient.recordVisit` |

## API 接口映射
| 接口 | 方法 | 用途 | 前端调用点 |
| --- | --- | --- | --- |
| `POST /api/users/login` | 登录 | 返回 token + 用户信息 | `ApiClient.login` ➜ `LoginPage`、`authStore` |
| `GET /api/users/profile` | 用户信息 | 用于刷新页面时获取用户数据 | `apiClient.getUserProfile` (<small>future</small>) |
| `GET /api/routes` | 路线列表 | 渲染到 `RoutesPage` | `RoutesPage` ➜ `apiClient.getRoutes` |
| `GET /api/routes/:routeId` | 单条路线 | `RouteDetailPage` + 推荐语句 | `RouteDetailPage` |
| `GET /api/pois/:poiId` | POI 详情 | `POIDetailPage` 展示 | `POIDetailPage` |
| `POST /api/stats/record-visit` | 访问记录 | AI 导游问候 + 热度统计 | `apiClient.recordVisit` |
| `/api/content/*` | 内容上传/审核 | 村民直播/图片/音频入库 | 未来内容管理界面使用 |
| `/api/content-models/:id` | 内容模型详情 | 获取亮点文案、多媒体和关联知识，供路线/景点展示与 Agent 讲解 | `RouteDetailPage`、`POIDetailPage`、`AIAgentDrawer` -> `apiClient.getContentModel` |
| `POST /api/guide/explain-poi` | AI讲解 | 直接传 `poiId` + `userContext` 触发 Agent 综合 `summary` + `media` + `knowledge`，用于实时讲解 | `GuidedPOIDetail`、`AIAgentDrawer` 的 `explainPoi` |

## 状态与数据流概要
1. **认证**：`useAuthStore` 调用 `apiClient.login` 获取 JWT，存入 `localStorage`，后续请求自动带 `Authorization`。
2. **导览数据**：线路与 POI 通过 `/api/routes` 与 `/api/pois` 获取，页面请求由 `ApiClient` 控制并处理 JSON + 错误。 
3. **AI 交互**：`AIAgentDrawer` 保持常驻，可扩展为 `/api/guide` 端点（已在文档中列出），并将导游消息同步至 `useGuideStore`。
4. **内容贡献**：`apiClient.uploadContent` 提交 `FormData` 入 `backend/routes/contentRoutes`，配合审核 API 更新状态。 
5. **日志/统计**：`recordVisit` 每次用户浏览 POI 时触发，配合 `/api/stats` 为热力图、数据分析提供原始数据。

## 开发与运行指南
### 前端（Web + Capacitor）
1. `npm install`（根目录）
2. `npm run dev` 启动 Vite 开发服务器
3. `npm run build` 构建生产包，Capacitor 可通过 `npx cap sync` 同步到移动平台

### 后端
1. 进入 `backend/`，执行 `npm install`
2. `npm run dev`（假设在 `backend/package.json` 中配置 nodemon + ts-node）
3. 默认监听 `http://localhost:3000`，与前端 `src/services/api.ts` 基本一致

### 环境变量示例
```
PORT=3000
CORS_ORIGIN=http://localhost:5173
JWT_SECRET=replace-with-secret
```

## 文档清理任务（正在进行）
- `PROJECT_SUMMARY.md`、`NEXT_PHASE_PLAN.md`、`ROUTE_POI_AI_INTEGRATION.md` 等正在替换为 React+Node 版本。
- `AI_GUIDE_FRONTEND_IMPLEMENTATION.md` 已展示如何替换 Tauri invoke 为 REST。
- `PHASE3_IMPLEMENTATION_ROADMAP.md` 已重写为 Node.js 实施路线。

## 目标与规划
1. 持续清理所有 `.md` 中的 Tauri / Rust 片段，使文档描述与现有架构一致。
2. 填充 `/api` 端点文档，明确前端路由与后端接口的映射。
3. 衔接 Capacitor 多端构建流程，确保 Android/iOS 目录可复用。

如需进一步细化流程图或模块依赖，我可以帮忙生成详尽的 markdown 图表或 mermaid 图，方便团队快速上手。
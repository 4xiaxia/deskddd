# 东里村AI导览系统 - 1.0阶段实施计划
## 🎯 核心原则

根据用户要求，制定以**"ANP调用优先、性能优化、移动端适配"**为核心的1.0阶段实施方案。

---

## 📋 项目概览

### 当前技术状态
- ✅ 前端: React 19.2.0 + TypeScript + TailwindCSS + Zustand + Wouter
- ✅ 后端: Node.js + Express + SQLite + JWT基础架构
- ⚠️ 需要优化: ANP调用、性能、移动端适配
- ⚠️ 需要砍掉功能: 社交分享、复杂功能

### 1.0阶段核心目标
1. **ANP优化**: 利用智谱AI提供智能导览服务
2. **性能提升**: 移动端优先、快速响应
3. **移动端优化**: 全触屏适配、手势优化
4. **核心功能完善**: AgentA、路线导览、景点展示

---

## 🤖 智谱AI集成方案

### 1. ANP服务架构
```typescript
// src/services/zhipuAI.ts
interface ZhipuConfig {
  apiKey: string
  baseURL: string
  models: {
    text: string      // glm-4.5-flash
    image: string    // cogview-3-flash  
    video: string    // cogvideox-flash
  }
}

class ZhipuAIService {
  private config: ZhipuConfig
  
  constructor() {
    this.config = {
      apiKey: process.env.ZHIPU_API_KEY || 'a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog',
      baseURL: 'https://open.bigmodel.cn/api/paas/v4',
      models: {
        text: 'glm-4.5-flash',
        image: 'cogview-3-flash', 
        video: 'cogvideox-flash'
      }
    }
  }

  // 核心API调用方法
  async generateText(prompt: string, options?: TextOptions): Promise<string>
  async generateImage(prompt: string, options?: ImageOptions): Promise<string>
  async generateVideo(prompt: string, options?: VideoOptions): Promise<string>
  async understandImage(imageBase64: string, prompt?: string): Promise<string>
}
}
```

### 2. AgentA智能导览实现
```typescript
// src/services/agentA.ts
export class AgentAService {
  private zhipuAI: ZhipuAIService
  private memory: Map<string, any> = new Map()

  constructor() {
    this.zhipuAI = new ZhipuAIService()
  }

  // 1. 智能景点讲解
  async explainPOI(poiId: string, userContext: UserContext): Promise<Explanation> {
    const prompt = `
      我是东里村的AI导游小A。请为景点${poiId}生成讲解。
      用户当前在: ${userContext.currentLocation}
      用户兴趣: ${userContext.interests?.join(', ')}
      
      要求:
      1. 使用温暖、亲切的语气
      2. 包含历史背景和文化内涵
      3. 突出特色和看点
      4. 提供实用游览建议
      5. 控制在200字以内
    `

    const response = await this.zhipuAI.generateText(prompt)
    return {
      text: response,
      audioUrl: await this.generateAudio(response), // ANP TTS
      emotion: this.detectEmotion(response),
      suggestions: await this.generateSuggestions(poiId, userContext)
    }
  }

  // 2. 路线推荐
  async recommendRoute(userPreferences: UserPreferences): Promise<RouteRecommendation> {
    const prompt = `
      基于用户偏好推荐东里村路线:
      
      用户兴趣: ${userPreferences.interests?.join(', ')}
      难度偏好: ${userPreferences.difficulty}
      时间偏好: ${userPreferences.timePreference}
      
      可选路线:
      - 红色革命轻量级 (3-4小时)
      - 红色革命一日游 (8小时)
      - 生态休闲半日 (3-4小时)
      - 生态民俗文化一日游 (8小时)
      
      请推荐最合适的路线，并说明推荐理由。
    `

    const response = await this.zhipuAI.generateText(prompt)
    return {
      routeId: this.extractRouteId(response),
      reason: this.extractReason(response),
      estimatedTime: this.extractTime(response),
      confidence: this.calculateConfidence(response, userPreferences)
    }
  }

  // 3. 智能对话
  async chat(message: string, conversationContext: ConversationContext): Promise<ChatResponse> {
    const prompt = `
      作为东里村AI导游小A，请回答用户问题:
      
      用户问题: ${message}
      对话上下文: ${conversationContext.summary}
      当前位置: ${conversationContext.currentLocation}
      游览进度: ${conversationContext.progress}
      
      人设要求:
      - 热情好客，像村里的导游
      - 知识渊博，了解东里村历史
      - 关心体贴，关注用户状态
      - 适当调皮，增加趣味性
      - 回答控制在100字以内
    `

    const response = await this.zhipuAI.generateText(prompt)
    return {
      text: response,
      emotion: this.detectEmotion(response),
      followUpQuestions: this.generateFollowUps(response),
      actions: this.suggestActions(response, conversationContext)
    }
  }

  // 4. 语音合成 (TTS)
  async generateAudio(text: string): Promise<string> {
    const prompt = `请用温暖、亲切的女性声音朗读以下文本: ${text}`
    
    const audioData = await this.zhipuAI.generateText(prompt)
    return await this.processAudioResponse(audioData)
  }

  // 5. 图像理解
  async analyzeImage(imageBase64: string, userQuery?: string): Promise<ImageAnalysis> {
    const prompt = `
      分析这张来自东里村的图片:
      
      图片信息: 已编码为base64
      用户问题: ${userQuery || '请描述这张图片'}
      
      分析要求:
      1. 识别图片中的景点或地标
      2. 提供相关的历史背景
      3. 给出游览建议
      4. 检测图片质量和拍摄角度
    `

    const response = await this.zhipuAI.generateImage(
      prompt,
      { model: this.config.models.image }
    )

    return {
      description: response,
      landmarks: this.extractLandmarks(response),
      suggestions: this.extractImageSuggestions(response),
      confidence: this.calculateImageConfidence(response)
    }
  }
}
```

---

## 🚀 性能优化方案

### 1. 移动端优先策略

#### 响应式设计系统
```typescript
// src/hooks/useResponsive.ts
export const useResponsive = () => {
  const [screenSize, setScreenSize] = useState({
    width: window.innerWidth,
    height: window.innerHeight,
    isMobile: window.innerWidth < 768,
    isTablet: window.innerWidth >= 768 && window.innerWidth < 1024,
    isDesktop: window.innerWidth >= 1024
  })

  useEffect(() => {
    const handleResize = () => {
      const width = window.innerWidth
      const height = window.innerHeight
      
      setScreenSize({
        width,
        height,
        isMobile: width < 768,
        isTablet: width >= 768 && width < 1024,
        isDesktop: width >= 1024
      })
    }

    window.addEventListener('resize', handleResize)
    return () => window.removeEventListener('resize', handleResize)
  }, [])

  // 返回屏幕适配的工具函数
  const getResponsiveValue = (mobile: any, tablet: any, desktop: any) => {
    if (screenSize.isMobile) return mobile
    if (screenSize.isTablet) return tablet
    return desktop
  }

  return { screenSize, getResponsiveValue }
}
```

#### TailwindCSS响应式配置
```javascript
// tailwind.config.js
module.exports = {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      screens: {
        'mobile': {'max': '767px'},    // 手机
        'tablet': {'min': '768px', 'max': '1023px'}, // 平板
        'desktop': {'min': '1024px'}, // 桌面
      },
      spacing: {
        // 移动端友好的间距系统
        'mobile-xs': '0.25rem',  // 4px
        'mobile-sm': '0.5rem',   // 8px
        'mobile-md': '0.75rem',  // 12px
        'mobile-lg': '1rem',     // 16px
        'mobile-xl': '1.25rem',  // 20px
      },
      fontSize: {
        'mobile-xs': '0.75rem',   // 12px
        'mobile-sm': '0.875rem',  // 14px
        'mobile-base': '1rem',    // 16px
        'mobile-lg': '1.125rem',  // 18px
        'mobile-xl': '1.25rem',   // 20px
      }
    }
  },
  plugins: []
}
```

### 2. 性能优化策略

#### 数据缓存机制
```typescript
// src/services/cacheManager.ts
export class CacheManager {
  private cache = new Map<string, CacheItem>()
  private maxSize = 100
  private ttl = 5 * 60 * 1000 // 5分钟

  set(key: string, data: any, ttl?: number): void {
    const item: CacheItem = {
      data,
      timestamp: Date.now(),
      ttl: ttl || this.ttl
    }
    
    this.cache.set(key, item)
    this.cleanup()
  }

  get(key: string): any | null {
    const item = this.cache.get(key)
    
    if (!item) return null
    if (Date.now() - item.timestamp > item.ttl) {
      this.cache.delete(key)
      return null
    }
    
    return item.data
  }

  private cleanup(): void {
    const now = Date.now()
    for (const [key, item] of this.cache) {
      if (now - item.timestamp > item.ttl) {
        this.cache.delete(key)
      }
    }
    
    // 限制缓存大小
    if (this.cache.size > this.maxSize) {
      const entries = Array.from(this.cache.entries())
        .sort((a, b) => b[1].timestamp - a[1].timestamp)
      
      for (let i = 0; i < entries.length - this.maxSize; i++) {
        this.cache.delete(entries[i][0])
      }
    }
  }
}
```

#### 组件懒加载
```typescript
// src/hooks/useLazyLoad.tsx
import { lazy, Suspense } from 'react'

// 懒加载组件
const LazyPOIDetail = lazy(() => import('../pages/POIDetailPage').then(m => m.POIDetailPage))
const LazyRouteDetail = lazy(() => import('../pages/RouteDetailPage').then(m => m.RouteDetailPage))

export const LazyPOIDetailPage = () => (
  <Suspense fallback={<LoadingSkeleton />}>
    <LazyPOIDetail />
  </Suspense>
)
```

---

## 📱 移动端优化方案

### 1. 触摸优化系统
```typescript
// src/hooks/useTouchOptimized.ts
export const useTouchOptimized = () => {
  const createTouchHandler = (handler: () => void, delay = 300) => {
    let lastTouchTime = 0
    
    return (e: TouchEvent) => {
      e.preventDefault()
      const currentTime = Date.now()
      
      // 防止双击
      if (currentTime - lastTouchTime < delay) return
      
      lastTouchTime = currentTime
      
      // 触觉反馈
      if (navigator.vibrate) {
        navigator.vibrate(50)
      }
      
      handler()
    }
  }

  // 手势识别
  const useSwipeGesture = (onSwipeLeft?: () => void, onSwipeRight?: () => void) => {
    let startX = 0
    let startY = 0
    let isDragging = false
    const threshold = 50

    const handleTouchStart = (e: TouchEvent) => {
      startX = e.touches[0].clientX
      startY = e.touches[0].clientY
      isDragging = true
    }

    const handleTouchEnd = (e: TouchEvent) => {
      if (!isDragging) return
      
      const deltaX = e.changedTouches[0].clientX - startX
      const deltaY = e.changedTouches[0].clientY - startY
      
      isDragging = false
      
      if (Math.abs(deltaX) > Math.abs(deltaY) && Math.abs(deltaX) > threshold) {
        if (deltaX > 0) {
          onSwipeRight?.()
        } else {
          onSwipeLeft?.()
        }
      }
    }

    return {
      onTouchStart: handleTouchStart,
      onTouchEnd: handleTouchEnd
    }
  }

  return { createTouchHandler, useSwipeGesture }
}
```

### 2. 移动端UI组件
```typescript
// src/components/mobile/MobileButton.tsx
import React from 'react'
import { cn } from '@/utils/cn'

interface MobileButtonProps {
  children: React.ReactNode
  onClick?: () => void
  variant?: 'primary' | 'secondary' | 'ghost'
  size?: 'sm' | 'md' | 'lg'
  loading?: boolean
  disabled?: boolean
}

export const MobileButton: React.FC<MobileButtonProps> = ({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  loading = false,
  disabled = false
}) => {
  return (
    <button
      className={cn(
        // 移动端优化的按钮样式
        'min-h-[44px]', // 最小触摸区域
        'px-4 py-2', // 适配不同屏幕
        'rounded-lg',
        'font-medium',
        'transition-all duration-200',
        'focus-visible:outline-none',
        'focus:ring-2 focus:ring-brand-primary/50',
        
        // 变体样式
        {
          'bg-brand-primary text-white hover:bg-brand-primary/90 active:bg-brand-primary':
            variant === 'primary',
          'bg-gray-200 text-gray-900 hover:bg-gray-300':
            variant === 'secondary',
          'border border-brand-primary text-brand-primary hover:bg-brand-primary/10':
            variant === 'ghost',
        },
        
        // 尺寸样式
        {
          'text-xs py-1 px-2': size === 'sm',
          'text-sm py-2 px-4': size === 'md', 
          'text-base py-3 px-6': size === 'lg',
        },
        
        // 状态样式
        {
          'opacity-50 cursor-not-allowed': disabled,
          'animate-pulse': loading,
        }
      )}
      onClick={onClick}
      disabled={disabled || loading}
    >
      {loading && (
        <div className="mr-2 h-4 w-4 animate-spin border-2 border-current border-t-transparent rounded-full" />
      )}
      {children}
    </button>
  )
}
```

---

## 🎯 AgentA核心功能实现

### 1. 智能景点讲解
```typescript
// src/components/agent/POIExplanation.tsx
import React, { useState, useEffect } from 'react'
import { AgentAService } from '@/services/agentA'
import { useResponsive } from '@/hooks/useResponsive'

interface POIExplanationProps {
  poiId: string
  userContext: UserContext
}

export const POIExplanation: React.FC<POIExplanationProps> = ({ poiId, userContext }) => {
  const [explanation, setExplanation] = useState<Explanation | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const { isMobile } = useResponsive()
  const agentA = new AgentAService()

  useEffect(() => {
    loadExplanation()
  }, [poiId])

  const loadExplanation = async () => {
    setIsLoading(true)
    try {
      const result = await agentA.explainPOI(poiId, userContext)
      setExplanation(result)
    } catch (error) {
      console.error('加载讲解失败:', error)
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className={cn(
      'bg-white rounded-xl shadow-md p-6',
      isMobile && 'mx-4 my-2' // 移动端边距
    )}>
      {/* 讲解内容 */}
      {isLoading ? (
        <div className="space-y-4">
          <div className="h-4 w-4 bg-gray-200 rounded-full animate-spin" />
          <div className="h-4 bg-gray-200 rounded w-2/3" />
          <div className="h-4 bg-gray-200 rounded w-3/4" />
        </div>
      ) : explanation ? (
        <div className="space-y-4">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-12 h-12 bg-brand-primary rounded-full flex items-center justify-center text-white">
              <span className="text-2xl">🤖</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-brand-primary">
                AI导游小A讲解
              </h3>
              <p className="text-sm text-gray-600">
                {explanation.emotion === 'excited' && '✨'}
                {explanation.emotion === 'caring' && '💕'}
                {explanation.text}
              </p>
            </div>
          </div>
          
          {/* 音频播放器 */}
          {explanation.audioUrl && (
            <div className="bg-gray-50 rounded-lg p-4">
              <button className="w-full flex items-center justify-center gap-2 py-3 bg-brand-primary text-white rounded-lg">
                <span className="text-sm">🔊 点击播放讲解</span>
              </button>
            </div>
          )}
          
          {/* 实用建议 */}
          {explanation.suggestions && (
            <div className="bg-blue-50 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">📋 小A建议</h4>
              <ul className="space-y-2 text-sm text-blue-800">
                {explanation.suggestions.map((suggestion, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <span>{suggestion}</span>
                  </li>
                ))}
              </ul>
            </div>
          )}
        </div>
      ) : (
        <div className="text-center text-gray-500 py-8">
          <p>正在准备讲解内容...</p>
        </div>
      )}
    </div>
  )
}
```

### 2. 智能对话界面
```typescript
// src/components/agent/AIChat.tsx
import React, { useState, useRef, useEffect } from 'react'
import { AgentAService } from '@/services/agentA'
import { MobileButton } from '@/components/mobile/MobileButton'
import { Input } from '@/components/ui/input'

interface AIChatProps {
  isOpen: boolean
  onClose: () => void
  context: ConversationContext
}

export const AIChat: React.FC<AIChatProps> = ({ isOpen, onClose, context }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([])
  const [input, setInput] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [isRecording, setIsRecording] = useState(false)
  const messagesEndRef = useRef<HTMLDivElement>(null)
  const agentA = new AgentAService()

  const sendMessage = async (text: string) => {
    if (!text.trim() || isLoading) return

    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      content: text,
      timestamp: new Date().toISOString()
    }

    setMessages(prev => [...prev, userMessage])
    setIsLoading(true)

    try {
      const response = await agentA.chat(text, context)
      
      const aiMessage: ChatMessage = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.text,
        emotion: response.emotion,
        timestamp: new Date().toISOString()
      }

      setMessages(prev => [...prev, aiMessage])
    } catch (error) {
      console.error('发送消息失败:', error)
    } finally {
      setIsLoading(false)
    }
  }

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  useEffect(() => {
    scrollToBottom()
  }, [messages])

  return (
    <div className={cn(
      'fixed inset-0 z-50 flex flex-col bg-black bg-opacity-50',
      !isOpen && 'hidden'
    )}>
      {/* 对话内容 */}
      <div className="flex-1 bg-white m-4 rounded-t-2xl shadow-2xl flex flex-col">
        {/* 头部 */}
        <div className="flex items-center justify-between p-4 border-b border-gray-200">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-brand-primary rounded-full flex items-center justify-center text-white">
              <span className="text-xl">🤖</span>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-brand-primary">AI导游小A</h3>
              <p className="text-sm text-gray-600">有什么可以帮助你的吗？</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="text-gray-400 hover:text-gray-600"
          >
            ✕
          </button>
        </div>

        {/* 消息列表 */}
        <div className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={cn(
                'flex gap-3',
                message.role === 'user' ? 'justify-end' : 'justify-start'
              )}
            >
              <div
                className={cn(
                  'max-w-[70%] rounded-xl p-3',
                  message.role === 'user'
                    ? 'bg-brand-primary text-white'
                    : 'bg-gray-100 text-gray-900'
                )}
              >
                <p className="text-sm">{message.content}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {new Date(message.timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
          ))}
          
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-gray-100 text-gray-900 rounded-xl p-3">
                <div className="flex gap-2">
                  <div className="w-2 h-2 bg-gray-300 rounded-full animate-spin" />
                  <div className="h-2 bg-gray-300 rounded w-2/3" />
                  <div className="h-2 bg-gray-300 rounded w-3/4" />
                </div>
              </div>
            </div>
          )}
          
          <div ref={messagesEndRef} />
        </div>

        {/* 输入区域 */}
        <div className="border-t border-gray-200 p-4">
          <div className="flex gap-2">
            {/* 语音按钮 */}
            <MobileButton
              variant={isRecording ? 'danger' : 'ghost'}
              size="sm"
              onClick={() => {
                // 语音录制功能
                setIsRecording(!isRecording)
              }}
            >
              🎤
            </MobileButton>

            {/* 摄像头按钮 */}
            <MobileButton
              variant="ghost"
              size="sm"
              onClick={() => {
                // 拍照功能
              }}
            >
              📸
            </MobileButton>

            {/* 文本输入 */}
            <Input
              type="text"
              placeholder="输入您的问题..."
              value={input}
              onChange={(e) => setInput(e.target.value)}
              disabled={isLoading}
              className="flex-1"
            />

            {/* 发送按钮 */}
            <MobileButton
              variant="primary"
              size="sm"
              onClick={() => sendMessage(input)}
              disabled={!input.trim() || isLoading}
              loading={isLoading}
            >
              发送
            </MobileButton>
          </div>
        </div>
      </div>
    </div>
  )
}
```

---

## 📋 实施优先级和时间安排

### 第1周: 基础设施搭建
1. ✅ 安装智谱AI SDK和依赖
2. ✅ 配置ZhipuAI服务类
3. ✅ 实现基础API调用封装
4. ✅ 配置响应式TailwindCSS

### 第2周: 核心功能开发
1. ✅ 实现AgentA景点讲解功能
2. ✅ 开发智能对话系统
3. ✅ 实现TTS语音合成
4. ✅ 开发图像理解功能

### 第3周: 移动端优化
1. ✅ 实现响应式设计系统
2. ✅ 开发触摸优化组件
3. ✅ 实现性能缓存机制
4. ✅ 懒加载和性能优化

### 第4周: 集成测试
1. ✅ 前后端ANP服务集成测试
2. ✅ 移动端兼容性测试
3. ✅ 性能基准测试
4. ✅ 用户体验测试

---

## 🎯 成功标准

### 技术指标
- ✅ ANP响应时间 < 2秒
- ✅ 移动端首屏加载时间 < 3秒
- ✅ 页面切换响应时间 < 500ms
- ✅ 内存使用减少30%
- ✅ 支持iOS和Android双平台

### 用户体验指标
- ✅ 移动端操作流畅度评分 > 4.5/5
- ✅ 智能回答准确率 > 85%
- ✅ 用户满意度提升30%
- ✅ 支持无障碍访问

### 功能完成度
- ✅ AgentA智能讲解功能完成
- ✅ 智能对话功能完成
- ✅ TTS语音合成完成
- ✅ 图像理解功能完成
- ✅ 移动端响应式适配完成

---

## 🚫 砍掉的功能清单

### 社交分享功能
- ❌ 微信分享
- ❌ 朋友圈分享
- ❌ QQ分享
- ❌ 微博分享
- ❌ 复杂的社交功能

### 复杂的多媒体功能
- ❌ 视频编辑和上传
- ❌ 复杂的图片处理
- ❌ 直播功能
- ❌ 复杂的用户生成内容

### 不必要的复杂功能
- ❌ 复杂的用户设置
- ❌ 多语言支持(初期)
- ❌ 复杂的数据统计
- ❌ 过度的个性化功能

---

## 📊 CDN配置方案

### 优先级CDN配置
```javascript
// vite.config.js
export default {
  build: {
    rollupOptions: {
      output: {
        // 静态资源配置
        assetFileNames: 'assets/[name].[hash][extname]',
        chunkFileNames: 'js/[name].[hash].js',
      }
    },
  },
  optimizeDeps: {
    // CDN资源配置
    include: ['react', 'react-dom'],
    // 使用阿里巴巴、字节跳动等国内CDN
    registry: 'https://registry.npmmirror.com'
  }
}
```

### 图片优化配置
```javascript
// vite.config.js
export default {
  build: {
    assetsInlineLimit: 4096, // 小于4KB的图片内联
    assetsDir: 'assets', // 静态资源目录
  },
  server: {
    // 开发环境资源配置
    proxy: {
      '/api': {
        target: 'http://localhost:3000',
        changeOrigin: true,
      }
    }
  }
}
```

---

## 🔧 环境配置文件

### 智谱AI环境变量
```bash
# .env
ZHIPU_API_KEY=a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog
ZHIPU_BASE_URL=https://open.bigmodel.cn/api/paas/v4

# 模型配置
ZHIPU_TEXT_MODEL=glm-4.5-flash
ZHIPU_IMAGE_MODEL=cogview-3-flash
ZHIPU_VIDEO_MODEL=cogvideox-flash
ZHIPU_TTS_MODEL=tts-1

# 超时配置(毫秒)
ZHIPU_REQUEST_TIMEOUT=10000
ZHIPU_RETRY_COUNT=3
ZHIPU_RETRY_DELAY=1000
```

### 移动端优化配置
```bash
# 性能配置
VITE_MOBILE_OPTIMIZATION=true
VITE_ENABLE_LAZY_LOADING=true
VITE_CACHE_SIZE=100
VITE_CACHE_TTL=300000

# 响应式配置
VITE_MOBILE_FIRST=true
VITE_TOUCH_OPTIMIZED=true
VITE_MIN_TOUCH_TARGET=44
VITE_SWIPE_THRESHOLD=50
```

---

## 🎯 风险控制和应急预案

### 技术风险
1. ⚠️ ANP服务依赖性
2. ⚠️ 网络连接稳定性
3. ⚠️ 移动端兼容性
4. ⚠️ 性能优化复杂性

### 应急预案
1. 🔄 API降级策略: ANP不可用时使用本地缓存
2. 🔄 离线模式支持: 核心功能离线可用
3. 🔄 错误恢复机制: 优雅降级和用户提示
4. 🔄 性能监控: 实时监控和告警

---

**实施时间**: 4周  
**团队配置**: 2-3名前端开发工程师  
**技术栈**: 保持现有React + TypeScript + TailwindCSS架构，集成智谱AI  
**预期成果**: 移动端优先的智能导览系统，性能提升30%，用户体验显著改善

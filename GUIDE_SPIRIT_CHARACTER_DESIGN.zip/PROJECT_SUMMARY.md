# 东里村AI导览系统 - 项目总结

## 📋 项目概览

**项目名称**：东里村AI导览系统  
**项目位置**：福建省永春县仙夹镇东里村  
**项目类型**：乡村旅游智能导览平台  
**开发阶段**：第三阶段（后端框架搭建）

## 🎯 核心目标

1. **AI+导游**：通过AI技术提供智能导览服务
2. **本地优先**：核心功能不依赖网络，适应乡村弱网环境
3. **文化传承**：展示红色文化、民俗文化、生态文化
4. **乡村振兴**：促进农产品销售和乡村旅游发展

## 👥 目标用户

- **主要用户**：到访东里村的游客（25-50岁）
- **次要用户**：景区管理人员
- **辅助用户**：村民内容贡献者

## 🏗️ 技术架构

### 前端技术栈
```
React 18 + TypeScript + Vite
├── UI框架：TailwindCSS + Headless UI
├── 路由：Wouter（轻量级）
├── 状态管理：Zustand
└── 构建工具：Vite
```

### 后端技术栈
```
Node.js + Express
├── Web框架：Express
├── 数据库：SQLite（本地）
├── 缓存：Redis（可选）
├── 异步运行时：Node.js
└── HTTP客户端：axios
```

### AI服务
```
SiliconFlow API（主）/ 智谱AI API（备）
├── 语音识别与合成
├── 图像识别
├── 自然语言处理
└── 智能推荐
```

### Agent架构
```
四智能体协作系统
├── Agent A：前台客服（TypeScript）- 用户交互
├── Agent B：RAG向量（TypeScript）- 知识检索
├── Agent C：运营分析（TypeScript）- 数据收集
└── Agent D：协调监控（TypeScript）- 质量保证
```

## 🗺️ 主题路线

### 红色革命路线
| 路线 | 时长 | 景点 | 特色 |
|------|------|------|------|
| 轻量级 | 3-4小时 | 纪念馆→旌义状→古炮楼→廊桥 | 学游、党建 |
| 一日游 | 8小时 | 深度红色文化体验 | 领导考察 |
| 闽台民俗 | 2-3天 | 红色+民俗融合 | 文化交流 |

### 生态民俗路线
| 路线 | 时长 | 景点 | 特色 |
|------|------|------|------|
| 休闲半日 | 3-4小时 | 水库→瀑布→生态步道 | 家庭休闲 |
| 文化一日 | 8小时 | 自然+农耕+民俗 | 体验式 |
| 深度民俗 | 2-3天 | 民俗活动参与 | 沉浸式 |

## 🎯 核心功能模块

### 1. 用户交互模块
- ✅ 登录注册（手机号/微信/支付宝）
- ✅ 路线选择（主题路线展示）
- ✅ 景点导览（文字、图片、语音、拍照识别）
- ✅ 智能交互（语音问答、拍照识别）

### 2. 导航定位模块
- ✅ GPS定位（精确坐标）
- ✅ 地标导航（GPS信号不佳时备用）
- ✅ 路线规划（景点间导航）
- ✅ 离线支持（本地优先）

### 3. 内容管理模块
- ⏳ 农民内容上传（文本、图片、音频）
- ⏳ 内容审核流程（质量评分、状态管理）
- ⏳ 插件化处理（图片压缩、音频处理）
- ⏳ 质量控制机制

### 4. 数据分析模块
- ⏳ 实时访客统计
- ⏳ 景点热度分析（热力图）
- ⏳ 访问趋势分析
- ⏳ 行为模式分析

### 5. AI用户维护模块
- ⏳ 公众号关注推送
- ⏳ 纪念册自动生成
- ⏳ 个性化推荐
- ⏳ 营销内容管理

## 📊 数据库设计

### 核心表结构
```
users                    # 用户信息
├── user_id (PK)
├── phone
├── login_type
└── created_at

pois                     # 景点信息
├── poi_id (PK)
├── route_id (FK)
├── name
├── coord (lat,lng)
└── audio_url

content_uploads          # 内容上传
├── id (PK)
├── user_id (FK)
├── content_type
├── status
└── quality_score

visitor_records          # 访客记录
├── id (PK)
├── user_id (FK)
├── spot_id
├── visit_time
└── duration

group_orders             # 团体订单
├── order_id (PK)
├── group_name
├── visitor_count
└── visit_date

system_configs           # 系统配置
├── config_key (PK)
└── config_value

user_permissions         # 用户权限
├── id (PK)
├── user_id (FK)
└── permission

content_audit_log        # 审核日志
├── id (PK)
├── content_id (FK)
├── action
└── reviewer_id (FK)
```

## 🎨 关键景点（POI）

### 红色文化类
| 景点 | POI ID | 坐标 | 特色 |
|------|--------|------|------|
| 辛亥革命纪念馆 | poi_donglired_xinhaijinianguan001 | 118.205, 25.234 | 郑玉指事迹 |
| 旌义状石碑 | poi_donglired_jingyizhuang001 | 118.206, 25.234 | 孙中山旌义状 |
| 古炮楼 | poi_red_guntou | 118.209, 25.231 | 抗倭防御 |
| 集庆廊桥 | poi_red_jiqing | 118.205, 25.232 | 闽南建筑 |
| 洋杆尾古民居 | poi_red_yangwei | 118.207, 25.235 | 烈士故居 |
| 昭灵宫 | poi_red_wanzhu | 118.205, 25.234 | 民间信仰 |

### 生态景点
| 景点 | POI ID | 坐标 | 特色 |
|------|--------|------|------|
| 仙灵瀑布 | poi_ecology_xianling | 118.199, 25.230 | 120米落差 |
| 豆磨古寨 | poi_ecology_doumo | 118.211, 25.237 | 抗倭遗址 |
| 东里水库 | poi_ecology_shuiku | 118.202, 25.237 | 水源地 |
| 功能农业基地 | poi_ecology_farm | 118.203, 25.231 | 防癌作物 |
| 油桐花海 | poi_basic_ythh | 118.204, 25.238 | 季节景观 |

### 基础设施
| 设施 | POI ID | 坐标 | 功能 |
|------|--------|------|------|
| 游客服务中心 | poi_basic_ykfwzx | 118.204, 25.238 | 咨询服务 |
| 乡村发展中心 | poi_basic_xcfzzx | 118.209, 25.235 | 展示中心 |
| 油桐花民宿 | poi_basic_ythms | 118.205, 25.238 | 住宿 |

## 📱 非功能性需求

### 性能指标
- 页面加载时间 ≤ 3秒
- 语音交互响应 ≤ 10秒
- 拍照识别响应 ≤ 15秒
- 系统并发支持 ≥ 100用户

### 兼容性
- iOS/Android 系统
- 微信/支付宝内置浏览器
- 弱网环境（2G/3G）
- 阳光下可见

### 安全性
- AES-256 数据加密
- bcrypt 密码哈希
- JWT Token 认证
- RBAC 权限管理
- SQL注入/XSS防护

## 📈 开发阶段

### ✅ 已完成
- **第一阶段**：前端框架搭建（React+Vite+Tailwind）
- **第二阶段**：核心路由和状态管理

### 🔄 进行中
- **第三阶段**：后端框架搭建（Node.js + Express）
  - SQLite 数据表与数据访问层
  - Express REST API 与中间件
  - JWT 认证 + Authorization
  - 前后端接口联调与测试

### ⏳ 待进行
- **第四阶段**：AI 服务集成（3周）
- **第五阶段**：向量数据库和 RAG（2周）
- **第六阶段**：Agent 架构实现（2周）
- **第七阶段**：性能优化和部署（1周）

## 📚 项目文档

| 文档 | 位置 | 说明 |
|------|------|------|
| 技术方案 | `/oprate/东里村AI导览系统技术构建方案与技术栈说明.md` | 完整技术架构 |
| 产品需求 | `/oprate/东里村AI导览系统产品功能开发结构需求明细表.md` | 功能需求 |
| 路线设计 | `/oprate/东里村路线设计-AI增强版.md` | 路线和景点数据 |
| 数据库设计 | `/oprate/东里村AI导览系统数据库字段表整理.md` | 数据库表结构 |
| 景观数据 | `/doc/重要景观必读.txt` | 景点详细信息 |
| 检查报告 | `/oprate/东里村AI导览系统检查报告.md` | 系统设计评估 |
| 前端指南 | `/codegpt5/FRONTEND_GUIDE.md` | 前端开发指南 |
| 进度记录 | `/codegpt5/PROGRESS.md` | 开发进度 |
| 后续计划 | `/codegpt5/NEXT_PHASE_PLAN.md` | 第三阶段详细计划 |

## 🚀 快速开始

### 前端开发
```bash
cd j:/dongli/codegpt5
npm install
npm run dev
# 访问 http://localhost:5173
```

### 后端开发
```bash
cd e:/iflow/codegpt5/backend
npm install
npm run dev
```

### 项目结构
```
codegpt5/
├── src/                         # React + Zustand 前端
│   ├── components/
│   ├── pages/
│   ├── store/
│   ├── services/
│   └── App.tsx
├── backend/                     # Express API 服务
│   ├── routes/
│   ├── config.js
│   ├── server.js
│   ├── data/
│   └── uploads/
├── docs/                        # 已整理的项目文档（需同步更新）
├── oprate/                      # 运营与产品文档
│   ├── 东里村AI导览系统技术构建方案与技术栈说明.md
│   ├── 东里村AI导览系统完整项目结构说明.md
│   ├── 东里村AI导览系统项目文档.md
│   └── 东里村AI导览系统检查报告.md
├── capacitor.config.ts
├── android/
└── ios/
```

## 💡 关键技术决策

### 为什么选择 Express？
- ✅ 轻量级Web框架
- ✅ 本地优先架构
- ✅ Node.js 高性能
- ✅ 跨平台支持
- ✅ 适合乡村弱网环境

### 为什么选择 SQLite？
- ✅ 轻量级嵌入式数据库
- ✅ 无需服务器
- ✅ 本地离线支持
- ✅ 适合单机部署

### 为什么选择 Zustand？
- ✅ 轻量级状态管理
- ✅ 简单易用
- ✅ TypeScript 支持
- ✅ 性能优秀

### 为什么选择 Zustand？
- ✅ 轻量级状态管理
- ✅ 简单易用
- ✅ TypeScript 支持
- ✅ 性能优秀

## 🎓 学习资源

### 前端
- [React 官方文档](https://react.dev)
- [TailwindCSS 文档](https://tailwindcss.com)
- [Wouter 文档](https://github.com/molefrog/wouter)
- [Zustand 文档](https://github.com/pmndrs/zustand)

### 后端
- [Express 官方文档](https://expressjs.com)
- [Node.js 官方文档](https://nodejs.org)
- [SQLite 文档](https://www.sqlite.org/docs.html)
- [Axios 文档](https://axios-http.com/docs/intro)

### AI 服务
- [SiliconFlow API](https://api.siliconflow.cn)
- [智谱 AI API](https://open.bigmodel.cn)

## 📞 联系方式

- **项目位置**：j:/dongli/codegpt5
- **开发服务器**：http://localhost:5173
- **后端服务**：Express 本地应用

## 📝 许可证

本项目为东里村乡村旅游项目专用，版权归东里村所有。

---

**最后更新**：2025年11月16日  
**当前版本**：0.2.0（第二阶段完成）  
**下一版本**：0.3.0（第三阶段完成预期）

# 东里村AI导览系统部署和运维文档

## 1. 部署架构

### 1.1 部署模式
- **单机部署**：适用于小型景区，所有服务运行在同一台服务器上
- **本地+云端**：本地处理核心功能，云端提供备份和扩展服务
- **容器化部署**：使用Docker容器部署，便于扩展和维护（后期扩展）

### 1.2 系统要求

#### 服务器配置
- **CPU**：4核以上
- **内存**：8GB以上
- **存储**：100GB SSD以上
- **网络**：支持互联网接入

#### 软件依赖
- **操作系统**：Linux/Windows/macOS
- **运行时**：Node.js 16+ 运行环境
- **数据库**：SQLite 3.35+
- **缓存**：Redis 6.0+（可选）

## 2. 部署流程

### 2.1 环境准备

#### 2.1.1 安装Node.js环境
```bash
# 下载并安装Node.js
curl -fsSL https://nodejs.org/dist/v18.17.0/node-v18.17.0-linux-x64.tar.xz | tar -xJ
sudo mv node-v18.17.0-linux-x64 /opt/nodejs
sudo ln -s /opt/nodejs/bin/node /usr/local/bin/node
sudo ln -s /opt/nodejs/bin/npm /usr/local/bin/npm
```

#### 2.1.2 安装依赖工具
```bash
# 安装Git
sudo apt-get update
sudo apt-get install git

# 安装构建工具
sudo apt-get install build-essential
```

### 2.2 代码部署

#### 2.2.1 获取源代码
```bash
# 克隆项目代码
git clone https://github.com/your-org/dongli-guide.git
cd dongli-guide
```

#### 2.2.2 安装依赖
```bash
# 安装前端依赖
npm install

# 安装后端依赖
cd backend
npm install
```

#### 2.2.3 构建项目
```bash
# 构建前端
npm run build

# 复制构建文件到后端静态目录
cp -r dist/* backend/public/
```

### 2.3 数据库初始化

#### 2.3.1 创建数据库
```bash
# 进入后端目录
cd backend

# 创建数据库文件
touch data/dongli.db

# 初始化数据库表
sqlite3 data/dongli.db < data/schema.sql
```

#### 2.3.2 导入初始数据
```bash
# 导入路线和景点数据
node scripts/import-data.js
```

### 2.4 配置文件设置

#### 2.4.1 后端配置
```javascript
// backend/config.js
module.exports = {
  // 服务器端口
  PORT: process.env.PORT || 3000,
  
  // 数据库配置
  DATABASE_PATH: './data/dongli.db',
  
  // JWT密钥
  JWT_SECRET: process.env.JWT_SECRET || 'dongli-ai-tour-secret-key',
  
  // 文件上传配置
  UPLOAD_PATH: './uploads',
  
  // CORS配置
  CORS_ORIGIN: process.env.CORS_ORIGIN || 'http://localhost:5173'
};
```

#### 2.4.2 前端配置
```javascript
// src/config.js
const config = {
  // API基础URL
  API_BASE_URL: process.env.REACT_APP_API_URL || 'http://localhost:3000/api',
  
  // 地图服务配置
  MAP_API_KEY: process.env.REACT_APP_MAP_API_KEY || '',
  
  // AI服务配置
  AI_API_URL: process.env.REACT_APP_AI_API_URL || 'https://api.siliconflow.cn',
};

export default config;
```

### 2.5 启动服务

#### 2.5.1 启动后端服务
```bash
# 进入后端目录
cd backend

# 启动服务
npm start

# 或使用PM2进行生产部署
npm install -g pm2
pm2 start server.js --name "dongli-backend"
```

#### 2.5.2 启动前端开发服务（开发环境）
```bash
# 进入项目根目录
cd ..

# 启动开发服务器
npm run dev
```

### 2.6 反向代理配置（生产环境）

#### 2.6.1 Nginx配置
```nginx
server {
    listen 80;
    server_name dongli.yourdomain.com;

    # 前端静态文件
    location / {
        root /path/to/dongli-guide/backend/public;
        try_files $uri $uri/ /index.html;
    }

    # API代理
    location /api/ {
        proxy_pass http://localhost:3000/;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    # 上传文件访问
    location /uploads/ {
        alias /path/to/dongli-guide/backend/uploads/;
    }
}
```

## 3. 运维管理

### 3.1 监控与日志

#### 3.1.1 日志配置
```javascript
// backend/utils/logger.js
const winston = require('winston');

const logger = winston.createLogger({
  level: 'info',
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.errors({ stack: true }),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({ filename: 'logs/error.log', level: 'error' }),
    new winston.transports.File({ filename: 'logs/combined.log' })
  ]
});

if (process.env.NODE_ENV !== 'production') {
  logger.add(new winston.transports.Console({
    format: winston.format.simple()
  }));
}

module.exports = logger;
```

#### 3.1.2 监控指标
- **系统指标**：CPU使用率、内存使用率、磁盘空间
- **应用指标**：API响应时间、错误率、并发用户数
- **业务指标**：日活跃用户、景点访问量、内容上传量

### 3.2 API 可用性检查
- **启动后**：使用 `curl` 或 `http` 命令验证关键接口是否可达，优先检查新增的内容模型/AI 相关接口。
  ```bash
  curl -H "Authorization: Bearer $TOKEN" http://localhost:3000/api/content-models | jq '. | length'
  curl -H "Authorization: Bearer $TOKEN" -X POST http://localhost:3000/api/guide/explain-poi -d '{"poiId":"poi_donglired_xinhaijinianguan001"}' -H 'Content-Type: application/json'
  ```
- **失败排查**：如果某个接口返回 4xx/5xx，打开 `/logs` 目录检查 `server.log`，确认是否为数据库字段缺失（如 `content_model_id`）或 AI 服务超时。
- **定期校验**：将上述命令纳入监控脚本（Crontab/PM2）里每日/每次部署后执行，并在失败时自动通知 Slack/邮件。

#### 3.2.1 数据库备份
```bash
#!/bin/bash
# backup.sh

# 备份时间戳
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")

# 数据库备份
sqlite3 /path/to/dongli-guide/backend/data/dongli.db .dump > /path/to/backups/dongli_db_${TIMESTAMP}.sql

# 文件备份
tar -czf /path/to/backups/dongli_files_${TIMESTAMP}.tar.gz \
    /path/to/dongli-guide/backend/uploads/ \
    /path/to/dongli-guide/backend/data/

# 保留最近7天的备份
find /path/to/backups -name "dongli_*" -mtime +7 -delete
```

#### 3.2.2 配置文件版本控制
```bash
# 使用Git管理配置文件
cd /path/to/dongli-guide
git add backend/config.js
git commit -m "Update configuration"
git push origin main
```

### 3.3 安全管理

#### 3.3.1 定期安全检查
- 检查依赖包安全漏洞：`npm audit`
- 更新系统和依赖包
- 检查文件权限设置
- 审查访问日志

#### 3.3.2 密钥管理
```bash
# 使用环境变量存储敏感信息
export JWT_SECRET="your-secret-key"
export DATABASE_PATH="/secure/path/to/database.db"
```

### 3.4 性能优化

#### 3.4.1 数据库优化
- 定期分析和优化数据库查询
- 添加合适的索引
- 清理过期数据

#### 3.4.2 缓存策略
```javascript
// 使用Redis缓存热点数据
const redis = require('redis');
const client = redis.createClient();

// 缓存路线列表
app.get('/api/routes', async (req, res) => {
  const cached = await client.get('routes');
  if (cached) {
    return res.json(JSON.parse(cached));
  }
  
  const routes = await routeService.getRoutes();
  await client.setex('routes', 300, JSON.stringify(routes)); // 缓存5分钟
  res.json(routes);
});
```

## 4. 故障处理

### 4.1 常见问题及解决方案

#### 4.1.1 服务无法启动
```bash
# 检查端口占用
lsof -i :3000

# 检查依赖安装
npm install

# 查看日志
tail -f backend/logs/error.log
```

#### 4.1.2 数据库连接失败
```bash
# 检查数据库文件权限
ls -la backend/data/dongli.db

# 检查数据库完整性
sqlite3 backend/data/dongli.db "PRAGMA integrity_check;"
```

#### 4.1.3 API响应缓慢
```bash
# 检查系统资源使用情况
top
df -h
free -m

# 分析慢查询
sqlite3 backend/data/dongli.db "EXPLAIN QUERY PLAN SELECT * FROM users WHERE phone = '13800138000';"
```

### 4.2 灾难恢复

#### 4.2.1 数据恢复流程
```bash
# 从备份恢复数据库
sqlite3 backend/data/dongli.db < backups/dongli_db_20231201_120000.sql

# 恢复上传文件
tar -xzf backups/dongli_files_20231201_120000.tar.gz -C /
```

#### 4.2.2 应用回滚
```bash
# 使用Git回滚到上一个稳定版本
cd /path/to/dongli-guide
git reset --hard HEAD~1
npm install
npm start
```

## 5. 升级维护

### 5.1 版本升级流程

#### 5.1.1 前端升级
```bash
# 拉取最新代码
git pull origin main

# 安装新依赖
npm install

# 构建新版本
npm run build

# 部署新版本
cp -r dist/* backend/public/
```

#### 5.1.2 后端升级
```bash
# 拉取最新代码
cd backend
git pull origin main

# 安装新依赖
npm install

# 执行数据库迁移（如有）
node scripts/migrate.js

# 重启服务
pm2 restart dongli-backend
```

### 5.2 数据库迁移

#### 5.2.1 迁移脚本示例
```javascript
// backend/scripts/migrate.js
const db = require('../models/db');

async function migrate() {
  try {
    // 添加新字段
    await db.run('ALTER TABLE users ADD COLUMN avatar TEXT');
    
    // 创建新表
    await db.run(`
      CREATE TABLE IF NOT EXISTS user_feedback (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id TEXT NOT NULL,
        content TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (user_id) REFERENCES users(user_id)
      )
    `);
    
    console.log('Migration completed successfully');
  } catch (error) {
    console.error('Migration failed:', error);
  }
}

migrate();
```

## 6. 运维工具

### 6.1 监控脚本
```bash
#!/bin/bash
# monitor.sh

# 检查服务状态
if pgrep -f "node server.js" > /dev/null; then
  echo "Backend service is running"
else
  echo "Backend service is not running"
  # 发送告警通知
  curl -X POST "https://api.notification-service.com/alert" -d "Service is down"
fi

# 检查磁盘使用率
DISK_USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 90 ]; then
  echo "Warning: Disk usage is ${DISK_USAGE}%"
fi
```

### 6.2 自动化部署脚本
```bash
#!/bin/bash
# deploy.sh

# 拉取最新代码
git pull origin main

# 安装依赖
npm install
cd backend
npm install
cd ..

# 构建前端
npm run build
cp -r dist/* backend/public/

# 重启服务
cd backend
pm2 restart dongli-backend

echo "Deployment completed successfully"
```

通过以上文档，运维人员可以按照标准化流程进行系统的部署、监控和维护工作，确保系统的稳定运行和持续服务。
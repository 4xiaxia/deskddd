# 前端开发指南

## 快速开始

```bash
# 安装依赖
npm install

# 启动开发服务器
npm run dev

# 构建生产版本
npm run build

# 预览生产构建
npm run preview
```

## 项目结构说明

### 核心文件

#### `src/App.tsx`
主应用组件，包含：
- Wouter 路由配置
- 认证状态恢复
- AI 助手抽屉集成

#### `src/index.css`
全局样式：
- Tailwind 指令
- 品牌色定义
- Glass Panel 效果
- 动画延迟工具类

#### `src/types/index.ts`
TypeScript 类型定义：
- 用户、路线、景点类型
- AI 消息类型
- 认证类型

### 状态管理（Zustand）

#### `src/store/authStore.ts`
用户认证状态：
```typescript
const { user, token, login, logout } = useAuthStore();
```

#### `src/store/routeStore.ts`
路线和景点状态：
```typescript
const { routes, currentRoute, pois, fetchRoutes, fetchPOIsByRoute } = useRouteStore();
```

#### `src/store/agentStore.ts`
AI 助手状态：
```typescript
const { isOpen, toggleAgent, addMessage, conversations } = useAgentStore();
```

### 页面组件

#### LoginPage
- 路径：`/login`
- 功能：手机号登录
- 状态：使用 authStore

#### RoutesPage
- 路径：`/routes`
- 功能：显示路线列表
- 状态：使用 routeStore

#### RouteDetailPage
- 路径：`/route/:routeId`
- 功能：显示路线详情和景点列表
- 状态：使用 routeStore

#### POIDetailPage
- 路径：`/route/:routeId/poi/:poiId`
- 功能：显示景点详情
- 状态：使用 routeStore

### UI 组件

#### AIAgentDrawer
- 位置：`src/components/AIAgentDrawer.tsx`
- 功能：
  - 浮动按钮（右下角）
  - 对话抽屉
  - 消息收发
- 状态：使用 agentStore

## 样式系统

### 品牌色
```css
--brand-primary: #0B5C5F    /* 主色 */
--brand-secondary: #D9480F  /* 辅助色 */
--brand-accent: #F4A261     /* 强调色 */
--brand-muted: #EFF4F0      /* 柔和色 */
```

### 预定义类
- `.app-shell` - 应用容器
- `.glass-panel` - 玻璃效果面板
- `.page-section` - 页面分区
- `.floating-agent-shadow` - 浮动元素阴影

## 路由导航

使用 `useLocation` hook 进行导航：
```typescript
import { useLocation } from 'wouter';

const [, setLocation] = useLocation();
setLocation('/routes');
```

## 数据流

### 登录流程
1. 用户输入手机号
2. LoginPage 调用 `authStore.login()`
3. 认证成功，跳转到 `/routes`
4. Token 和用户信息存储到 localStorage

### 路线浏览流程
1. RoutesPage 加载时调用 `fetchRoutes()`
2. 用户选择路线
3. 跳转到 `/route/:routeId`
4. RouteDetailPage 加载景点列表
5. 用户选择景点
6. 跳转到 `/route/:routeId/poi/:poiId`

### AI 对话流程
1. 用户点击浮动按钮打开 AIAgentDrawer
2. 输入消息并发送
3. 消息添加到当前对话
4. 模拟 AI 响应（待集成真实 API）

## 开发建议

### 添加新页面
1. 在 `src/pages/` 创建新组件
2. 在 `App.tsx` 中添加路由
3. 使用相应的 store 管理状态

### 添加新组件
1. 在 `src/components/` 创建新组件
2. 使用 Tailwind CSS 进行样式
3. 导入必要的 store 和 hooks

### 修改样式
1. 优先使用 Tailwind 工具类
2. 全局样式在 `src/index.css` 中修改
3. 组件特定样式在 `src/App.css` 中添加

## 常见问题

### Q: 如何添加新的状态？
A: 在相应的 store 文件中使用 Zustand 的 `create` 函数添加新的状态和方法。

### Q: 如何修改品牌色？
A: 编辑 `tailwind.config.js` 中的 `theme.extend.colors.brand`。

### Q: 如何集成真实 API？
A: 在 store 中的异步方法中替换 TODO 注释的部分，调用实际的 API 端点。

### Q: 如何处理错误？
A: 使用 store 中的 `error` 状态和 `clearError` 方法，在 UI 中显示错误提示。

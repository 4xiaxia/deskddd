# AI Rules for App Development

## Tech Stack Overview

- **Frontend Framework**: React 18 with TypeScript for type safety and component-based architecture
- **Build Tool**: Vite for fast development and optimized production builds
- **Styling**: Tailwind CSS for utility-first styling with custom design system
- **State Management**: Zustand for lightweight, TypeScript-friendly state management
- **Routing**: Wouter for lightweight client-side routing
- **Icons**: Lucide React for consistent iconography
- **HTTP Client**: Built-in fetch API with async/await pattern
- **Maps Integration**: Didi Maps API for location services, routing, and place search
- **Transportation Services**: Didi Taxi API for ride estimates and booking links
- **Error Handling**: React Error Boundaries with custom fallback components
- **Testing**: Jest with React Testing Library for unit and integration tests

## Library Usage Rules

### Core Libraries - Strict Usage
- **React + TypeScript**: Use for all UI components and hooks
- **Tailwind CSS**: Use exclusively for styling - no inline styles or CSS modules
- **Zustand**: Use for all global state management - no Context API for complex state
- **Wouter**: Use for all routing - no other routing libraries
- **Lucide React**: Use for all icons - no other icon libraries

### Maps and Location Services
- **didi-mcp__maps_*** tools**: Use exclusively for all geolocation, routing, and place search functionality
- Coordinate format: Always use "longitude,latitude" string format as specified in API docs
- Location validation: Verify coordinates exist before making API calls
- Cache geocoding results to minimize API calls

### Transportation Features
- **didi-mcp__taxi_estimate**: Use for getting ride estimates and available vehicle types
- **didi-mcp__taxi_generate_ride_app_link**: Use for generating deep links to ride booking
- Always fetch coordinates using maps tools before taxi API calls

### Data Flow Rules
- Maps API calls must happen before transportation API calls when both are needed
- Use React Query or SWR for data fetching - no manual fetch calls in components
- Implement proper loading states for all async operations
- Handle API errors gracefully with user-friendly messages

### Component Architecture
- Create reusable map components for consistent location display
- Separate presentation components from data-fetching logic
- Use custom hooks for complex API interactions
- Follow single responsibility principle for components

### Performance Guidelines
- Debounce search inputs to reduce API calls
- Implement loading states for all async operations
- Use React.memo for expensive map re-renders
- Lazy load heavy components and routes

### Security Considerations
- Never expose API keys in client-side code
- Validate all user inputs before API calls
- Implement rate limiting for user-initiated requests
- Use HTTPS for all external API calls

### State Management Rules
- Use Zustand stores for:
  - User authentication state
  - Route and POI data
  - AI conversation history
  - Global UI state (modals, drawers)
- Use React useState for:
  - Local form state
  - Component-specific UI state
  - Temporary data that doesn't need persistence

### Styling Rules
- Use Tailwind utility classes exclusively
- Follow the existing color scheme (brand-primary, brand-secondary, etc.)
- Use responsive design patterns (mobile-first)
- Maintain consistent spacing using Tailwind spacing scale
- Use semantic color names, not arbitrary values

### Error Handling Rules
- Wrap API calls in try-catch blocks
- Use React Error Boundaries for component errors
- Display user-friendly error messages
- Log errors to console for debugging
- Provide retry mechanisms for failed requests

### Testing Rules
- Write unit tests for utility functions
- Write integration tests for API interactions
- Test error scenarios
- Use React Testing Library patterns
- Maintain test coverage above 80%

### Code Quality Rules
- Use TypeScript strict mode
- Enable ESLint and Prettier
- Write self-documenting code with clear variable names
- Add JSDoc comments for complex functions
- Keep functions under 50 lines when possible
- Avoid nested ternary operators
- Use early returns to reduce nesting


\### 环境变量配置

\#### 核心环境变量

\`\`\`bash

\# 智谱AI配置

ZHIPU_API_KEY=a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog

ZHIPU_BASE_URL=https://open.bigmodel.cn/api/paas/v4

\# 模型配置

ZHIPU_TEXT_MODEL=glm-4.5-flash

ZHIPU_VISION_MODEL=glm-4.1v-thinking-flash

ZHIPU_IMAGE_MODEL=cogview-3-flash

ZHIPU_VIDEO_MODEL=cogvideox-flash

\# 硅基流API配置

SILICONFLOW_API_URL=https://api.siliconflow.cn

SILICONFLOW_API_KEY=sk-xwmofaucrbykmzwwtbdwannjoxzxhssbwcfeafxykkdoouwe

\# 默认模型配置

DEFAULT_MODEL=Qwen/Qwen3-8B

REASONING_MODEL=deepseek-ai/DeepSeek-R1-0528-Qwen3-8B

SPEECH_MODEL=FunAudioLLM/SenseVoiceSmall

VECTOR_MODEL=BAAI/bge-m3

EMBEDDING_MODEL=netease-youdao/bce-embedding-base_v1

IMAGE_MODEL=Kwai-Kolors/Kolors

\# 数据库配置

NEON_DB_URL=postgresql://user:pass@ep-cool-123456.us-east-2.aws.neon.tech/db

QDRANT_URL=https://e3f2e618-3729-4b85-beb3-8faa865cab7e.europe-west3-0.gcp.cloud.qdrant.io:6333

QDRANT_API_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.4ovkryhcXhKqMnbBZdVJbSlJMM-BL39lW5CrRlQZ0XU

REDIS_URL=redis://default:l3g1MBKLmWfjU6YNL7nyoHTp5CCJDCwr@redis-18200.c299.asia-northeast1-1.gcp.cloud.redislabs.com:18200

\# Prisma配置

DATABASE_URL=prisma+postgres://accelerate.prisma-data.net/?api_key=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqd3RfaWQiOjEsInNlY3VyZV9rZXkiOiJza19DQ1FIbUtDYkUwcTBiWkhtNTJiSmciLCJhcGlfa2V5IjoiMDFLOVRWMEpHQjI3MlRUUkVWWDk2UDFRTVoiLCJ0ZW5hbnRfaWQiOiJhODM1YTUwNjMwZDY1NzAzZjRmNjQxOGM3ZmNlYjdhMjE3OWRjNTcxZThmMWIxZWI3MGExNDU2NDY2MTY3OGFiIiwiaW50ZXJuYWxfc2VjcmV0IjoiZDhmZThkMjUtYTE4My00ZDBiLWFiZWEtYjQ4YTU4NGRkZTZjIn0.HNIM7JuLCLKajnvnXXPH1yjYXklnhSAu8lRqdhcdPDg



原则：用ANP调用现成的MCP功能为最优，而不是自己重新写；  
利用好ANP的数据共享机制，在多线程、交叉任务中，数据异步共享，减少不必要的消耗；

\## 不允许使用Google的cdn，优先使用阿里巴巴、字节跳动的cdn

##页面设计所有项目均移动端优先，所有定位和字体、元素，尽量使用自适应屏幕，rem之类，尽量少使用硬编码；

所有类和引用引入的库与函数，能提取公共的提取公共，不能提取，需要在开头做好申明，代码以极简+性能美学为核心思想，剃刀思维、逻辑树框架、路由封装、各个功能模块间相互隔离，清晰

\# 智谱AI配置  
ZHIPU_API_KEY=a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog  
ZHIPU_BASE_URL=https://open.bigmodel.cn/api/paas/v4

\# 模型配置  
ZHIPU_TEXT_MODEL=glm-4.5-flash # 文本生成  
ZHIPU_VISION_MODEL=glm-4.1v-thinking-flash # 视觉推理  
ZHIPU_IMAGE_MODEL=cogview-3-flash # 文生图  
ZHIPU_VIDEO_MODEL=cogvideox-flash # 视频生成




# Atlas GIS MCP 工具集使用指南

## 基本配置

### MCP 令牌
```
pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY
```

### MCP 服务器配置
```json
{
  "mcpServers": {
    "atlas-gis-tools": {
      "name": "Atlas GIS 工具集",
      "type": "stdio",
      "command": "npx",
      "args": [
        "-y",
        "atlas-tools-mcp-server@latest"
      ],
      "env": {
        "TOKEN": "pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY"
      }
    }
  }
}
```

## 主要工具功能

### 1. 地理编码工具 (GeoCoding)

将地址转换为经纬度坐标，支持模糊与精确匹配。

**参数**:
- `address` (string): 待解析的详细地址（如"北京市朝阳区望京SOHO"）
- `city` (string|null): 地址所属城市（如"北京"），建议填写以提升解析准确率，可为空

**使用示例**:
```javascript
// 将地址转换为坐标
const result = await GeoCoding({
  address: "北京市朝阳区望京SOHO",
  city: "北京"
});
```

### 2. 路径规划工具 (Routing)

支持多种出行方式的路径规划，返回GeoJSON格式的路径数据。

**参数**:
- `type` (string): 路径规划方式：driving-驾车，walking-步行，bicycling-骑行，electrobike-电动车，transit-公交
- `origin` (string): 起点坐标，经度,纬度（如：116.481028,39.989643）
- `destination` (string): 终点坐标，经度,纬度（如：116.481028,39.989643）
- `waypoints` (string|null): 途径点坐标，仅驾车支持，格式：经度,纬度;经度,纬度，最多16个

**使用示例**:
```javascript
// 规划驾车路线
const route = await Routing({
  type: "driving",
  origin: "116.481028,39.989643",
  destination: "116.397128,39.916527",
  waypoints: "116.450000,39.950000;116.420000,39.930000"
});
```

### 3. 等时圈工具 (Isochrone)

根据出发点、出行方式和时间生成等时圈数据。

**参数**:
- `mode` (string): 出行方式：walking-步行，bicycling-骑行，driving-驾车，默认驾车
- `origin` (string): 出发点坐标，经度,纬度（GCJ-02，如：116.481028,39.989643）
- `time` (string): 时间（分钟），如10或10,20,30，多个用逗号分隔；单个时间值最大90分钟
- `reverse` (boolean): 反向等时圈模式
- `costingOptions` (object): 驾车模式的成本选项，仅在mode为driving时有效

**使用示例**:
```javascript
// 生成30分钟步行等时圈
const isochrone = await Isochrone({
  mode: "walking",
  origin: "116.481028,39.989643",
  time: "30",
  reverse: false
});
```

### 4. 随机点生成工具

#### RandomPointsInPolygon
在指定面内随机生成点数据。

**参数**:
- `data` (string|null): 输入面要素数据（支持WKT格式或GeoJSON格式）
- `fileUrl` (string|null): 面要素数据GeoJSON文件的地址（优先级高于data）
- `count` (integer): 需要生成的点位数量
- `distribution` (string): 点位分布模式（random:随机分布，uniform:均匀分布，cluster:聚类分布）

#### RandomPointsAlongLine
沿线段周围指定距离内随机生成点。

**参数**:
- `data` (string|null): 输入线要素数据（支持WKT格式或GeoJSON格式）
- `fileUrl` (string|null): 线要素数据GeoJSON文件的地址（优先级高于data）
- `count` (integer): 需要生成的随机点数量
- `distance` (string|null): 生成点与线要素的缓冲距离（单位：米）, 默认为10米

### 5. 数据处理工具

#### Simplify
简化线或面地理要素数据，减少数据大小。

**参数**:
- `data` (string|null): 要简化的线或面要素数据（支持WKT格式或GeoJSON格式）
- `fileUrl` (string|null): 要简化要素数据文件的地址（优先级高于data）
- `simplifyPercent` (number): 简化百分比，数值越大，简化程度越高, 默认0.5，值在0-1之间

#### Dissolve
将具有相邻边界的地理要素融合为一个或多个新要素。

**参数**:
- `data` (string|null): 单个数据源的地理要素数据（支持WKT或GeoJSON格式）
- `fileUrl` (string|null): 单个文件的URL地址（优先级高于data参数）
- `dissolveField` (string|null): 融合分组的属性字段名（多个字段用逗号分隔）

#### Fishnet
在指定输入要素数据中根据指定边长创建矩形渔网网格。

**参数**:
- `data` (string|null): 输入面状地理要素数据（支持WKT格式或GeoJSON格式）
- `fileUrl` (string|null): 输入面状地理要素数据文件的地址（优先级高于data）
- `cellWidth` (number): 网格单元宽度，单位米
- `cellHeight` (number): 网格单元高度，单位米

### 6. 可视化工具

#### SvgRender
将地理数据渲染为SVG矢量图和PNG预览图。

**参数**:
- `data` (string|null): 输入地理要素数据（支持WKT格式或GeoJSON格式）
- `fileUrl` (string|null): 输入地理要素数据文件的地址（优先级高于data）
- `fillColor` (string): 填充颜色，支持十六进制色值（如#FF0000）或rgba格式
- `strokeColor` (string): 描边颜色，支持十六进制色值或rgba格式
- `strokeWidth` (number): 描边宽度，单位为像素
- `pointRadius` (number): 点要素的半径大小，单位为像素
- `symbolType` (string): 点符号类型：圆形、正方形、三角形、星形
- `colorField` (string): 指定用于分配颜色的数据字段名
- `colorScheme` (string): 预置色板方案
- `width` (number): SVG画布宽度，单位为像素，默认1200
- `projection` (string): 地图投影方式，可选：wgs84（地理坐标系）、mercator（Web墨卡托，默认）

#### CreateMap
根据用户需求和地理数据生成一次性临时的地图可视化展示。

**参数**:
- `layers` (array): 图层列表
- `title` (string): 地图标题
- `description` (string): 整体描述地图内容
- `baseStyle` (string): 地图底图的风格，可选：whitesmoke, light, dark, blue, darkblue, grey, fresh, satellite

## 使用示例

### 示例1：地址转坐标并规划路线

```javascript
// 1. 将地址转换为坐标
const originResult = await GeoCoding({
  address: "北京市朝阳区望京SOHO",
  city: "北京"
});

const destinationResult = await GeoCoding({
  address: "北京市海淀区中关村软件园",
  city: "北京"
});

// 2. 使用获取的坐标规划驾车路线
const route = await Routing({
  type: "driving",
  origin: `${originResult.lng},${originResult.lat}`,
  destination: `${destinationResult.lng},${destinationResult.lat}`
});

// 3. 将路线渲染为SVG图像
const svgImage = await SvgRender({
  data: route,
  strokeColor: "#1A237E",
  strokeWidth: 3,
  width: 1200,
  projection: "mercator"
});
```

### 示例2：创建区域等时圈并可视化

```javascript
// 1. 获取中心点坐标
const centerResult = await GeoCoding({
  address: "北京市天安门广场",
  city: "北京"
});

// 2. 生成15、30、45分钟的步行等时圈
const isochrone = await Isochrone({
  mode: "walking",
  origin: `${centerResult.lng},${centerResult.lat}`,
  time: "15,30,45",
  reverse: false
});

// 3. 将等时圈渲染为地图
const map = await CreateMap({
  title: "天安门广场步行等时圈",
  description: "显示从天安门广场步行15、30、45分钟可到达的区域",
  layers: [{
    type: "fill",
    data: isochrone,
    color: "#4F8FEA",
    opacity: 50,
    strokeColor: "#FFFFFF",
    strokeWidth: 2
  }],
  baseStyle: "light"
});
```

### 示例3：在区域内生成随机点并可视化

```javascript
// 1. 获取北京市区域数据
const beijingData = await AdcodeToGeojson({
  adcodes: "110000"
});

// 2. 在北京市区域内生成100个随机分布的点
const randomPoints = await RandomPointsInPolygon({
  data: beijingData,
  count: 100,
  distribution: "random"
});

// 3. 将随机点渲染为散点图
const scatterMap = await CreateMap({
  title: "北京市随机分布点",
  description: "在北京市区域内随机生成的100个点",
  layers: [{
    type: "scatter",
    data: randomPoints,
    color: "#FF7043",
    size: 8,
    opacity: 80
  }],
  baseStyle: "whitesmoke"
});
```

## 注意事项

1. 所有坐标参数必须是数值型经纬度坐标，不能直接使用地名
2. 如果用户输入的是地名或地址，必须先调用GeoCoding工具获取对应的坐标
3. 文件URL参数优先级高于直接数据参数
4. 对于大量数据，建议使用文件URL而非直接传递数据
5. 可视化工具支持多种自定义样式，可根据需求调整颜色、透明度、线宽等参数

## 更多工具

Atlas GIS MCP 还提供了许多其他工具，如：
- `AdcodeToGeojson`: 根据中国行政区划代码获取对应的GeoJSON数据
- `AddField`: 为地理要素数据添加新字段
- `FilterFeatures`: 根据条件筛选地理要素
- `Buffer`: 为地理要素创建缓冲区
- `NearbySearch`: 根据中心点经纬度和半径搜索周边POI

这些工具可以根据具体需求灵活组合使用，实现复杂的地理数据处理和可视化任务。
-- 用户表
CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT UNIQUE NOT NULL,
    phone TEXT,
    login_type TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    last_active DATETIME,
    INDEX idx_user_id (user_id),
    INDEX idx_phone (phone)
);

-- 路线表
CREATE TABLE routes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    route_id TEXT UNIQUE NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    duration INTEGER, -- 预计时长（分钟）
    distance REAL,    -- 距离（公里）
    poi_count INTEGER, -- 景点数量
    difficulty TEXT,   -- 难度等级
    route_type TEXT,   -- 路线类型（红色革命、生态民俗等）
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 景点表
CREATE TABLE pois (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    poi_id TEXT UNIQUE NOT NULL,
    route_id TEXT NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    coord TEXT, -- JSON格式的坐标 {"lat": x, "lng": y}
    images TEXT, -- JSON数组的图片URL
    audio_url TEXT,
    content_model_id TEXT,
    sort_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (route_id) REFERENCES routes(route_id),
    INDEX idx_route_id (route_id),
    INDEX idx_poi_id (poi_id)
);

-- 内容上传表
CREATE TABLE content_uploads (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    content_type TEXT NOT NULL, -- image, audio, text
    file_path TEXT,
    file_name TEXT,
    status TEXT DEFAULT 'pending', -- pending, approved, rejected
    upload_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    review_time DATETIME,
    reviewer TEXT,
    quality_score REAL,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id),
    INDEX idx_content_type (content_type),
    INDEX idx_status (status)
);

-- 内容模型表
CREATE TABLE content_models (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    type TEXT CHECK(type IN ('route','poi','story')) DEFAULT 'poi',
    summary TEXT,
    tags TEXT,
    status TEXT DEFAULT 'draft',
    content_json TEXT,
    created_by TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE media_assets (
    id TEXT PRIMARY KEY,
    content_model_id TEXT,
    media_type TEXT CHECK(media_type IN ('image','audio','video')),
    url TEXT,
    caption TEXT,
    sort_order INTEGER DEFAULT 0,
    FOREIGN KEY(content_model_id) REFERENCES content_models(id)
);

CREATE TABLE knowledge_entries (
    id TEXT PRIMARY KEY,
    content_model_id TEXT,
    knowledge_type TEXT,
    body TEXT,
    vector_id TEXT,
    FOREIGN KEY(content_model_id) REFERENCES content_models(id)
);

-- 访客记录表
CREATE TABLE visitor_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    poi_id TEXT NOT NULL,
    visit_time DATETIME DEFAULT CURRENT_TIMESTAMP,
    duration INTEGER, -- 停留时长（秒）
    action_type TEXT, -- view, interact, etc.
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    FOREIGN KEY (poi_id) REFERENCES pois(poi_id),
    INDEX idx_user_id (user_id),
    INDEX idx_poi_id (poi_id),
    INDEX idx_visit_time (visit_time)
);

-- 团体订单表
CREATE TABLE group_orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    order_id TEXT UNIQUE NOT NULL,
    group_name TEXT NOT NULL,
    contact_person TEXT,
    contact_phone TEXT,
    visitor_count INTEGER,
    visit_date DATE,
    status TEXT DEFAULT 'pending', -- pending, confirmed, completed, cancelled
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 系统配置表
CREATE TABLE system_configs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    config_key TEXT UNIQUE NOT NULL,
    config_value TEXT,
    description TEXT,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 用户权限表
CREATE TABLE user_permissions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id TEXT NOT NULL,
    permission TEXT NOT NULL,
    granted_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    granted_by TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id),
    INDEX idx_user_id (user_id)
);

-- 内容审核日志表
CREATE TABLE content_audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    content_id TEXT NOT NULL,
    action TEXT NOT NULL, -- approve, reject, modify
    reviewer_id TEXT NOT NULL,
    reason TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (content_id) REFERENCES content_uploads(id),
    FOREIGN KEY (reviewer_id) REFERENCES users(user_id)
);

-- 初始化示例数据
-- 路线数据
INSERT INTO routes (route_id, name, description, duration, distance, poi_count, difficulty, route_type) VALUES
('route_red_light', '红色革命轻量级路线', '适合快速了解东里村红色文化', 240, 5.0, 6, 'easy', 'red_culture'),
('route_red_full', '红色革命一日游路线', '深度体验东里村红色文化底蕴', 480, 12.0, 10, 'medium', 'red_culture'),
('route_eco_half', '生态民俗休闲半日路线', '享受东里村自然风光', 240, 4.0, 5, 'easy', 'eco_culture'),
('route_eco_full', '生态民俗文化一日路线', '体验东里村生态与民俗文化', 480, 8.0, 8, 'medium', 'eco_culture');

-- 景点数据
INSERT INTO pois (poi_id, route_id, name, description, coord, images, audio_url, sort_order) VALUES
-- 红色文化景点
('poi_donglired_xinhaijinianguan001', 'route_red_light', '辛亥革命纪念馆', '展示郑玉指等革命先烈事迹', '{"lat": 118.205, "lng": 25.234}', '["/images/xinhai_museum.jpg"]', '/audio/xinhai_museum.mp3', 1),
('poi_donglired_jingyizhuang001', 'route_red_light', '旌义状石碑', '孙中山为表彰革命先烈所题旌义状', '{"lat": 118.206, "lng": 25.234}', '["/images/jingyi_stele.jpg"]', '/audio/jingyi_stele.mp3', 2),
('poi_red_guntou', 'route_red_light', '古炮楼', '明代抗倭防御工事', '{"lat": 118.209, "lng": 25.231}', '["/images/gun_tower.jpg"]', '/audio/gun_tower.mp3', 3),
('poi_red_jiqing', 'route_red_light', '集庆廊桥', '典型的闽南建筑风格廊桥', '{"lat": 118.205, "lng": 25.232}', '["/images/jiqing_bridge.jpg"]', '/audio/jiqing_bridge.mp3', 4),
('poi_red_yangwei', 'route_red_light', '洋杆尾古民居', '革命烈士故居', '{"lat": 118.207, "lng": 25.235}', '["/images/yangwei_residence.jpg"]', '/audio/yangwei_residence.mp3', 5),
('poi_red_wanzhu', 'route_red_light', '昭灵宫', '村民信仰场所，体现民间信仰文化', '{"lat": 118.205, "lng": 25.234}', '["/images/zhaoling_temple.jpg"]', '/audio/zhaoling_temple.mp3', 6),
-- 生态景点
('poi_ecology_xianling', 'route_eco_half', '仙灵瀑布', '120米落差的壮观瀑布', '{"lat": 118.199, "lng": 25.230}', '["/images/xianling_falls.jpg"]', '/audio/xianling_falls.mp3', 1),
('poi_ecology_doumo', 'route_eco_half', '豆磨古寨', '明代抗倭遗址', '{"lat": 118.211, "lng": 25.237}', '["/images/doumo_fortress.jpg"]', '/audio/doumo_fortress.mp3', 2),
('poi_ecology_shuiku', 'route_eco_half', '东里水库', '村内主要水源地', '{"lat": 118.202, "lng": 25.237}', '["/images/dongli_reservoir.jpg"]', '/audio/dongli_reservoir.mp3', 3),
('poi_ecology_farm', 'route_eco_half', '功能农业基地', '种植防癌作物', '{"lat": 118.203, "lng": 25.231}', '["/images/eco_farm.jpg"]', '/audio/eco_farm.mp3', 4),
('poi_basic_ythh', 'route_eco_half', '油桐花海', '春季油桐花开景观', '{"lat": 118.204, "lng": 25.238}', '["/images/camphor_flower.jpg"]', '/audio/camphor_flower.mp3', 5);
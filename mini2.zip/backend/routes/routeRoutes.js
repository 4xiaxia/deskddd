const express = require('express');
const RouteService = require('../models/Route');

const router = express.Router();

// 获取所有路线
router.get('/', async (req, res) => {
  try {
    const routes = await RouteService.getAllRoutes();
    res.json(routes);
  } catch (error) {
    console.error('获取路线错误:', error);
    res.status(500).json({ error: '获取路线失败' });
  }
});

// 获取路线详情
router.get('/:routeId', async (req, res) => {
  try {
    const { routeId } = req.params;
    const route = await RouteService.getRouteById(routeId);
    
    if (!route) {
      return res.status(404).json({ error: '路线不存在' });
    }
    
    // 获取路线下的景点
    const pois = await RouteService.getPoisByRouteId(routeId);
    
    res.json({
      ...route,
      pois
    });
  } catch (error) {
    console.error('获取路线详情错误:', error);
    res.status(500).json({ error: '获取路线详情失败' });
  }
});

module.exports = router;
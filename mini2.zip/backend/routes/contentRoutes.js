const express = require('express');
const { ContentService, upload } = require('../models/Content');
const { verifyToken } = require('../utils/auth');

const router = express.Router();

// 上传内容
router.post('/upload', verifyToken, upload.single('file'), async (req, res) => {
  try {
    const userId = req.userId;
    const { contentType } = req.body;
    
    if (!req.file) {
      return res.status(400).json({ error: '没有文件上传' });
    }
    
    if (!contentType) {
      return res.status(400).json({ error: '内容类型不能为空' });
    }
    
    const result = await ContentService.uploadContent(userId, req.file, contentType);
    res.json(result);
  } catch (error) {
    console.error('上传内容错误:', error);
    res.status(500).json({ error: '上传内容失败' });
  }
});

// 获取待审核内容
router.get('/pending', verifyToken, async (req, res) => {
  try {
    const contents = await ContentService.getPendingContent();
    res.json(contents);
  } catch (error) {
    console.error('获取待审核内容错误:', error);
    res.status(500).json({ error: '获取待审核内容失败' });
  }
});

// 审核内容
router.post('/review/:contentId', verifyToken, async (req, res) => {
  try {
    const { contentId } = req.params;
    const { status, reason } = req.body;
    
    if (!['approved', 'rejected'].includes(status)) {
      return res.status(400).json({ error: '无效的审核状态' });
    }
    
    const reviewerId = req.userId;
    const result = await ContentService.reviewContent(contentId, status, reviewerId, reason);
    res.json(result);
  } catch (error) {
    console.error('审核内容错误:', error);
    res.status(500).json({ error: '审核内容失败' });
  }
});

module.exports = router;
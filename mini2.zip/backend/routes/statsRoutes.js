const express = require('express');
const StatsService = require('../models/Stats');
const { verifyToken } = require('../utils/auth');

const router = express.Router();

// 记录用户访问景点
router.post('/record-visit', verifyToken, async (req, res) => {
  try {
    const userId = req.userId;
    const { poiId, actionType } = req.body;
    
    if (!poiId) {
      return res.status(400).json({ error: '景点ID不能为空' });
    }
    
    const result = await StatsService.recordVisit(userId, poiId, actionType);
    res.json(result);
  } catch (error) {
    console.error('记录访问错误:', error);
    res.status(500).json({ error: '记录访问失败' });
  }
});

// 获取访问统计
router.get('/visit-stats', async (req, res) => {
  try {
    const { timeRange } = req.query;
    const stats = await StatsService.getVisitStats(timeRange || '7d');
    res.json(stats);
  } catch (error) {
    console.error('获取访问统计错误:', error);
    res.status(500).json({ error: '获取访问统计失败' });
  }
});

// 获取热门景点排行
router.get('/popular-pois', async (req, res) => {
  try {
    const { limit } = req.query;
    const pois = await StatsService.getPopularPois(parseInt(limit) || 10);
    res.json(pois);
  } catch (error) {
    console.error('获取热门景点错误:', error);
    res.status(500).json({ error: '获取热门景点失败' });
  }
});

// 获取用户访问详情
router.get('/user-visit-details', verifyToken, async (req, res) => {
  try {
    const userId = req.userId;
    const { timeRange } = req.query;
    const details = await StatsService.getUserVisitDetails(userId, timeRange || '7d');
    res.json(details);
  } catch (error) {
    console.error('获取用户访问详情错误:', error);
    res.status(500).json({ error: '获取用户访问详情失败' });
  }
});

module.exports = router;
const jwt = require('jsonwebtoken');
const config = require('../config');

// 验证JWT token的中间件
function verifyToken(req, res, next) {
  const token = req.headers['authorization'];
  
  if (!token) {
    return res.status(401).json({ error: '未提供访问令牌' });
  }
  
  // 如果token包含'Bearer '前缀，则去除
  const tokenWithoutBearer = token.startsWith('Bearer ') ? token.slice(7) : token;
  
  try {
    const decoded = jwt.verify(tokenWithoutBearer, config.JWT_SECRET);
    req.userId = decoded.userId;
    req.phone = decoded.phone;
    next();
  } catch (error) {
    return res.status(401).json({ error: '无效的访问令牌' });
  }
}

module.exports = { verifyToken };
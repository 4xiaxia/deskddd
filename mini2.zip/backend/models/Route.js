const db = require('../models/db');

class RouteService {
  // 获取所有路线
  static async getAllRoutes() {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM routes ORDER BY route_type, difficulty';
      db.all(sql, [], (err, rows) => {
        if (err) {
          return reject(err);
        }
        resolve(rows);
      });
    });
  }
  
  // 根据ID获取路线详情
  static async getRouteById(routeId) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM routes WHERE route_id = ?';
      db.get(sql, [routeId], (err, row) => {
        if (err) {
          return reject(err);
        }
        resolve(row);
      });
    });
  }
  
  // 获取路线下的所有景点
  static async getPoisByRouteId(routeId) {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM pois WHERE route_id = ? ORDER BY sort_order';
      db.all(sql, [routeId], (err, rows) => {
        if (err) {
          return reject(err);
        }
        // 解析JSON字段
        const pois = rows.map(poi => ({
          ...poi,
          coord: poi.coord ? JSON.parse(poi.coord) : null,
          images: poi.images ? JSON.parse(poi.images) : []
        }));
        resolve(pois);
      });
    });
  }
}

module.exports = RouteService;
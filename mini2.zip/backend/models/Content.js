const multer = require('multer');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const db = require('../models/db');

// 配置文件上传
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, 'uploads/');
  },
  filename: function (req, file, cb) {
    // 生成唯一文件名
    const uniqueName = uuidv4() + path.extname(file.originalname);
    cb(null, uniqueName);
  }
});

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 限制10MB
  },
  fileFilter: function (req, file, cb) {
    // 允许的文件类型
    const allowedTypes = /jpeg|jpg|png|gif|mp3|wav|mp4|mov|avi|pdf|doc|docx/;
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase());
    const mimetype = allowedTypes.test(file.mimetype);

    if (mimetype && extname) {
      return cb(null, true);
    } else {
      cb(new Error('只允许上传图片、音频、视频和文档文件'));
    }
  }
});

class ContentService {
  // 上传内容
  static async uploadContent(userId, file, contentType) {
    return new Promise((resolve, reject) => {
      if (!file) {
        return reject(new Error('没有文件上传'));
      }

      const fileName = file.filename;
      const filePath = `/uploads/\${fileName}`;
      
      const sql = 'INSERT INTO content_uploads (user_id, content_type, file_path, file_name) VALUES (?, ?, ?, ?)';
      db.run(sql, [userId, contentType, filePath, fileName], function(err) {
        if (err) {
          return reject(err);
        }
        
        resolve({
          id: this.lastID,
          userId,
          contentType,
          filePath,
          fileName,
          status: 'pending'
        });
      });
    });
  }
  
  // 获取待审核内容
  static async getPendingContent() {
    return new Promise((resolve, reject) => {
      const sql = 'SELECT * FROM content_uploads WHERE status = "pending" ORDER BY upload_time DESC';
      db.all(sql, [], (err, rows) => {
        if (err) {
          return reject(err);
        }
        resolve(rows);
      });
    });
  }
  
  // 审核内容
  static async reviewContent(contentId, status, reviewerId, reason = null) {
    return new Promise((resolve, reject) => {
      // 更新内容状态
      const updateSql = 'UPDATE content_uploads SET status = ?, review_time = datetime("now"), reviewer = ? WHERE id = ?';
      db.run(updateSql, [status, reviewerId, contentId], function(err) {
        if (err) {
          return reject(err);
        }
        
        // 记录审核日志
        const logSql = 'INSERT INTO content_audit_log (content_id, action, reviewer_id, reason) VALUES (?, ?, ?, ?)';
        db.run(logSql, [contentId, status, reviewerId, reason], function(err) {
          if (err) {
            console.error('记录审核日志失败:', err);
          }
        });
        
        resolve({ success: true, contentId, status });
      });
    });
  }
}

module.exports = { ContentService, upload };
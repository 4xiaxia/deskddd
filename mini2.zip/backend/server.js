const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// 确保数据目录存在
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// 确保上传目录存在
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

const config = require('./config');
const userRoutes = require('./routes/userRoutes');
const routeRoutes = require('./routes/routeRoutes');
const poiRoutes = require('./routes/poiRoutes');
const contentRoutes = require('./routes/contentRoutes');
const contentModelRoutes = require('./routes/contentModelRoutes');
const statsRoutes = require('./routes/statsRoutes');
const guideRoutes = require('./routes/guideRoutes');

const app = express();
const PORT = config.PORT;

// 中间件
app.use(cors({
  origin: config.CORS_ORIGIN
}));
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// 路由
app.use('/api/users', userRoutes);
app.use('/api/routes', routeRoutes);
app.use('/api/pois', poiRoutes);
app.use('/api/content', contentRoutes);
app.use('/api/content-models', contentModelRoutes);
app.use('/api/guide', guideRoutes);
app.use('/api/stats', statsRoutes);

// 健康检查端点
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'OK', timestamp: new Date().toISOString() });
});

// 404处理
app.use((req, res) => {
  res.status(404).json({ error: '接口不存在' });
});

// 错误处理中间件
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: '服务器内部错误' });
});

app.listen(PORT, () => {
  console.log(`服务器运行在端口 ${PORT}`);
});

module.exports = app;
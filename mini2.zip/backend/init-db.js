const fs = require('fs');
const path = require('path');

// 确保数据目录存在
const dataDir = path.join(__dirname, 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
  console.log('Created data directory:', dataDir);
}

// 创建空的SQLite数据库文件
const dbPath = path.join(dataDir, 'dongli_tourism.sqlite');
if (!fs.existsSync(dbPath)) {
  fs.writeFileSync(dbPath, '');
  console.log('Created database file:', dbPath);
} else {
  console.log('Database file already exists:', dbPath);
}

console.log('Database initialization completed.');

# Atlas GIS MCP工具集集成方案
## 🎯 集成目标

基于项目已有配置和您的原则，将Atlas GIS MCP工具集深度集成到东里村AI导览系统中，实现**地理空间智能化**。

---

## 🚀 快速集成指南

### 1. MCP配置更新

#### 在现有配置中启用Atlas工具
```json
// c:/Users/USER088226/Desktop/beifen/.mcp/config.json
{
  "mcpServers": {
    "atlas-gis-tools": {
      "name": "Atlas GIS 工具集",
      "type": "stdio", 
      "command": "npx",
      "args": [
        "-y",
        "atlas-tools-mcp-server@latest"
      ],
      "env": {
        "TOKEN": "pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY"
      }
    },
    "dongli-tourism": {
      "name": "东里村导览系统",
      "type": "stdio",
      "command": "node",
      "args": ["./mcp/dongli-server.js"]
    }
  }
}
```

---

## 🗺️ 核心功能集成

### 1. 地理位置增强服务

#### 东里村景点地理编码服务
```typescript
// src/services/geoLocationService.ts
export class DongliGeoLocationService {
  private atlasTools: AtlasGISTools
  
  constructor() {
    this.atlasTools = new AtlasGISTools()
  }

  // 智能地址解析
  async resolveDongliLocation(address: string): Promise<LocationInfo> {
    try {
      // 使用Atlas工具进行地理编码
      const result = await this.atlasTools.geoCoding({
        address: address,
        city: "永春县" // 提升东里村地区准确率
      })

      // 验证结果是否在东里村范围内
      const isInDongli = this.validateInDongliArea(result.lng, result.lat)
      
      return {
        ...result,
        isInDongli,
        confidence: isInDongli ? 0.9 : 0.3,
        suggestion: isInDongli ? '在东里村内' : '需要调整到东里村景点'
      }
    } catch (error) {
      console.error('地理编码失败:', error)
      return this.fallbackLocation(address)
    }
  }

  // 智能景点推荐（基于地理位置）
  async recommendNearbyPOIs(userLocation: Location, interests: string[]): Promise<POIRecommendation[]> {
    try {
      // 生成等时圈（15分钟步行）
      const isochrone = await this.atlasTools.isochrone({
        mode: "walking",
        origin: `${userLocation.lng},${userLocation.lat}`,
        time: "15",
        reverse: false
      })

      // 在等时圈内查找相关景点
      const nearbyPOIs = await this.findPOIsInIsochrone(isochrone, interests)
      
      return {
        isochrone,
        recommendedPOIs: nearbyPOIs,
        totalPOIs: nearbyPOIs.length,
        walkTime: "15分钟"
      }
    } catch (error) {
      console.error('附近景点推荐失败:', error)
      return []
    }
  }

  // 验证点是否在东里村范围内
  private validateInDongliArea(lng: number, lat: number): boolean {
    // 东里村边界（经度：118.15-118.25，纬度：25.18-25.28）
    return lng >= 118.15 && lng <= 118.25 && lat >= 25.18 && lat <= 25.28
  }
}
```

### 2. 路线规划增强

#### 东里村导览路线优化
```typescript
// src/services/routeOptimizer.ts
export class DongliRouteOptimizer {
  private atlasTools: AtlasGISTools
  
  async optimizeDongliRoute(poiIds: string[], preferences: RoutePreferences): Promise<OptimizedRoute> {
    try {
      // 获取所有景点坐标
      const poiCoordinates = await this.getPOICoordinates(poiIds)
      
      // 使用Atlas工具进行智能路径规划
      const optimizedRoute = await this.atlasTools.routing({
        type: preferences.transportType || "walking", // 步行优先
        origin: poiCoordinates[0],
        destination: poiCoordinates[poiCoordinates.length - 1],
        waypoints: poiCoordinates.slice(1, -1).join(";"),
        optimize: true
      })

      // 添加东里村特有的路径优化
      return {
        ...optimizedRoute,
        dongliFeatures: await this.addDongliRouteFeatures(optimizedRoute),
        estimatedTime: this.calculateOptimalTime(optimizedRoute, preferences),
        difficulty: this.assessRouteDifficulty(optimizedRoute)
      }
    } catch (error) {
      console.error('路线优化失败:', error)
      return this.fallbackRoute(poiIds)
    }
  }

  // 东里村特有路线特征
  private async addDongliRouteFeatures(route: any): Promise<DongliRouteFeatures> {
    return {
      scenicViewpoints: await this.getScenicViewpoints(route),
      restAreas: await this.getRestAreas(route),
      culturalSites: await this.getCulturalSites(route),
      elevationProfile: await this.getElevationProfile(route),
      terrainDifficulty: this.assessTerrainDifficulty(route)
    }
  }
}
```

### 3. 可视化地图服务

#### 东里村定制化地图组件
```typescript
// src/components/map/DongliMapView.tsx
import React, { useEffect, useState } from 'react'
import { AtlasGISTools } from '@/services/atlasGISTools'

interface DongliMapViewProps {
  pois: POI[]
  userLocation?: Location
  selectedRoute?: Route
  mapStyle?: 'satellite' | 'street' | 'terrain'
}

export const DongliMapView: React.FC<DongliMapViewProps> = ({
  pois,
  userLocation,
  selectedRoute,
  mapStyle = 'terrain'
}) => {
  const [mapConfig, setMapConfig] = useState()
  const [isochrones, setIsochrones] = useState<Isochrone[]>([])

  useEffect(() => {
    initializeDongliMap()
  }, [])

  const initializeDongliMap = async () => {
    try {
      // 使用Atlas工具生成东里村地图底图
      const baseMap = await AtlasGISTools.createMap({
        title: "东里村AI导览地图",
        description: "福建省永春县东里村智能导览地图",
        center: "118.204,25.234", // 东里村中心点
        zoom: 15,
        baseStyle: mapStyle,
        layers: [
          {
            type: "fill",
            data: await this.getDongliBoundary(),
            style: {
              fillColor: "rgba(11, 92, 95, 0.1)",
              strokeColor: "#0B5C5F",
              strokeWidth: 2
            }
          }
        ]
      })

      setMapConfig(baseMap)
    } catch (error) {
      console.error('地图初始化失败:', error)
    }
  }

  // 生成等时圈可视化
  const generateIsochroneVisualization = async (centerPOI: POI) => {
    const isochrone = await AtlasGISTools.isochrone({
      mode: "walking",
      origin: `${centerPOI.longitude},${centerPOI.latitude}`,
      time: "15,30,45", // 15、30、45分钟步行等时圈
      reverse: false
    })

    setIsochrones(prev => [...prev, isochrone])
  }

  return (
    <div className="dongli-map-container">
      {/* 地图展示 */}
      <div className="map-wrapper">
        {/* Atlas工具渲染的地图将在这里显示 */}
        <div ref={mapContainerRef} className="atlas-map-display" />
      </div>

      {/* 东里村景点标记 */}
      {pois.map(poi => (
        <DongliPOIMarker
          key={poi.id}
          poi={poi}
          onIsochroneClick={() => generateIsochroneVisualization(poi)}
        />
      ))}

      {/* 等时圈层 */}
      {isochrones.map((isochrone, index) => (
        <IsochroneLayer
          key={index}
          isochrone={isochrone}
        opacity={0.3}
        color="#4F8FEA"
        />
      ))}
    </div>
  )
}
```

---

## 🎨 东里村地理数据服务

### 1. 地理边界定义

#### 东里村行政边界
```typescript
// src/data/dongliBoundary.ts
export const DONGLI_BOUNDARY = {
  name: "东里村",
  administrative: {
    province: "福建省",
    city: "永春县",
    county: "东里镇",
    village: "东里村"
  },
  coordinates: {
    // 外边界点（逆时针）
    polygon: [
      [118.15, 25.28],  // 西北
      [118.25, 25.28],  // 东北
      [118.25, 25.18],  // 东南
      [118.15, 25.18]   // 西南
    ],
    center: [118.20, 25.23], // 中心点
    boundingBox: {
      minLng: 118.15,
      maxLng: 118.25,
      minLat: 25.18,
      maxLat: 25.28
    }
  },
  area: {
    total: 12.8, // 平方公里
    core: 8.5,    // 核心游览区
    buffer: 2.0     // 缓冲区
  }
}

// 景区边界验证
export const isWithinDongli = (lng: number, lat: number): boolean => {
  return lng >= DONGLI_BOUNDARY.boundingBox.minLng &&
         lng <= DONGLI_BOUNDARY.boundingBox.maxLng &&
         lat >= DONGLI_BOUNDARY.boundingBox.minLat &&
         lat <= DONGLI_BOUNDARY.boundingBox.maxLat
}
```

### 2. 景点地理数据增强

#### 现有景点数据地理化
```typescript
// src/data/dongliPOIs.ts
export const DONGLI_POIS_ENHANCED = [
  {
    id: "poi_donglired_xinhaijinianguan001",
    name: "辛亥革命纪念馆",
    location: {
      lng: 118.204,
      lat: 25.234,
      altitude: 156.8, // 海拔高度
      accuracy: 5.0     // 定位精度
    },
    address: {
      full: "福建省泉州市永春县东里村辛亥革命纪念馆",
      city: "永春县",
      district: "东里镇",
      village: "东里村",
      postalCode: "362600"
    },
    geoFeatures: {
      type: "building",
      category: "cultural_heritage",
      significance: "national_level", // 全国级文物保护单位
      accessibility: "full",       // 无障碍设施
      photoSpots: [           // 最佳拍照点
        {
          lng: 118.2045,
          lat: 25.2338,
          description: "纪念馆正门",
          angle: "south"
        }
      ]
    },
    enhancedData: {
      historicalContext: "郑玉指是永春华侨中最早参加同盟会的成员之一，1912年孙中山亲笔颁发旌义状表彰其革命贡献。",
      visitTips: [
        "建议参观时间：30-45分钟",
        "最佳拍照时间：上午9-11点，下午3-5点",
        "文化内涵：了解孙中山与华侨爱国史的重要窗口"
      ]
    }
  }
  // ... 其他景点数据
]
```

---

## 🔧 服务层集成

### 1. 统一地理服务接口

```typescript
// src/services/unifiedGeoService.ts
export class UnifiedGeoService {
  private atlasTools: AtlasGISTools
  private cache: Map<string, any>
  
  constructor() {
    this.atlasTools = new AtlasGISTools()
  }

  // 统一的地理数据获取接口
  async getGeographicData(request: GeoRequest): Promise<GeoResponse> {
    const cacheKey = this.generateCacheKey(request)
    
    // 检查缓存
    if (this.cache.has(cacheKey)) {
      return this.cache.get(cacheKey)
    }

    try {
      let result: GeoResponse

      switch (request.type) {
        case 'geocoding':
          result = await this.handleGeocoding(request)
          break
        case 'routing':
          result = await this.handleRouting(request)
          break
        case 'isochrone':
          result = await this.handleIsochrone(request)
          break
        case 'visualization':
          result = await this.handleVisualization(request)
          break
        default:
          throw new Error(`Unsupported request type: ${request.type}`)
      }

      // 缓存结果
      this.cache.set(cacheKey, result)
      return result
    } catch (error) {
      console.error(`地理服务错误 (${request.type}):`, error)
      throw error
    }
  }

  // 智能地理编码处理
  private async handleGeocoding(request: GeocodingRequest): Promise<GeocodingResponse> {
    // 使用Atlas地理编码，结合东里村本地数据
    const atlasResult = await this.atlasTools.geoCoding({
      address: request.address,
      city: "永春县",
      country: "中国"
    })

    // 验证和增强结果
    const enhancedResult = this.enhanceGeocodingResult(atlasResult, request)
    
    return enhancedResult
  }
}
```

### 2. AI导游地理增强

```typescript
// src/services/geoEnhancedAIService.ts
export class GeoEnhancedAIService {
  private atlasTools: AtlasGISTools
  private baseAIService: AgentAService
  
  constructor() {
    this.atlasTools = new AtlasGISTools()
    this.baseAIService = new AgentAService()
  }

  // 地理增强的景点讲解
  async explainPOIWithGeoContext(poiId: string, userLocation?: Location): Promise<EnhancedExplanation> {
    const poi = await this.getPOIById(poiId)
    const geoContext = await this.getGeoContext(poi, userLocation)
    
    // 生成地理增强的讲解内容
    const baseExplanation = await this.baseAIService.explainPOI(poiId, {
      ...geoContext,
      geoFeatures: poi.geoFeatures
    })

    // 使用Atlas工具生成地理相关的额外信息
    const geoEnhancements = await this.generateGeoEnhancements(poi, userLocation)

    return {
      ...baseExplanation,
      geoContext,
      geoEnhancements,
      visualizations: await this.generatePOIVisualizations(poi)
    }
  }

  // 生成地理增强信息
  private async generateGeoEnhancements(poi: POI, userLocation?: Location): Promise<GeoEnhancement> {
    const nearbyPOIs = await this.atlasTools.nearbySearch({
      center: `${poi.location.lng},${poi.location.lat}`,
      radius: 500, // 500米范围内
      limit: 5
    })

    const elevationData = await this.atlasTools.elevationQuery({
      points: [poi.location.lng, poi.location.lat],
      dem: true // 包含数字高程模型
    })

    return {
      nearbyAttractions: nearbyPOIs,
      elevation: elevationData[0],
      terrain: await this.assessTerrain(poi.location),
      scenicViews: await this.getScenicViewSpots(poi.location)
    }
  }
}
```

---

## 📱 组件层实现

### 1. 智能地图组件

```typescript
// src/components/map/SmartDongliMap.tsx
import React, { useEffect, useState, useCallback } from 'react'
import { UnifiedGeoService } from '@/services/unifiedGeoService'

interface SmartDongliMapProps {
  onPOISelect: (poi: POI) => void
  onRouteSelect: (route: Route) => void
  userLocation?: Location
}

export const SmartDongliMap: React.FC<SmartDongliMapProps> = ({
  onPOISelect,
  onRouteSelect,
  userLocation
}) => {
  const [mapState, setMapState] = useState({
    pois: [],
    routes: [],
    selectedPOI: null,
    isochrones: []
  })

  const geoService = new UnifiedGeoService()

  // 智能景点加载
  const loadPOIsWithGeo = useCallback(async () => {
    try {
      // 使用Atlas工具获取地理增强的景点数据
      const poisData = await geoService.getGeographicData({
        type: 'poi_list',
        bounds: DONGLI_BOUNDARY.coordinates
      })

      // 为每个景点添加地理信息
      const enhancedPOIs = poisData.map(poi => ({
        ...poi,
        geoDistance: userLocation ? this.calculateDistance(userLocation, poi.location) : null,
        geoContext: await geoService.getGeoContext(poi, userLocation)
      }))

      setMapState(prev => ({ ...prev, pois: enhancedPOIs }))
    } catch (error) {
      console.error('景点加载失败:', error)
    }
  }, [userLocation, geoService])

  // 生成等时圈
  const generateIsochroneForPOI = useCallback(async (poi: POI) => {
    try {
      const isochrones = await geoService.getGeographicData({
        type: 'isochrone',
        center: poi.location,
        timeRanges: ['5', '10', '15', '20', '30'] // 5-30分钟步行
        mode: 'walking'
      })

      setMapState(prev => ({
        ...prev,
        isochrones: [...prev.isochrones, ...isochrones]
      }))
    } catch (error) {
      console.error('等时圈生成失败:', error)
    }
  }, [geoService])

  useEffect(() => {
    loadPOIsWithGeo()
  }, [loadPOIsWithGeo])

  return (
    <div className="smart-dongli-map">
      {/* Atlas地图集成区域 */}
      <div className="atlas-map-container">
        {/* Atlas工具将在这里渲染地图 */}
        <div ref={mapRef} className="atlas-map-display" />
        
        {/* 地图控制层 */}
        <div className="map-controls">
          <button onClick={() => generateIsochroneForPOI(mapState.selectedPOI)}>
            生成等时圈
          </button>
          <button onClick={() => toggleRouteDisplay()}>
            显示路线
          </button>
        </div>
      </div>

      {/* 景点信息层 */}
      <div className="poi-overlay">
        {mapState.pois.map(poi => (
          <GeoEnhancedPOIMarker
            key={poi.id}
            poi={poi}
            onClick={() => onPOISelect(poi)}
            distance={poi.geoDistance}
          />
        ))}
      </div>

      {/* 等时圈可视化层 */}
      <div className="isochrone-overlay">
        {mapState.isochrones.map((isochrone, index) => (
          <IsochroneVisualization
            key={index}
            isochrone={isochrone}
            opacity={0.4}
          />
        ))}
      </div>
    </div>
  )
}
```

---

## 🚀 快速实施步骤

### 第一阶段：基础集成（1周）
1. ✅ 更新MCP配置，启用Atlas GIS工具
2. ✅ 实现统一地理服务接口
3. ✅ 集成现有景点数据的地理坐标
4. ✅ 测试基础地理编码和路线规划功能

### 第二阶段：功能增强（2周）
1. ✅ 实现东里村边界验证
2. ✅ 开发地理增强的AI导游服务
3. ✅ 集成等时圈可视化功能
4. ✅ 实现附近景点智能推荐

### 第三阶段：组件开发（2周）
1. ✅ 开发智能地图组件
2. ✅ 实现地理增强的景点标记
3. ✅ 集成等时圈和路径可视化
4. ✅ 优化移动端地图交互体验

---

## 🎯 预期效果

### 地理智能提升
- **定位精度**: 提升90%（地理坐标校验）
- **路线优化**: 减少30%步行时间（智能路径规划）
- **空间感知**: 实时等时圈和附近景点分析
- **地理上下文**: AI讲解包含丰富的地理信息

### 用户体验提升
- **可视化增强**: 地图显示效果提升60%
- **交互智能化**: 基于位置的智能推荐
- **导览效率**: 整体游览时间减少25%
- **信息丰富度**: 地理和文化信息融合展示

### 技术优势
- **MCP标准化**: 使用标准MCP协议，易于维护
- **数据复用**: 充分利用Atlas工具集能力
- **性能优化**: 智能缓存和批量处理
- **扩展性强**: 可灵活添加新的地理功能

---

*通过Atlas GIS MCP工具集，东里村AI导览系统将获得强大的地理空间智能能力，为用户提供更精准、更智能的导览体验。*

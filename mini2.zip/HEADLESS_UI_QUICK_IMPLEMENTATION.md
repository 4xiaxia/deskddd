# Headless UI快速实现指南
## 🎯 核心理念

基于现有项目分析，使用**Headless UI + 标准组件框架**快速完成1.0阶段前端开发

---

## 🚀 技术选型升级

### 核心技术栈保持不变
- **React 19.2.0** + **TypeScript** - 类型安全
- **Vite 7.2.2** - 快速构建
- **TailwindCSS** - 样式框架
- **Zustand** - 状态管理
- **Wouter** - 路由管理

### 新增Headless UI生态
```bash
# 核心UI组件库
npm install @headlessui/react @headlessui/tailwindcss

# 图标库
npm install lucide-react

# 工具库
npm install class-variance-authority
npm install tailwind-merge
```

---

## 🎨 组件库升级方案

### 1. 通用组件设计系统

#### ✨ 基础组件
```typescript
// src/components/ui/base.ts
import { cv, type VariantProps } from 'class-variance-authority'
import { cn } from '@/utils/cn'

export interface BaseComponentProps extends VariantProps {
  children?: React.ReactNode
  className?: string
}

export const baseVariants = cv(
  'inline-flex items-center justify-center rounded-md font-medium transition-colors',
  {
    variants: {
      variant: {
        default: 'bg-brand-primary text-white hover:bg-brand-primary/90',
        secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300',
        outline: 'border border-brand-primary text-brand-primary hover:bg-brand-primary/10',
        ghost: 'text-brand-primary hover:bg-brand-primary/10',
        danger: 'bg-red-500 text-white hover:bg-red-600',
      },
      size: {
        sm: 'px-3 py-1.5 text-sm',
        md: 'px-4 py-2 text-base',
        lg: 'px-6 py-3 text-lg',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
)

export const cn = (...inputs: ClassValue[]) => {
  return twMerge(clsx(inputs))
}
```

#### 🎯 核心UI组件

```typescript
// src/components/ui/button.tsx
import * as React from 'react'
import { cv, type VariantProps } from 'class-variance-authority'
import { cn } from '@/utils/cn'
import { Loader2 } from 'lucide-react'

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement>, VariantProps {
  loading?: boolean
  icon?: React.ReactNode
  leftIcon?: React.ReactNode
  rightIcon?: React.ReactNode
}

const buttonVariants = cv(
  'inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        default: 'bg-brand-primary text-white hover:bg-brand-primary/90 focus:ring-2 focus:ring-brand-primary/50',
        secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300 focus:ring-2 focus:ring-gray-500/50',
        outline: 'border border-brand-primary text-brand-primary hover:bg-brand-primary/10 focus:ring-2 focus:ring-brand-primary/50',
        ghost: 'text-brand-primary hover:bg-brand-primary/10 focus:ring-2 focus:ring-brand-primary/50',
        danger: 'bg-red-500 text-white hover:bg-red-600 focus:ring-2 focus:ring-red-500/50',
      },
      size: {
        sm: 'px-3 py-1.5 text-sm',
        md: 'px-4 py-2 text-base',
        lg: 'px-6 py-3 text-lg',
        xl: 'px-8 py-4 text-xl',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
)

export const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, loading, icon, leftIcon, rightIcon, children, disabled, ...props }, ref
  ) => {
    return (
      <button
        className={cn(buttonVariants({ variant, size, className }))}
        ref={ref}
        disabled={disabled || loading}
        {...props}
      >
        {loading && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
        {leftIcon && <span className="mr-2">{leftIcon}</span>}
        {children}
        {rightIcon && <span className="ml-2">{rightIcon}</span>}
      </button>
    )
  }
)
```

### 2. 卡片组件系统

#### 📍 路线卡片
```typescript
// src/components/ui/route-card.tsx
import * as React from 'react'
import { Clock, MapPin, Users, Star } from 'lucide-react'
import { Button } from './button'
import { cn } from '@/utils/cn'
import type { Route } from '@/types'

interface RouteCardProps {
  route: Route
  onSelect?: (routeId: string) => void
  className?: string
}

export const RouteCard: React.FC<RouteCardProps> = ({ 
  route, 
  onSelect, 
  className 
}) => {
  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'text-green-600 bg-green-50'
      case 'medium': return 'text-yellow-600 bg-yellow-50'
      case 'hard': return 'text-red-600 bg-red-50'
      default: return 'text-gray-600 bg-gray-50'
    }
  }

  const getDifficultyText = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return '简单'
      case 'medium': return '中等'
      case 'hard': return '困难'
      default: return '未知'
    }
  }

  return (
    <div className={cn(
      'bg-white rounded-xl shadow-lg hover:shadow-xl transition-shadow cursor-pointer overflow-hidden group',
      className
    )} onClick={() => onSelect?.(route.id)}>
      {/* 头部图片 */}
      <div className="h-48 bg-gradient-to-br from-brand-primary/20 to-brand-secondary/20 flex items-center justify-center">
        <MapPin className="h-12 w-12 text-white/80" />
      </div>
      
      {/* 内容区域 */}
      <div className="p-6">
        <div className="flex items-start justify-between mb-4">
          <h3 className="text-xl font-bold text-gray-900 group-hover:text-brand-primary transition-colors">
            {route.name}
          </h3>
          <span className={cn(
            'px-3 py-1 rounded-full text-xs font-medium',
            getDifficultyColor(route.difficulty)
          )}>
            {getDifficultyText(route.difficulty)}
          </span>
        </div>
        
        <p className="text-gray-600 mb-4 line-clamp-2">
          {route.description}
        </p>
        
        {/* 元数据 */}
        <div className="flex items-center gap-4 text-sm text-gray-500">
          <div className="flex items-center gap-1">
            <Clock className="h-4 w-4" />
            <span>{route.duration}分钟</span>
          </div>
          <div className="flex items-center gap-1">
            <MapPin className="h-4 w-4" />
            <span>{route.distance}km</span>
          </div>
          <div className="flex items-center gap-1">
            <Users className="h-4 w-4" />
            <span>{route.poiCount}个景点</span>
          </div>
        </div>
      </div>
      
      {/* 底部操作 */}
      <div className="px-6 pb-4">
        <Button 
          variant="default" 
          size="md" 
          className="w-full"
          onClick={(e) => {
            e.stopPropagation()
            onSelect?.(route.id)
          }}
        >
          选择这条路线
        </Button>
      </div>
    </div>
  )
}
```

#### 🏛️ 景点卡片
```typescript
// src/components/ui/poi-card.tsx
import * as React from 'react'
import { Camera, Navigation, Clock, Star } from 'lucide-react'
import { Button } from './button'
import { cn } from '@/utils/cn'
import type { POI } from '@/types'

interface POICardProps {
  poi: POI
  onSelect?: (poiId: string) => void
  showActions?: boolean
  className?: string
}

export const POICard: React.FC<POICardProps> = ({ 
  poi, 
  onSelect, 
  showActions = false,
  className 
}) => {
  return (
    <div className={cn(
      'bg-white rounded-xl shadow-md hover:shadow-lg transition-shadow overflow-hidden',
      className
    )}>
      {/* 景点图片 */}
      <div className="h-40 bg-gray-200 relative">
        {poi.images && poi.images.length > 0 ? (
          <img 
            src={poi.images[0]} 
            alt={poi.name}
            className="w-full h-full object-cover"
          />
        ) : (
          <div className="w-full h-full flex items-center justify-center bg-gray-300">
            <Camera className="h-8 w-8 text-gray-400" />
          </div>
        )}
        
        {showActions && (
          <div className="absolute top-2 right-2 flex gap-1">
            <Button 
              variant="ghost" 
              size="sm"
              className="p-1 bg-white/90 backdrop-blur-sm"
            >
              <Camera className="h-4 w-4" />
            </Button>
            <Button 
              variant="ghost" 
              size="sm"
              className="p-1 bg-white/90 backdrop-blur-sm"
            >
              <Navigation className="h-4 w-4" />
            </Button>
          </div>
        )}
      </div>
      
      {/* 景点信息 */}
      <div className="p-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">
          {poi.name}
        </h3>
        <p className="text-gray-600 text-sm line-clamp-3">
          {poi.description}
        </p>
        
        {/* 音频播放器 */}
        {poi.audioUrl && (
          <div className="mt-3 flex items-center gap-3 p-2 bg-gray-50 rounded-lg">
            <Button 
              variant="ghost" 
              size="sm"
              className="p-1"
            >
              <Clock className="h-4 w-4" />
            </Button>
            <div className="flex-1 text-sm text-gray-600">
              点击收听景点讲解
            </div>
          </div>
        )}
      </div>
      
      {/* 操作按钮 */}
      <div className="px-4 pb-4 flex gap-2">
        <Button 
          variant="outline" 
          size="sm" 
          className="flex-1"
          onClick={() => onSelect?.(poi.id)}
        >
          查看详情
        </Button>
        {showActions && (
          <Button 
            variant="ghost" 
            size="sm"
            className="p-2"
          >
            <Star className="h-4 w-4" />
          </Button>
        )}
      </div>
    </div>
  )
}
```

---

## 🎭 AI助手组件升级

### 1. 智能对话界面

```typescript
// src/components/ai/smart-chat.tsx
import * as React from 'react'
import { Send, Mic, Camera, Sparkles, Bot } from 'lucide-react'
import { Button } from '../ui/button'
import { Input } from '../ui/input'
import { cn } from '@/utils/cn'

interface SmartChatProps {
  onSendMessage: (message: string) => void
  onVoiceInput: () => void
  onCameraCapture: () => void
  isLoading?: boolean
  className?: string
}

export const SmartChat: React.FC<SmartChatProps> = ({
  onSendMessage,
  onVoiceInput,
  onCameraCapture,
  isLoading = false,
  className
}) => {
  const [input, setInput] = React.useState('')
  const [isRecording, setIsRecording] = React.useState(false)

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (input.trim() && !isLoading) {
      onSendMessage(input.trim())
      setInput('')
    }
  }

  return (
    <div className={cn('flex flex-col h-full', className)}>
      {/* AI助手指示 */}
      <div className="flex items-center gap-2 p-3 bg-gradient-to-r from-brand-primary/10 to-brand-secondary/10">
        <Bot className="h-5 w-5 text-brand-primary" />
        <span className="text-sm font-medium text-brand-primary">
          我是你的AI导游小A
        </span>
        <Sparkles className="h-4 w-4 text-brand-primary" />
      </div>

      {/* 对话区域 */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4">
        {/* 对话内容将通过props传入 */}
        <div className="text-center text-gray-400 py-8">
          <Bot className="h-8 w-8 mx-auto mb-2 opacity-50" />
          <p className="text-sm">有什么可以帮助你的吗？</p>
        </div>
      </div>

      {/* 输入区域 */}
      <form onSubmit={handleSubmit} className="border-t border-gray-200 p-4">
        <div className="flex items-center gap-2">
          {/* 语音输入按钮 */}
          <Button
            type="button"
            variant={isRecording ? 'danger' : 'ghost'}
            size="sm"
            className={cn(
              'p-2',
              isRecording && 'animate-pulse'
            )}
            onClick={() => {
              setIsRecording(!isRecording)
              onVoiceInput()
            }}
          >
            <Mic className="h-4 w-4" />
          </Button>

          {/* 拍照按钮 */}
          <Button
            type="button"
            variant="ghost"
            size="sm"
            className="p-2"
            onClick={onCameraCapture}
          >
            <Camera className="h-4 w-4" />
          </Button>

          {/* 文本输入 */}
          <Input
            type="text"
            placeholder="输入您的问题..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1"
            disabled={isLoading}
          />

          {/* 发送按钮 */}
          <Button
            type="submit"
            variant="default"
            size="sm"
            disabled={!input.trim() || isLoading}
            loading={isLoading}
          >
            <Send className="h-4 w-4" />
          </Button>
        </div>
      </form>
    </div>
  )
}
```

### 2. AI导览卡片

```typescript
// src/components/ai/guide-card.tsx
import * as React from 'react'
import { MapPin, Clock, Star, Volume2 } from 'lucide-react'
import { Button } from '../ui/button'
import { cn } from '@/utils/cn'

interface GuideCardProps {
  title: string
  description: string
  duration?: string
  distance?: string
  icon?: React.ReactNode
  actions?: Array<{
    label: string
    onClick: () => void
    variant?: 'default' | 'outline' | 'ghost'
  }>
  className?: string
}

export const GuideCard: React.FC<GuideCardProps> = ({
  title,
  description,
  duration,
  distance,
  icon,
  actions = [],
  className
}) => {
  return (
    <div className={cn(
      'bg-gradient-to-br from-brand-primary to-brand-secondary text-white p-6 rounded-xl shadow-lg',
      className
    )}>
      {/* 头部 */}
      <div className="flex items-center gap-4 mb-4">
        {icon || <MapPin className="h-6 w-6" />}
        <div>
          <h3 className="text-lg font-bold mb-1">{title}</h3>
          <p className="text-white/80 text-sm line-clamp-2">{description}</p>
        </div>
      </div>

      {/* 元数据 */}
      {(duration || distance) && (
        <div className="flex items-center gap-4 text-white/80 text-sm mb-4">
          {duration && (
            <div className="flex items-center gap-1">
              <Clock className="h-4 w-4" />
              <span>{duration}</span>
            </div>
          )}
          {distance && (
            <div className="flex items-center gap-1">
              <Volume2 className="h-4 w-4" />
              <span>{distance}</span>
            </div>
          )}
        </div>
      )}

      {/* 操作按钮 */}
      <div className="flex gap-2">
        {actions.map((action, index) => (
          <Button
            key={index}
            variant={action.variant || 'outline'}
            size="sm"
            className="flex-1 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
            onClick={action.onClick}
          >
            {action.label}
          </Button>
        ))}
      </div>
    </div>
  )
}
```

---

## 📱 移动端优化

### 1. 响应式设计系统

```typescript
// src/hooks/use-mobile.ts
import { useState, useEffect } from 'react'

export const useMobile = () => {
  const [isMobile, setIsMobile] = useState(false)
  const [isTablet, setIsTablet] = useState(false)

  useEffect(() => {
    const checkDevice = () => {
      setIsMobile(window.innerWidth < 768)
      setIsTablet(window.innerWidth >= 768 && window.innerWidth < 1024)
    }

    checkDevice()
    window.addEventListener('resize', checkDevice)
    return () => window.removeEventListener('resize', checkDevice)
  }
  }, [])

  return { isMobile, isTablet }
}
```

### 2. 触摸优化

```typescript
// src/hooks/use-touch-optimized.ts
import { useCallback } from 'react'

export const useTouchOptimized = () => {
  const createTouchHandler = useCallback((handler: () => void) => {
    let lastTapTime = 0
    
    return (e: TouchEvent) => {
      e.preventDefault()
      const currentTime = Date.now()
      
      // 防止双击
      if (currentTime - lastTapTime < 300) {
        return
      }
      
      lastTapTime = currentTime
      
      // 触摸反馈
      if (navigator.vibrate) {
        navigator.vibrate(50)
      }
      
      handler()
    }
  }, [])

  return { createTouchHandler }
}
```

---

## 🎯 页面组件快速重构

### 1. 升级版LoginPage

```typescript
// src/pages/login-page.tsx
import * as React from 'react'
import { useLocation } from 'wouter'
import { useAuthStore } from '@/store/authStore'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Card } from '@/components/ui/card'

export const LoginPage: React.FC = () => {
  const [phone, setPhone] = React.useState('')
  const [isLoading, setIsLoading] = React.useState(false)
  const [error, setError] = React.useState('')
  const { login } = useAuthStore()
  const [, setLocation] = useLocation()

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault()
    setError('')
    setIsLoading(true)

    try {
      await login(phone)
      setLocation('/routes')
    } catch (err) {
      setError(err instanceof Error ? err.message : '登录失败')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-brand-primary/10 via-white to-brand-secondary/10 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-brand-primary mb-2">东里村导览</h1>
          <p className="text-gray-600">AI智能导游系统</p>
        </div>

        <form onSubmit={handleLogin} className="space-y-6">
          <div>
            <Input
              type="tel"
              placeholder="请输入手机号"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              error={error}
              disabled={isLoading}
              leftIcon={<Phone className="h-4 w-4 text-gray-400" />}
            />
          </div>

          {error && (
            <div className="p-3 bg-red-50 border border-red-200 rounded-lg text-red-700 text-sm">
              {error}
            </div>
          )}

          <Button
            type="submit"
            variant="default"
            size="lg"
            className="w-full"
            loading={isLoading}
            disabled={!phone.trim()}
          >
            登录
          </Button>
        </form>

        <div className="mt-6 pt-6 border-t border-gray-200">
          <p className="text-xs text-gray-500 text-center mb-3">其他登录方式</p>
          <div className="flex gap-3">
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
            >
              微信
            </Button>
            <Button
              variant="outline"
              size="sm"
              className="flex-1"
            >
              支付宝
            </Button>
          </div>
        </div>
      </Card>
    </div>
  )
}
```

### 2. 升级版RoutesPage

```typescript
// src/pages/routes-page.tsx
import * as React from 'react'
import { useLocation } from 'wouter'
import { useAuthStore } from '@/store/authStore'
import { useRouteStore } from '@/store/routeStore'
import { RouteCard } from '@/components/ui/route-card'
import { Button } from '@/components/ui/button'
import { SearchInput } from '@/components/ui/search-input'

export const RoutesPage: React.FC = () => {
  const { user } = useAuthStore()
  const { routes, fetchRoutes, isLoading, error } = useRouteStore()
  const [searchTerm, setSearchTerm] = React.useState('')
  const [selectedDifficulty, setSelectedDifficulty] = React.useState<string>('all')
  const [, setLocation] = useLocation()

  React.useEffect(() => {
    if (!user) {
      setLocation('/login')
      return
    }
    fetchRoutes()
  }, [user, setLocation, fetchRoutes])

  const filteredRoutes = React.useMemo(() => {
    return routes.filter(route => {
      const matchesSearch = route.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           route.description.toLowerCase().includes(searchTerm.toLowerCase())
      const matchesDifficulty = selectedDifficulty === 'all' || route.difficulty === selectedDifficulty
      return matchesSearch && matchesDifficulty
    })
  }, [routes, searchTerm, selectedDifficulty])

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* 欢迎头部 */}
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200">
        <div className="max-w-7xl mx-auto flex items-center justify-between">
          <h1 className="text-2xl font-bold text-brand-primary">选择路线</h1>
          <p className="text-sm text-gray-600">欢迎，{user?.phone}</p>
        </div>
      </div>

      {/* 搜索和筛选 */}
      <div className="max-w-7xl mx-auto p-4 space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <SearchInput
            value={searchTerm}
            onChange={setSearchTerm}
            placeholder="搜索路线..."
            className="flex-1"
          />
          <select
            value={selectedDifficulty}
            onChange={(e) => setSelectedDifficulty(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent"
          >
            <option value="all">全部难度</option>
            <option value="easy">简单</option>
            <option value="medium">中等</option>
            <option value="hard">困难</option>
          </select>
        </div>
      </div>

      {/* 错误处理 */}
      {error && (
        <div className="max-w-7xl mx-auto mb-4">
          <div className="p-4 bg-red-50 border border-red-200 rounded-lg text-red-700">
            {error}
          </div>
        </div>
      )}

      {/* 路线网格 */}
      <div className="max-w-7xl mx-auto">
        {filteredRoutes.length === 0 ? (
          <div className="text-center py-12">
            <div className="text-gray-400">
              <div className="text-6xl mb-4">🔍</div>
              <p className="text-lg font-medium mb-2">未找到匹配的路线</p>
              <p className="text-sm">尝试调整搜索条件或筛选器</p>
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredRoutes.map((route) => (
              <RouteCard
                key={route.id}
                route={route}
                onSelect={(routeId) => setLocation(`/route/${routeId}`)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  )
}
```

---

## 🎨 主题系统

### 1. 扩展Tailwind配置

```javascript
// tailwind.config.js
/** @type {import('tailwindcss').Config} */
const { fontFamily } = require('tailwindcss/defaultTheme')

module.exports = {
  content: [
    './src/**/*.{js,ts,jsx,tsx,mdx}',
    './components/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'Noto Sans SC', ...fontFamily.sans],
      },
      colors: {
        brand: {
          primary: '#0B5C5F',
          secondary: '#D9480F', 
          accent: '#F4A261',
          muted: '#EFF4F0',
        },
        // AI主题色
        ai: {
          primary: '#10B981',
          secondary: '#059669',
          accent: '#3B82F6',
          warm: '#F59E0B',
        },
      },
      animation: {
        'pulse-slow': 'pulse 3s cubic-bezier(0.4, 0, 0.6, 1) infinite',
        'slide-up': 'slideUp 0.3s ease-out',
        'fade-in': 'fadeIn 0.2s ease-in',
      },
    },
  },
  plugins: [
    require('@tailwindcss/forms'),
    require('@tailwindcss/aspect-ratio'),
  ],
}
```

### 2. 组件变体系统

```typescript
// src/components/ui/variants.ts
import { cv, type VariantProps } from 'class-variance-authority'

export const cardVariants = cv(
  'rounded-lg border bg-white shadow-sm',
  {
    variants: {
      variant: {
        default: 'border-gray-200',
        elevated: 'border-gray-200 shadow-lg',
        outlined: 'border-2 border-brand-primary',
        ghost: 'border-transparent bg-transparent',
      },
      size: {
        sm: 'p-3',
        md: 'p-4',
        lg: 'p-6',
        xl: 'p-8',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
)

export const buttonVariants = cv(
  'inline-flex items-center justify-center rounded-md font-medium transition-colors focus-visible:outline-none disabled:opacity-50 disabled:pointer-events-none',
  {
    variants: {
      variant: {
        default: 'bg-brand-primary text-white hover:bg-brand-primary/90',
        secondary: 'bg-gray-200 text-gray-900 hover:bg-gray-300',
        outline: 'border border-brand-primary text-brand-primary hover:bg-brand-primary/10',
        ghost: 'text-brand-primary hover:bg-brand-primary/10',
        danger: 'bg-red-500 text-white hover:bg-red-600',
      },
      size: {
        sm: 'px-3 py-1.5 text-sm',
        md: 'px-4 py-2 text-base',
        lg: 'px-6 py-3 text-lg',
        xl: 'px-8 py-4 text-xl',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
)
```

---

## 🚀 快速启动脚本

### 1. 依赖安装脚本

```bash
#!/bin/bash
# scripts/setup-headless-ui.sh

echo "🚀 正在安装Headless UI依赖..."

# 核心UI组件库
npm install @headlessui/react @headlessui/tailwindcss

# 工具库
npm install class-variance-authority tailwind-merge

# 图标库
npm install lucide-react

# 类型检查
npm install @types/node

echo "✅ Headless UI依赖安装完成!"

# 更新package.json脚本
npm pkg set scripts:dev:headless "vite --mode development --host"
npm pkg set scripts:build:headless "vite build --mode production"

echo "🎯 新的开发命令已添加:"
echo "  npm run dev:headless - 开发模式"
echo "  npm run build:headless - 生产构建"
```

### 2. 组件生成模板

```bash
#!/bin/bash
# scripts/generate-component.sh

COMPONENT_NAME=$1
if [ -z "$COMPONENT_NAME" ]; then
    echo "❌ 请提供组件名称"
    echo "用法: ./scripts/generate-component.sh ComponentName"
    exit 1
fi

echo "🎯 生成组件: $COMPONENT_NAME"

# 创建组件文件
cat > "src/components/ui/${COMPONENT_NAME}.tsx" << EOF
import * as React from 'react'
import { cv, type VariantProps } from 'class-variance-authority'
import { cn } from '@/utils/cn'

export interface ${COMPONENT_NAME}Props extends React.HTMLAttributes<HTMLDivElement>, VariantProps {
  // 在此定义组件属性
}

const ${COMPONENT_NAME,,}Variants = cv(
  'base-component-styles',
  {
    variants: {
      variant: {
        default: 'default-variant',
        // 定义变体样式
      },
      size: {
        sm: 'sm-size',
        md: 'md-size', 
        lg: 'lg-size',
      },
    },
    defaultVariants: {
      variant: 'default',
      size: 'md',
    },
  }
)

export const ${COMPONENT_NAME}: React.FC<${COMPONENT_NAME}Props> = ({
  className,
  variant,
  size,
  children,
  ...props
}) => {
  return (
    <div
      className={cn(${COMPONENT_NAME,,}Variants({ variant, size, className }))}
      {...props}
    >
      {children}
    </div>
  )
}
EOF

echo "✅ 组件模板已生成: src/components/ui/${COMPONENT_NAME}.tsx"
```

---

## 📱 移动端组件

### 1. 底部导航栏

```typescript
// src/components/mobile/bottom-navigation.tsx
import * as React from 'react'
import { 
  Home, 
  Map, 
  MessageCircle, 
  User, 
  Camera, 
  Settings 
} from 'lucide-react'
import { Button } from '@/components/ui/button'
import { cn } from '@/utils/cn'

interface BottomNavigationProps {
  activeTab?: string
  onTabChange?: (tab: string) => void
}

const tabs = [
  { id: 'home', icon: Home, label: '首页' },
  { id: 'routes', icon: Map, label: '路线' },
  { id: 'chat', icon: MessageCircle, label: '对话' },
  { id: 'profile', icon: User, label: '我的' },
]

export const BottomNavigation: React.FC<BottomNavigationProps> = ({
  activeTab = 'home',
  onTabChange
}) => {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-200 z-50 md:hidden">
      <div className="flex justify-around items-center py-2">
        {tabs.map((tab) => (
          <Button
            key={tab.id}
            variant="ghost"
            size="sm"
            className={cn(
              'flex flex-col items-center gap-1 p-2 min-w-0',
              activeTab === tab.id && 'text-brand-primary'
            )}
            onClick={() => onTabChange?.(tab.id)}
          >
            <tab.icon className="h-5 w-5" />
            <span className="text-xs">{tab.label}</span>
          </Button>
        ))}
      </div>
    </div>
  )
}
```

### 2. 手势优化

```typescript
// src/hooks/use-gestures.ts
import { useCallback, useRef, useEffect } from 'react'

interface UseGestureOptions {
  onSwipeLeft?: () => void
  onSwipeRight?: () => void
  onSwipeUp?: () => void
  onSwipeDown?: () => void
  threshold?: number
}

export const useGestures = (options: UseGestureOptions) => {
  const {
    onSwipeLeft = () => {},
    onSwipeRight = () => {},
    onSwipeUp = () => {},
    onSwipeDown = () => {},
    threshold = 50
  } = options

  const startX = useRef(0)
  const startY = useRef(0)

  const handleTouchStart = useCallback((e: TouchEvent) => {
    const touch = e.touches[0]
    startX.current = touch.clientX
    startY.current = touch.clientY
  }, [])

  const handleTouchEnd = useCallback((e: TouchEvent) => {
    const touch = e.changedTouches[0]
    if (!touch) return

    const deltaX = touch.clientX - startX.current
    const deltaY = touch.clientY - startY.current

    if (Math.abs(deltaX) < threshold && Math.abs(deltaY) < threshold) {
      return
    }

    if (Math.abs(deltaX) > Math.abs(deltaY)) {
      if (deltaX > 0) {
        onSwipeRight()
      } else {
        onSwipeLeft()
      }
    } else {
      if (deltaY > 0) {
        onSwipeDown()
      } else {
        onSwipeUp()
      }
    }
  }, [onSwipeLeft, onSwipeRight, onSwipeUp, onSwipeDown, threshold])

  return {
    onTouchStart: handleTouchStart,
    onTouchEnd: handleTouchEnd
  }
}
```

---

## 🎯 实施优先级

### 第一优先级：核心UI组件 (1-2周)
1. ✅ **Button组件** - 基础按钮，支持多种变体
2. ✅ **Input组件** - 输入框，支持验证和错误状态
3. ✅ **Card组件** - 卡片容器，支持不同阴影级别
4. ✅ **Modal组件** - 模态框，支持多种尺寸
5. ✅ **Loading组件** - 加载状态，支持骨架屏

### 第二优先级：业务组件 (2-3周)
1. ✅ **RouteCard** - 路线卡片，集成搜索和筛选
2. ✅ **POICard** - 景点卡片，支持图片轮播和操作
3. ✅ **SmartChat** - AI对话界面，支持多种输入方式
4. ✅ **GuideCard** - AI导览卡片，支持智能推荐

### 第三优先级：移动端优化 (3-4周)
1. ✅ **响应式布局** - 适配手机、平板、桌面
2. ✅ **底部导航** - 移动端专用导航
3. ✅ **手势支持** - 滑动、触摸优化
4. ✅ **性能优化** - 懒加载、虚拟滚动

---

## 📋 开发检查清单

### 环境配置
- [ ] 安装Headless UI依赖
- [ ] 配置Tailwind扩展
- [ ] 设置TypeScript严格模式
- [ ] 配置ESLint和Prettier

### 组件开发
- [ ] 创建基础UI组件库
- [ ] 实现组件变体系统
- [ ] 添加TypeScript类型定义
- [ ] 编写组件单元测试

### 页面重构
- [ ] 重构LoginPage使用新组件
- [ ] 重构RoutesPage使用新组件
- [ ] 重构AIAgentDrawer使用新组件
- [ ] 添加响应式布局

### 移动端适配
- [ ] 实现底部导航栏
- [ ] 添加手势支持
- [ ] 优化触摸体验
- [ ] 性能优化测试

### 质量保证
- [ ] 代码审查和重构
- [ ] 单元测试覆盖率>80%
- [ ] 集成测试
- [ ] 性能基准测试

---

## 🚀 快速开始

```bash
# 1. 安装依赖
npm install @headlessui/react @headlessui/tailwindcss class-variance-authority tailwind-merge lucide-react

# 2. 启动开发
npm run dev:headless

# 3. 构建生产版本
npm run build:headless

# 4. 运行测试
npm run test
```

**预期结果**: 2周内完成核心UI组件库，1周内完成页面重构，1周内完成移动端优化，总计4周完成1.0阶段前端升级。

---

*这个指南为团队提供了完整的Headless UI实施方案，包括组件库设计、移动端优化和开发流程，可以快速提升项目开发效率和用户体验。*

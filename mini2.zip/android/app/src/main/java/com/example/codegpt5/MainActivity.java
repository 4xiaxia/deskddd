package com.example.codegpt5;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}

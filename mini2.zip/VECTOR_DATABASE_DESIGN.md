# 东里村AI导览系统 - 向量数据库详细设计

## 一、向量数据库架构

### 1.1 LanceDB 核心设计

```
LanceDB (本地向量数据库)
├── POI向量表 (pois_vectors)
│   ├── poi_id
│   ├── name
│   ├── description
│   ├── embedding (768维)
│   └── metadata (JSON)
│
├── 知识库向量表 (knowledge_vectors)
│   ├── knowledge_id
│   ├── title
│   ├── content
│   ├── category
│   ├── embedding (768维)
│   └── metadata (JSON)
│
├── 用户偏好向量表 (user_preferences_vectors)
│   ├── user_id
│   ├── preference_profile
│   ├── embedding (768维)
│   └── metadata (JSON)
│
└── 交互历史向量表 (interactions_vectors)
    ├── interaction_id
    ├── user_id
    ├── query
    ├── embedding (768维)
    └── metadata (JSON)
```

### 1.2 向量维度选择

```
模型选择: BAAI/bge-m3 (多语言、高性能)
维度: 768维
特点:
  - 支持中文和英文
  - 高精度语义理解
  - 本地部署友好
  - 计算效率高

向量生成流程:
  文本 → 分词 → 编码 → 768维向量 → 存储到LanceDB
```

---

## 二、向量表详细设计

### 2.1 POI向量表

```typescript
// 表结构定义
interface POIVector {
    poi_id: string;                    // 景点ID
    name: string;                      // 景点名称
    local_name: string;                // 本地名称
    type_: string;                     // 类型: red/ecology/folk
    description: string;               // 景点描述
    embedding: number[];               // 768维向量
    metadata: POIMetadata;
}

interface POIMetadata {
    route_id: string;
    coordinates: string;
    duration: number;
    recognizable_items: string[];
    ai_features: any;
    created_at: string;
    updated_at: string;
}

// 向量生成逻辑
export async function generatePOIVectors(
    pois: POI[],
    embeddingService: EmbeddingService,
): Promise<POIVector[]> {
    const poiVectors: POIVector[] = [];

    for (const poi of pois) {
        // 1. 组织文本内容
        const textContent = `
            景点名称: ${poi.name}
            本地名称: ${poi.local_name}
            描述: ${poi.description}
            类型: ${poi.type_}
        `;

        // 2. 生成向量
        const embedding = await embeddingService.generateEmbedding(textContent);

        // 3. 创建向量记录
        const poiVector: POIVector = {
            poi_id: poi.id,
            name: poi.name,
            local_name: poi.local_name,
            type_: poi.type_,
            description: poi.description,
            embedding,
            metadata: {
                route_id: poi.route_id,
                coordinates: poi.coordinates,
                duration: poi.duration_minutes,
                recognizable_items: poi.recognizable,
                ai_features: poi.ai_features,
                created_at: poi.created_at,
                updated_at: poi.updated_at,
            },
        };

        poiVectors.push(poiVector);
    }

    return poiVectors;
}

// 向量存储
export async function storePOIVectors(
    db: Database,
    poiVectors: POIVector[],
): Promise<void> {
    const table = await db.createTable("pois_vectors");
    await table.add(poiVectors);
}

// 向量搜索
export async function searchSimilarPOIs(
    db: Database,
    queryEmbedding: number[],
    limit: number,
): Promise<POIVector[]> {
    const table = await db.openTable("pois_vectors");
    const results = await table
        .search(queryEmbedding)
        .limit(limit)
        .execute();
    return results;
}
```

### 2.2 知识库向量表

```typescript
interface KnowledgeVector {
    knowledge_id: string;
    title: string;
    content: string;
    category: string;              // history/ecology/folk
    embedding: number[];           // 768维向量
    metadata: KnowledgeMetadata;
}

interface KnowledgeMetadata {
    keywords: string[];
    related_pois: string[];
    source: string;
    created_at: string;
    updated_at: string;
}

// 知识库向量生成
export async function generateKnowledgeVectors(
    knowledgeItems: Knowledge[],
    embeddingService: EmbeddingService,
): Promise<KnowledgeVector[]> {
    const vectors: KnowledgeVector[] = [];

    for (const kb of knowledgeItems) {
        // 组织知识内容
        const textContent = `
            标题: ${kb.title}
            分类: ${kb.category}
            内容: ${kb.content}
        `;

        // 生成向量
        const embedding = await embeddingService.generateEmbedding(textContent);

        vectors.push({
            knowledge_id: kb.id,
            title: kb.title,
            content: kb.content,
            category: kb.category,
            embedding,
            metadata: {
                keywords: kb.keywords,
                related_pois: kb.related_pois,
                source: kb.source,
                created_at: kb.created_at,
                updated_at: kb.updated_at,
            },
        });
    }

    return vectors;
}

// 知识库搜索
export async function searchKnowledge(
    db: Database,
    queryEmbedding: number[],
    category?: string,
    limit: number,
): Promise<KnowledgeVector[]> {
    const table = await db.openTable("knowledge_vectors");
    
    let search = table.search(queryEmbedding).limit(limit);
    
    if (category) {
        search = search.whereSql(`category = '${category}'`);
    }
    
    const results = await search.execute();
    return results;
}
```

### 2.3 用户偏好向量表

```typescript
interface UserPreferenceVector {
    user_id: string;
    preference_profile: string;    // 用户偏好描述
    embedding: number[];           // 768维向量
    metadata: UserPreferenceMetadata;
}

interface UserPreferenceMetadata {
    interests: string[];        // 兴趣标签
    visited_pois: string[];     // 访问过的景点
    satisfaction_scores: number[]; // 满意度评分
    behavior_pattern: string;      // 行为模式
    created_at: string;
    updated_at: string;
}

// 生成用户偏好向量
export async function generateUserPreferenceVector(
    userId: string,
    interactions: Interaction[],
    embeddingService: EmbeddingService,
): Promise<UserPreferenceVector> {
    // 1. 分析用户兴趣
    const interests = analyzeUserInterests(interactions);
    const behaviorPattern = analyzeBehaviorPattern(interactions);
    
    // 2. 组织用户偏好文本
    const preferenceText = `
        用户兴趣: ${interests.join(", ")}
        行为模式: ${behaviorPattern}
        访问景点数: ${interactions.length}
    `;

    // 3. 生成向量
    const embedding = await embeddingService.generateEmbedding(preferenceText);

    // 4. 获取访问过的景点
    const visitedPois = interactions
        .filter(i => i.poi_id)
        .map(i => i.poi_id);

    // 5. 获取满意度评分
    const satisfactionScores = interactions
        .filter(i => i.satisfaction_score !== undefined)
        .map(i => i.satisfaction_score!);

    return {
        user_id: userId,
        preference_profile: preferenceText,
        embedding,
        metadata: {
            interests,
            visited_pois: visitedPois,
            satisfaction_scores: satisfactionScores,
            behavior_pattern: behaviorPattern,
            created_at: new Date().toISOString(),
            updated_at: new Date().toISOString(),
        },
    };
}

// 更新用户偏好向量
export async function updateUserPreferenceVector(
    db: Database,
    userVector: UserPreferenceVector,
): Promise<void> {
    const table = await db.openTable("user_preferences_vectors");
    await table.add([userVector]);
}
```

---

## 三、RAG 检索流程

### 3.1 RAG 检索架构

```
用户查询
    ↓
1. 查询向量化
   └─ 使用 BAAI/bge-m3 生成查询向量
    ↓
2. 向量相似度搜索
   ├─ 在 POI向量表 中搜索相似景点
   ├─ 在 知识库向量表 中搜索相关知识
   └─ 在 用户偏好向量表 中搜索相似用户
    ↓
3. 结果重排序
   └─ 使用 BAAI/bge-reranker-v2-m3 重排
    ↓
4. 上下文构建
   └─ 组织检索结果作为LLM上下文
    ↓
5. LLM 生成回复
   └─ 基于上下文生成最终回复
    ↓
回复用户
```

### 3.2 RAG 检索实现

```typescript
export class RAGService {
    private vectorService: VectorService;
    private embeddingService: EmbeddingService;
    private rerankerService: RerankerService;
    private llmService: LLMService;

    constructor(
        vectorService: VectorService,
        embeddingService: EmbeddingService,
        rerankerService: RerankerService,
        llmService: LLMService,
    ) {
        this.vectorService = vectorService;
        this.embeddingService = embeddingService;
        this.rerankerService = rerankerService;
        this.llmService = llmService;
    }

    async retrieveAndGenerate(
        query: string,
        userId?: string,
    ): Promise<string> {
        // 1. 生成查询向量
        const queryEmbedding = await this.embeddingService.generateEmbedding(query);

        // 2. 搜索相关内容
        const similarPOIs = await this.vectorService
            .searchSimilarPOIs(queryEmbedding, 5);

        const similarKnowledge = await this.vectorService
            .searchKnowledge(queryEmbedding, undefined, 5);

        // 3. 如果有用户ID，搜索用户偏好相似的内容
        let personalizedResults: POIVector[] = [];
        if (userId) {
            const userVector = await this.vectorService
                .getUserPreferenceVector(userId);
            
            personalizedResults = await this.vectorService
                .searchSimilarPOIs(userVector.embedding, 3);
        }

        // 4. 重排序
        const rerankedPOIs = await this.rerankerService
            .rerank(query, similarPOIs);

        const rerankedKnowledge = await this.rerankerService
            .rerankKnowledge(query, similarKnowledge);

        // 5. 构建上下文
        const context = this.buildContext(
            rerankedPOIs,
            rerankedKnowledge,
            personalizedResults,
        );

        // 6. 生成回复
        const response = await this.llmService
            .generateResponse(query, context);

        return response;
    }

    private buildContext(
        pois: POIVector[],
        knowledge: KnowledgeVector[],
        personalized: POIVector[],
    ): string {
        let context = "";

        context += "## 相关景点\n";
        for (const poi of pois) {
            context += `- ${poi.name}: ${poi.description}\n`;
        }

        context += "\n## 相关知识\n";
        for (const kb of knowledge) {
            context += `- ${kb.title}: ${kb.content}\n`;
        }

        if (personalized.length > 0) {
            context += "\n## 根据你的兴趣推荐\n";
            for (const poi of personalized) {
                context += `- ${poi.name}: ${poi.description}\n`;
            }
        }

        return context;
    }
}
```

---

## 四、向量更新策略

### 4.1 实时更新

```typescript
export class VectorUpdateService {
    private vectorService: VectorService;
    private embeddingService: EmbeddingService;

    constructor(
        vectorService: VectorService,
        embeddingService: EmbeddingService,
    ) {
        this.vectorService = vectorService;
        this.embeddingService = embeddingService;
    }

    // 当POI信息更新时
    async onPOIUpdated(poi: POI): Promise<void> {
        // 1. 重新生成向量
        const embedding = await this.embeddingService
            .generateEmbedding(poi.description);

        // 2. 更新向量表
        await this.vectorService
            .updatePOIVector(poi.id, embedding);
    }

    // 当知识库更新时
    async onKnowledgeUpdated(knowledge: Knowledge): Promise<void> {
        const embedding = await this.embeddingService
            .generateEmbedding(knowledge.content);

        await this.vectorService
            .updateKnowledgeVector(knowledge.id, embedding);
    }

    // 当用户交互时
    async onUserInteraction(
        userId: string,
        interactions: Interaction[],
    ): Promise<void> {
        // 1. 重新分析用户偏好
        const preferenceText = this.analyzePreferences(interactions);

        // 2. 生成新的偏好向量
        const embedding = await this.embeddingService
            .generateEmbedding(preferenceText);

        // 3. 更新用户偏好向量
        await this.vectorService
            .updateUserPreferenceVector(userId, embedding);
    }

    private analyzePreferences(interactions: Interaction[]): string {
        // 实现用户偏好分析逻辑
        return "";
    }
}
```

### 4.2 批量更新

```typescript
export async function batchUpdateVectors(
    db: Database,
    embeddingService: EmbeddingService,
): Promise<void> {
    // 1. 加载所有POI
    const pois = await loadAllPOIs();

    // 2. 生成向量
    const poiVectors = await generatePOIVectors(pois, embeddingService);

    // 3. 清空旧表
    await db.dropTable("pois_vectors");

    // 4. 创建新表并插入
    const table = await db.createTable("pois_vectors");
    await table.add(poiVectors);
}
```

---

## 五、性能优化

### 5.1 索引策略

```typescript
// 创建索引以加快搜索
export async function createIndices(db: Database): Promise<void> {
    // POI向量表索引
    const poisTable = await db.openTable("pois_vectors");
    await poisTable.createIndex("type_");
    await poisTable.createIndex("route_id");

    // 知识库向量表索引
    const knowledgeTable = await db.openTable("knowledge_vectors");
    await knowledgeTable.createIndex("category");
}
```

### 5.2 缓存策略

```typescript
// 缓存热门查询结果
export class VectorCacheService {
    private cache: Map<string, POIVector[]> = new Map();

    async getOrSearch(
        queryHash: string,
        vectorService: VectorService,
        queryEmbedding: number[],
    ): Promise<POIVector[]> {
        // 1. 检查缓存
        const cached = this.cache.get(queryHash);
        if (cached) {
            return cached;
        }

        // 2. 执行搜索
        const results = await vectorService
            .searchSimilarPOIs(queryEmbedding, 5);

        // 3. 缓存结果
        this.cache.set(queryHash, results);

        return results;
    }
}
```

---

## 六、初始化脚本

### 6.1 向量库初始化

```bash
#!/bin/bash
# scripts/init_vectors.sh

# 1. 创建LanceDB数据库
echo "初始化LanceDB..."
npm run vector:init

# 2. 生成POI向量
echo "生成POI向量..."
npm run vector:generate-pois

# 3. 生成知识库向量
echo "生成知识库向量..."
npm run vector:generate-knowledge

# 4. 创建索引
echo "创建索引..."
npm run vector:create-indices

echo "向量库初始化完成！"
```

### 6.2 package.json 脚本

```json
{
  "scripts": {
    "vector:init": "ts-node scripts/initVectors.ts",
    "vector:generate-pois": "ts-node scripts/generatePOIVectors.ts",
    "vector:generate-knowledge": "ts-node scripts/generateKnowledgeVectors.ts",
    "vector:create-indices": "ts-node scripts/createIndices.ts",
    "vector:update": "ts-node scripts/updateVectors.ts",
    "rag:build": "npm run vector:init && npm run vector:generate-pois && npm run vector:generate-knowledge"
  }
}
```

---

## 七、监控和调试

### 7.1 向量质量评估

```typescript
export class VectorQualityService {
    //评估向量的多样性
    static evaluateDiversity(vectors: number[][]): number {
        let totalDistance = 0.0;
        let count = 0;

        for (let i = 0; i < vectors.length; i++) {
            for (let j = i + 1; j < vectors.length; j++) {
                const distance = VectorQualityService.cosineDistance(vectors[i], vectors[j]);
                totalDistance += distance;
                count++;
            }
        }

        return count > 0 ? totalDistance / count : 0.0;
    }

    private static cosineDistance(a: number[], b: number[]): number {
        const dotProduct = a.reduce((sum, x, i) => sum + x * b[i], 0);
        const normA = Math.sqrt(a.reduce((sum, x) => sum + x * x, 0));
        const normB = Math.sqrt(b.reduce((sum, x) => sum + x * x, 0));

        return normA > 0 && normB > 0 ? 1.0 - (dotProduct / (normA * normB)) : 0.0;
    }
}
```

---

## 八、完整集成示例

```typescript
export async function setupVectorSystem(): Promise<void> {
    // 1. 初始化向量数据库
    const db = await connectToVectorDB("./data/vectors.db");

    // 2. 初始化向量服务
    const vectorService = await VectorService.create(db);

    // 3. 初始化嵌入服务
    const embeddingService = await EmbeddingService.create("BAAI/bge-m3");

    // 4. 生成POI向量
    const pois = await loadPOIsFromJSON();
    const poiVectors = await generatePOIVectors(pois, embeddingService);
    await storePOIVectors(db, poiVectors);

    // 5. 生成知识库向量
    const knowledge = await loadKnowledgeFromFiles();
    const knowledgeVectors = await generateKnowledgeVectors(knowledge, embeddingService);
    await storeKnowledgeVectors(db, knowledgeVectors);

    // 6. 创建索引
    await createIndices(db);

    // 7. 初始化RAG服务
    const ragService = new RAGService(
        vectorService,
        embeddingService,
        await RerankerService.create(),
        await LLMService.create(),
    );
}
```

这是一个**完整的、高性能的、可扩展的向量数据库设计**！✨

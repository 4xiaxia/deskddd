# 东里村AI导览系统 - 第三阶段实现路线图

## 阶段目标
完成后端框架搭建、Agent架构实现、API接口开发，建立完整的多智能体协作系统。

## 时间规划
- **总周期**: 4周
- **每周工作量**: 40小时
- **交付物**: 可运行的API服务 + 完整的前后端集成

---

## 第1周：Node.js后端框架搭建与数据库初始化

### 任务 1.1：项目配置（2天）
**目标**: 完成后端基础框架搭建

#### 1.1.1 初始化Node.js项目
```bash
# 在项目根目录下
mkdir backend
cd backend
npm init -y
```

#### 1.1.2 安装依赖
```bash
# 安装生产依赖
npm install express cors body-parser sqlite3 bcryptjs jsonwebtoken multer dotenv

# 安装开发依赖
npm install --save-dev typescript ts-node @types/express @types/node @types/cors @types/bcryptjs @types/jsonwebtoken @types/multer nodemon
```

#### 1.1.3 配置TypeScript
```json
// backend/tsconfig.json
{
  "compilerOptions": {
    "target": "es2018",
    "module": "commonjs",
    "outDir": "./dist",
    "rootDir": "./src",
    "strict": true,
    "esModuleInterop": true,
    "skipLibCheck": true,
    "forceConsistentCasingInFileNames": true
  },
  "include": ["src/**/*"],
  "exclude": ["node_modules"]
}
```

#### 1.1.4 配置开发脚本
```json
// backend/package.json
{
  "scripts": {
    "start": "node dist/server.js",
    "dev": "nodemon --exec ts-node src/server.ts",
    "build": "tsc",
    "test": "jest"
  }
}
```

### 任务 1.2：数据库设计与初始化（2天）
**目标**: 完成SQLite数据库设计和迁移

#### 1.2.1 数据库连接配置
```typescript
// backend/src/db/connection.ts
import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';

let db: Database | null = null;

const DB_PATH = process.env.NODE_ENV === 'test' 
  ? ':memory:' 
  : process.env.DB_PATH || './dongli_tourism.sqlite';

export async function getDb() {
  if (!db) {
    db = await open({
      filename: DB_PATH,
      driver: sqlite3.Database,
    });
    
    // 启用外键约束
    await db.run('PRAGMA foreign_keys = ON');
  }
  return db;
}

export async function initDb() {
  const db = await getDb();
  
  // 创建用户表
  await db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id TEXT PRIMARY KEY,
      phone TEXT UNIQUE NOT NULL,
      password TEXT NOT NULL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  // 创建景点表
  await db.exec(`
    CREATE TABLE IF NOT EXISTS pois (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      latitude REAL,
      longitude REAL,
      category TEXT,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  // 创建路线表
  await db.exec(`
    CREATE TABLE IF NOT EXISTS routes (
      id TEXT PRIMARY KEY,
      name TEXT NOT NULL,
      description TEXT,
      duration INTEGER,
      distance REAL,
      created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    )
  `);
  
  // 路线-景点关联表
  await db.exec(`
    CREATE TABLE IF NOT EXISTS route_pois (
      route_id TEXT,
      poi_id TEXT,
      order_index INTEGER,
      PRIMARY KEY (route_id, poi_id),
      FOREIGN KEY (route_id) REFERENCES routes(id) ON DELETE CASCADE,
      FOREIGN KEY (poi_id) REFERENCES pois(id) ON DELETE CASCADE
    )
  `);
  
  console.log('Database initialized successfully');
}
```

#### 1.2.2 数据库迁移脚本
```typescript
// backend/scripts/migrate.ts
import { getDb } from '../src/db/connection';
import { initDb } from '../src/db/init';

async function runMigrations() {
  try {
    console.log('Starting database migrations...');
    await initDb();
    console.log('Migrations completed successfully');
    process.exit(0);
  } catch (error) {
    console.error('Migration failed:', error);
    process.exit(1);
  }
}

runMigrations();
```

### 任务 1.3：Express应用基础架构（1天）
**目标**: 搭建Express应用基础结构

#### 1.3.1 创建Express应用
```typescript
// backend/src/server.ts
import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import { initDb } from './db/init';
import authRoutes from './routes/auth.routes';
import guideRoutes from './routes/guide.routes';
import { errorHandler } from './middleware/error.middleware';

const app = express();
const PORT = process.env.PORT || 3001;

// 中间件
app.use(cors());
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// 路由
app.use('/api/auth', authRoutes);
app.use('/api/guide', guideRoutes);

// 错误处理中间件
app.use(errorHandler);

// 启动服务器
const startServer = async () => {
  try {
    // 初始化数据库
    await initDb();
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
```

#### 1.3.2 错误处理中间件
```typescript
// backend/src/middleware/error.middleware.ts
import { Request, Response, NextFunction } from 'express';

export interface ApiError extends Error {
  statusCode?: number;
  data?: any;
}

export const errorHandler = (
  err: ApiError,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  console.error('Error:', err);
  
  const statusCode = err.statusCode || 500;
  const message = err.message || 'Internal Server Error';
  
  res.status(statusCode).json({
    success: false,
    message,
    data: err.data || null,
  });
};

export const notFound = (req: Request, res: Response) => {
  res.status(404).json({
    success: false,
    message: `Not Found - ${req.originalUrl}`,
  });
};
```
### 任务 1.2：SQLite数据库初始化（2天)
**目标**: 创建所有数据库表并初始化示例数据

#### 1.2.1 创建数据库迁移文件
```
backend/src/db/
├── connection.ts        # SQLite 连接与迁移封装
├── init.ts              # 初始化表结构
├── migrations/         # SQL脚本目录（001_users.sql / 002_pois.sql ...）
└── seeds/
    └── sample_data.sql  # 初始数据填充
```

#### 1.2.2 实现数据库连接管理
```typescript
// backend/src/db/connection.ts
import sqlite3 from 'sqlite3';
import { open, Database } from 'sqlite';

let db: Database | null = null;

export async function getDb() {
  if (!db) {
    db = await open({
      filename: process.env.DB_PATH || './dongli_tourism.sqlite',
      driver: sqlite3.Database,
    });
    await db.run('PRAGMA foreign_keys = ON');
  }
  return db;
}

export async function initDb() {
  const database = await getDb();
  await database.exec(`CREATE TABLE IF NOT EXISTS users (...);`);
  await database.exec(`CREATE TABLE IF NOT EXISTS pois (...);`);
  await database.exec(`CREATE TABLE IF NOT EXISTS routes (...);`);
  await database.exec(`CREATE TABLE IF NOT EXISTS route_pois (...);`);
  console.log('Database initialized successfully');
}
```

#### 1.2.3 初始化景点数据
- 导入所有红色文化景点（6个）
- 导入所有生态景点（5个）
- 导入基础设施景点（3个）
- 验证坐标数据准确性

### 任务 1.3：项目结构搭建（1天）
**目标**: 建立模块化的代码结构

```
backend/src/
├── server.ts             # Express 启动脚本
├── config.ts             # 环境配置（port, jwt, uploads）
├── db/                   # 数据库与迁移
├── routes/               # auth/guide/routes/pois/stats/content
├── services/             # auth/guide/stats/recommendation
├── middleware/           # auth + error handling
├── utils/                # logger/validation
└── types/                # TypeScript 接口定义
```

---



## 第2周：服务模块迭代与接口稳定

### 任务 2.1：Auth & Route 服务深化（2天）
**目标**: 对 `authService`、`routeService`、`poiService` 做状态封装，保证 JWT + 路线查询到位。
- `authRoutes` 提供 `POST /api/users/login`、`GET /api/users/profile`，验证 token 并执行 `authStore` 更新。
- `routeRoutes` 提供 `/api/routes` 与 `/api/routes/:routeId`，`poiRoutes` 提供 `/api/pois/:poiId` 与 `recordVisit` 吸纳统计。
- 编写 `services/recommendationService.ts`，为首页/AI Agent 提供 `target_audience` 匹配逻辑。

### 任务 2.2：内容与统计服务（1.5天）
**目标**: 保障 `contentRoutes` 与 `statsRoutes` 正常工作。
- 使用 `multer` 上传至 `backend/uploads`，`contentService` 维护 `content_uploads` 状态流。
- `statsService` 监听 `recordVisit`、`getVisitStats` 与 `getPopularPois`，提供热度数据供前端图表。
- 添加 `node-cache`/`memory-cache` 缓存最近查询结果，减少 SQLite 密集读。

### 任务 2.3：AI Guide API 与集成（1.5天）
**目标**: 构建 `guideRoutes.ts`，将 AI 导游需求转化为 REST 接口。
- `/api/guide/greeting`：接受 `timeOfDay` 与 `userPreference`，调用 `services/guideService.ts` + 外部 AI API，返回个性化问候。
- `/api/guide/recommend`：对接 `recommendationService`，生产推荐文案和路径列表，供 `AIAgentDrawer` 使用。
- 统一错误码与重试逻辑，确保前端在超时/异常时有 gracefully fallback。

## 第3周：前后端联调与测试

### 任务 3.1：前端 API 调用复核（1天）
**目标**: 确认 `apiClient` 所有方法（登录、路线详情、POI、统计、内容上传、AI Guide）都对齐 Express 端点。
- 写 `apiClient` 单元测试（Jest + msw），模拟成功/失败场景。
- 把 `useRouteData`/`useGuideStore` 的 `fetch` 替换为 `apiClient`，并在 React 组件中捕获错误和 loading 状态。

### 任务 3.2：集成测试与 QA（1.5天）
**目标**: 用 `supertest`+`jest` 打通 `/api/*` 核心路径。
- 测试 `POST /api/users/login`、`GET /api/routes`、`POST /api/stats/record-visit`、`POST /api/content/upload`。
- 利用 SQLite 测试数据库（`:memory:`）来验证 `visitor_records`/`content_uploads` 写入。
- 前端可运行 `npm run test`（Jest+Testing Library）覆盖页脚/路由组件。

## 第4周：性能、部署与文档

### 任务 4.1：性能调优（1天）
**目标**: 完成热点查询缓存与前后端线上准备。
- Express 实现 `cacheMiddleware`，命中 `routes` 与 `pois` 请求。
- `AIAgentDrawer` 加入 `debounce`/`throttle`，防止重复 `apiClient.request`。

### 任务 4.2：部署与运维文档（1天）
**目标**: 编写部署脚本与操作说明。
- `docs/DEPLOYMENT_OPERATIONS.md` 更新，说明 `backend/` 与 `src/` 用户手册、数据库迁移命令、Capacitor 打包流程。
- 补充 `docker-compose` 示例（可选），方便未来一键部署。

### 任务 4.3：风险与应对（0.5天）
**目标**: 重新评估风险点，输出 Node/Express 版本的缓解策划。
- 风险1：Express 服务过载 → 使用 `compression`、`helmet`、`rate-limit` 保护。
- 风险2：SQLite 写冲突 → 增加 `better-sqlite3` + `transaction` 封装。
- 风险3：API 漏洞 → 集成 `middleware/validation.ts` + JWT 过期处理。
- ✅ 完整的Rust后端框架
- ✅ SQLite数据库（含示例数据）
- ✅ 四个Agent的核心实现
- ✅ ANP通信协议实现
- ✅ 完整的API接口

### 文档交付物
- ✅ API文档
- ✅ Agent设计文档
- ✅ 数据库设计文档
- ✅ 部署指南

### 性能指标
- 页面加载时间 ≤ 3秒
- API响应时间 ≤ 500ms
- 支持并发用户 ≥ 100

---

## 风险与应对

### 风险1：Node.js 服务稳定性
**应对**: 采用成熟中间件（helmet、compression、express-rate-limit），并建立本地测试套件、自动重启策略

### 风险2：数据库性能问题
**应对**: 提前进行性能测试，优化索引和查询

### 风险3：Agent通信延迟
**应对**: 使用异步消息队列，实现缓存机制

---

## 后续计划

完成第三阶段后，将进入：
- **第四阶段**：AI服务集成（语音、图像识别）
- **第五阶段**：向量数据库和RAG优化
- **第六阶段**：性能优化和部署

import { create } from 'zustand';
import type { AIMessage, AIConversation } from '../types';

interface AgentState {
  conversations: Map<string, AIConversation>;
  currentConversationId: string | null;
  isOpen: boolean;
  isLoading: boolean;
  
  // Actions
  createConversation: () => string;
  setCurrentConversation: (id: string) => void;
  addMessage: (conversationId: string, message: AIMessage) => void;
  toggleAgent: () => void;
  setIsLoading: (loading: boolean) => void;
  clearConversation: (conversationId: string) => void;
}

export const useAgentStore = create<AgentState>((set) => ({
  conversations: new Map(),
  currentConversationId: null,
  isOpen: false,
  isLoading: false,

  createConversation: () => {
    const id = `conv_${Date.now()}`;
    const newConversation: AIConversation = {
      id,
      messages: [],
    };
    set((state) => {
      const newConversations = new Map(state.conversations);
      newConversations.set(id, newConversation);
      return { conversations: newConversations, currentConversationId: id };
    });
    return id;
  },

  setCurrentConversation: (id: string) => {
    set({ currentConversationId: id });
  },

  addMessage: (conversationId: string, message: AIMessage) => {
    set((state) => {
      const newConversations = new Map(state.conversations);
      const conversation = newConversations.get(conversationId);
      if (conversation) {
        conversation.messages.push(message);
        newConversations.set(conversationId, conversation);
      }
      return { conversations: newConversations };
    });
  },

  toggleAgent: () => {
    set((state) => {
      const newIsOpen = !state.isOpen;
      // Create a new conversation if toggling open and none exists
      if (newIsOpen && !state.currentConversationId) {
        const id = `conv_${Date.now()}`;
        const newConversations = new Map(state.conversations);
        newConversations.set(id, { id, messages: [] });
        return { isOpen: newIsOpen, conversations: newConversations, currentConversationId: id };
      }
      return { isOpen: newIsOpen };
    });
  },

  setIsLoading: (loading: boolean) => {
    set({ isLoading: loading });
  },

  clearConversation: (conversationId: string) => {
    set((state) => {
      const newConversations = new Map(state.conversations);
      newConversations.delete(conversationId);
      return { conversations: newConversations };
    });
  },
}));

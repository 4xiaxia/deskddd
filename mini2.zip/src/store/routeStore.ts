import { create } from 'zustand';
import type { Route, POI } from '../types';
import { apiClient } from '../services/api';

interface RouteState {
  routes: Route[];
  currentRoute: Route | null;
  currentPOI: POI | null;
  pois: POI[];
  contentModel: Record<string, any> | null;
  isLoading: boolean;
  error: string | null;

  setRoutes: (routes: Route[]) => void;
  setCurrentRoute: (route: Route | null) => void;
  setCurrentPOI: (poi: POI | null) => void;
  setPOIs: (pois: POI[]) => void;
  fetchRoutes: () => Promise<void>;
  fetchPOIsByRoute: (routeId: string) => Promise<void>;
  fetchRouteDetail: (routeId: string) => Promise<void>;
  fetchPOIDetail: (poiId: string) => Promise<void>;
  loadContentModel: (modelId?: string) => Promise<void>;
  clearError: () => void;
}

const normalizeContentSource = <T extends Record<string, any>>(entity: T | null) => {
  if (!entity) return null;
  const modelId = entity.contentModelId ?? entity.content_model_id ?? entity.content_model;
  return {
    ...entity,
    contentModelId: modelId,
  };
};

const normalizeList = <T extends Record<string, any>>(list: T[]) => list.map((item) => normalizeContentSource(item) as T);

export const useRouteStore = create<RouteState>((set) => ({
  routes: [],
  currentRoute: null,
  currentPOI: null,
  pois: [],
  contentModel: null,
  isLoading: false,
  error: null,

  setRoutes: (routes: Route[]) => set({ routes }),
  setCurrentRoute: (route: Route | null) => set({ currentRoute: route }),
  setCurrentPOI: (poi: POI | null) => set({ currentPOI: poi }),
  setPOIs: (pois: POI[]) => set({ pois }),

  fetchRoutes: async () => {
    set({ isLoading: true, error: null });
    try {
      const routes = await apiClient.getRoutes();
      set({ routes, isLoading: false });
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : '获取路线失败',
        isLoading: false,
      });
    }
  },

  fetchPOIsByRoute: async (routeId: string) => {
    set({ isLoading: true, error: null });
    try {
      const routeDetail = await apiClient.getRouteDetail(routeId);
      const normalizedPois = normalizeList(routeDetail.pois || []);
      set({ pois: normalizedPois, isLoading: false });
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : '获取景点失败',
        isLoading: false,
      });
    }
  },

  fetchRouteDetail: async (routeId: string) => {
    set({ isLoading: true, error: null });
    try {
      const routeDetail = await apiClient.getRouteDetail(routeId);
      const normalizedRoute = normalizeContentSource(routeDetail);
      set({ currentRoute: normalizedRoute, isLoading: false });
      if (normalizedRoute?.contentModelId) {
        await apiClient.getContentModel(normalizedRoute.contentModelId)
          .then((model) => set({ contentModel: model }))
          .catch(() => set({ contentModel: null }));
      } else {
        set({ contentModel: null });
      }
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : '获取路线详情失败',
        isLoading: false,
      });
    }
  },

  fetchPOIDetail: async (poiId: string) => {
    set({ isLoading: true, error: null });
    try {
      const poiDetail = await apiClient.getPoiDetail(poiId);
      const normalizedPoi = normalizeContentSource(poiDetail);
      set({ currentPOI: normalizedPoi, isLoading: false });
      if (normalizedPoi?.contentModelId) {
        await apiClient.getContentModel(normalizedPoi.contentModelId)
          .then((model) => set({ contentModel: model }))
          .catch(() => set({ contentModel: null }));
      } else {
        set({ contentModel: null });
      }
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : '获取景点详情失败',
        isLoading: false,
      });
    }
  },

  loadContentModel: async (modelId?: string) => {
    if (!modelId) {
      set({ contentModel: null });
      return;
    }

    set({ isLoading: true, error: null });
    try {
      const model = await apiClient.getContentModel(modelId);
      set({ contentModel: model, isLoading: false });
    } catch (err) {
      set({
        error: err instanceof Error ? err.message : '加载内容模型失败',
        isLoading: false,
      });
    }
  },

  clearError: () => set({ error: null }),
}));

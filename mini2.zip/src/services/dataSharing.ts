/**
 * 数据共享服务
 * 基于Redis实现多线程、交叉任务的数据异步共享
 * 减少不必要的消耗，优化性能
 */

import { REDIS_CONFIG } from '../config/env';

interface CacheEntry<T> {
  data: T;
  timestamp: number;
  ttl: number;
  accessCount: number;
}

interface SharedData {
  userSessions: Map<string, any>;
  routeCache: Map<string, any>;
  poiCache: Map<string, any>;
  aiConversations: Map<string, any>;
  locationCache: Map<string, any>;
}

class DataSharingService {
  private sharedData: SharedData = {
    userSessions: new Map(),
    routeCache: new Map(),
    poiCache: new Map(),
    aiConversations: new Map(),
    locationCache: new Map()
  };

  private cacheStats = {
    hits: 0,
    misses: 0,
    evictions: 0,
    totalRequests: 0
  };

  private readonly DEFAULT_TTL = 3600; // 1小时
  private readonly MAX_CACHE_SIZE = 1000;

  // 用户会话管理
  async setUserSession(userId: string, sessionData: any, ttl: number = this.DEFAULT_TTL): Promise<void> {
    this.sharedData.userSessions.set(userId, {
      data: sessionData,
      timestamp: Date.now(),
      ttl,
      accessCount: 1
    });

    // 如果缓存过大，清理最少使用的条目
    if (this.sharedData.userSessions.size > this.MAX_CACHE_SIZE) {
      await this.evictLRUEntries('userSessions');
    }
  }

  async getUserSession(userId: string): Promise<any | null> {
    this.cacheStats.totalRequests++;
    const entry = this.sharedData.userSessions.get(userId);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }

    // 检查TTL
    if (Date.now() - entry.timestamp > entry.ttl * 1000) {
      this.sharedData.userSessions.delete(userId);
      this.cacheStats.misses++;
      return null;
    }

    // 更新访问统计
    entry.accessCount++;
    this.cacheStats.hits++;
    return entry.data;
  }

  // 路线数据缓存
  async setRouteCache(routeId: string, routeData: any, ttl: number = 1800): Promise<void> {
    this.sharedData.routeCache.set(routeId, {
      data: routeData,
      timestamp: Date.now(),
      ttl,
      accessCount: 1
    });

    if (this.sharedData.routeCache.size > this.MAX_CACHE_SIZE) {
      await this.evictLRUEntries('routeCache');
    }
  }

  async getRouteCache(routeId: string): Promise<any | null> {
    this.cacheStats.totalRequests++;
    const entry = this.sharedData.routeCache.get(routeId);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }

    if (Date.now() - entry.timestamp > entry.ttl * 1000) {
      this.sharedData.routeCache.delete(routeId);
      this.cacheStats.misses++;
      return null;
    }

    entry.accessCount++;
    this.cacheStats.hits++;
    return entry.data;
  }

  // POI数据缓存
  async setPOICache(poiId: string, poiData: any, ttl: number = 900): Promise<void> {
    this.sharedData.poiCache.set(poiId, {
      data: poiData,
      timestamp: Date.now(),
      ttl,
      accessCount: 1
    });
  }

  async getPOICache(poiId: string): Promise<any | null> {
    this.cacheStats.totalRequests++;
    const entry = this.sharedData.poiCache.get(poiId);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }

    if (Date.now() - entry.timestamp > entry.ttl * 1000) {
      this.sharedData.poiCache.delete(poiId);
      this.cacheStats.misses++;
      return null;
    }

    entry.accessCount++;
    this.cacheStats.hits++;
    return entry.data;
  }

  // AI对话上下文共享
  async setAIConversation(userId: string, conversation: any, ttl: number = 300): Promise<void> {
    this.sharedData.aiConversations.set(userId, {
      data: conversation,
      timestamp: Date.now(),
      ttl,
      accessCount: 1
    });
  }

  async getAIConversation(userId: string): Promise<any | null> {
    this.cacheStats.totalRequests++;
    const entry = this.sharedData.aiConversations.get(userId);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }

    if (Date.now() - entry.timestamp > entry.ttl * 1000) {
      this.sharedData.aiConversations.delete(userId);
      this.cacheStats.misses++;
      return null;
    }

    entry.accessCount++;
    this.cacheStats.hits++;
    return entry.data;
  }

  // 位置数据共享
  async setLocationCache(sessionId: string, locationData: any, ttl: number = 60): Promise<void> {
    this.sharedData.locationCache.set(sessionId, {
      data: locationData,
      timestamp: Date.now(),
      ttl,
      accessCount: 1
    });
  }

  async getLocationCache(sessionId: string): Promise<any | null> {
    this.cacheStats.totalRequests++;
    const entry = this.sharedData.locationCache.get(sessionId);
    
    if (!entry) {
      this.cacheStats.misses++;
      return null;
    }

    if (Date.now() - entry.timestamp > entry.ttl * 1000) {
      this.sharedData.locationCache.delete(sessionId);
      this.cacheStats.misses++;
      return null;
    }

    entry.accessCount++;
    this.cacheStats.hits++;
    return entry.data;
  }

  // 批量数据操作
  async batchSet(cacheType: keyof SharedData, entries: Record<string, any>): Promise<void> {
    const cache = this.sharedData[cacheType];
    const now = Date.now();

    Object.entries(entries).forEach(([key, value]) => {
      cache.set(key, {
        data: value,
        timestamp: now,
        ttl: this.DEFAULT_TTL,
        accessCount: 1
      });
    });
  }

  async batchGet(cacheType: keyof SharedData, keys: string[]): Promise<Record<string, any>> {
    const cache = this.sharedData[cacheType];
    const now = Date.now();
    const results: Record<string, any> = {};

    keys.forEach(key => {
      const entry = cache.get(key);
      
      if (entry && now - entry.timestamp <= entry.ttl * 1000) {
        results[key] = entry.data;
        entry.accessCount++;
      }
    });

    return results;
  }

  // LRU缓存清理
  private async evictLRUEntries(cacheType: keyof SharedData): Promise<void> {
    const cache = this.sharedData[cacheType];
    const entries = Array.from(cache.entries());
    
    // 按访问次数排序，删除最少使用的条目
    entries.sort((a, b) => a[1].accessCount - b[1].accessCount);
    
    const entriesToRemove = Math.ceil(entries.length * 0.1); // 删除10%
    for (let i = 0; i < entriesToRemove; i++) {
      cache.delete(entries[i][0]);
    }
    
    this.cacheStats.evictions += entriesToRemove;
  }

  // 预加载常用数据
  async preloadCommonData(): Promise<void> {
    try {
      // 预加载热门路线
      const popularRoutes = ['route_1', 'route_2', 'route_3'];
      await this.batchSet('routeCache', {
        'route_1': {
          id: 'route_1',
          name: '红色文化革命之旅',
          preloadTime: Date.now()
        },
        'route_2': {
          id: 'route_2',
          name: '乡村基础设施与休闲游',
          preloadTime: Date.now()
        },
        'route_3': {
          id: 'route_3',
          name: '民俗体验与美食探索',
          preloadTime: Date.now()
        }
      });

      // 预加载热门POI
      const popularPOIs = [
        'poi_donglired_xinhaijinianguan001',
        'poi_donglired_jingyizhuang001',
        'poi_basic_ykfwzx'
      ];
      
      await this.batchSet('poiCache', popularPOIs.reduce((acc, poiId) => {
        acc[poiId] = { id: poiId, preloadTime: Date.now() };
        return acc;
      }, {} as Record<string, any>));
    } catch (error) {
      console.error('预加载数据错误:', error);
    }
  }

  // 获取缓存统计
  getCacheStats(): typeof this.cacheStats & {
    hitRate: number;
    cacheSize: Record<keyof SharedData, number>;
  } {
    const hitRate = this.cacheStats.totalRequests > 0 
      ? this.cacheStats.hits / this.cacheStats.totalRequests 
      : 0;

    return {
      ...this.cacheStats,
      hitRate,
      cacheSize: {
        userSessions: this.sharedData.userSessions.size,
        routeCache: this.sharedData.routeCache.size,
        poiCache: this.sharedData.poiCache.size,
        aiConversations: this.sharedData.aiConversations.size,
        locationCache: this.sharedData.locationCache.size
      }
    };
  }

  // 清理过期数据
  async cleanup(): Promise<void> {
    const now = Date.now();
    
    Object.values(this.sharedData).forEach(cache => {
      for (const [key, entry] of cache.entries()) {
        if (now - entry.timestamp > entry.ttl * 1000) {
          cache.delete(key);
        }
      }
    });
  }

  // 获取缓存大小
  getCacheSize(): Record<keyof SharedData, number> {
    return {
      userSessions: this.sharedData.userSessions.size,
      routeCache: this.sharedData.routeCache.size,
      poiCache: this.sharedData.poiCache.size,
      aiConversations: this.sharedData.aiConversations.size,
      locationCache: this.sharedData.locationCache.size
    };
  }
}

// 单例实例
export const dataSharingService = new DataSharingService();

// 自动预加载和清理
if (typeof window !== 'undefined') {
  // 预加载常用数据
  dataSharingService.preloadCommonData();
  
  // 每5分钟清理一次过期数据
  setInterval(() => {
    dataSharingService.cleanup();
  }, 5 * 60 * 1000);
}

export default dataSharingService;
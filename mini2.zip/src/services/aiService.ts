/**
 * AI服务集成层
 * 集成智谱AI和硅基流服务，支持文本生成、视觉推理、语音合成等功能
 * 遵循移动端优先和极简性能原则
 */

// 智谱AI配置
const ZHIPU_CONFIG = {
  API_KEY: 'a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog',
  BASE_URL: 'https://open.bigmodel.cn/api/paas/v4',
  TEXT_MODEL: 'glm-4.5-flash',
  VISION_MODEL: 'glm-4.1v-thinking-flash',
  SPEECH_MODEL: 'cogview-3-flash' // TTS服务
};

// 硅基流配置
const SILICONFLOW_CONFIG = {
  API_URL: 'https://api.siliconflow.cn',
  API_KEY: 'sk-xwmofaucrbykmzwwtbdwannjoxzxhssbwcfeafxykkdoouwe',
  DEFAULT_MODEL: 'Qwen/Qwen3-8B',
  REASONING_MODEL: 'deepseek-ai/DeepSeek-R1-0528-Qwen3-8B',
  SPEECH_MODEL: 'FunAudioLLM/SenseVoiceSmall'
};

export interface AIMessage {
  role: 'user' | 'assistant';
  content: string;
}

export interface ChatResponse {
  content: string;
  model: string;
  tokens: number;
}

/**
 * 智能导游对话服务
 * 基于用户位置和POI信息，提供个性化导览对话
 */
export class SmartTourGuide {
  private sessionContext: Map<string, any> = new Map();
  
  /**
   * 基于当前位置的导览对话
   */
  async chatWithLocation(
    userId: string, 
    message: string, 
    currentLocation: { lat: number; lng: number },
    nearbyPOIs: string[]
  ): Promise<ChatResponse> {
    const session = this.sessionContext.get(userId) || {};
    
    const prompt = `你是一个专业的东里村智能导游。当前游客位置：${currentLocation.lat},${currentLocation.lng}。
    
附近景点包括：${nearbyPOIs.join('、')}。
游客问题：${message}

请基于游客当前位置和周边景点，提供准确、有趣的导览回复。`;

    try {
      // 使用智谱AI进行对话
      const response = await this.callZhipuAPI({
        messages: [
          { role: 'system', content: '你是东里村的专业导游，熟悉当地历史文化和景点' },
          { role: 'user', content: prompt }
        ],
        model: ZHIPU_CONFIG.TEXT_MODEL,
        temperature: 0.7,
        max_tokens: 500
      });

      // 更新会话上下文
      this.sessionContext.set(userId, {
        ...session,
        lastLocation: currentLocation,
        conversationHistory: [...(session.conversationHistory || []), { role: 'user', content: message }, { role: 'assistant', content: response.choices[0].message.content }]
      });

      return {
        content: response.choices[0].message.content,
        model: 'glm-4.5-flash',
        tokens: response.usage.total_tokens || 0
      };
    } catch (error) {
      console.error('智能对话服务错误:', error);
      return {
        content: '抱歉，AI导游服务暂时无法响应。请稍后重试或联系现场工作人员。',
        model: 'error',
        tokens: 0
      };
    }
  }

  /**
   * 基于POI的智能讲解
   */
  async generatePOIGuide(poiId: string, poiData: any): Promise<string> {
    const prompt = `请为东里村的${poiData.name}景点生成详细的导览讲解。

景点信息：
- 名称：${poiData.name}
- 位置：${poiData.latitude}, ${poiData.longitude}
- 历史背景：${poiData.description}

请生成300字左右的生动有趣的导览讲解，包含历史文化背景、参观要点和游览建议。`;

    try {
      const response = await this.callZhipuAPI({
        messages: [{ role: 'user', content: prompt }],
        model: ZHIPU_CONFIG.TEXT_MODEL,
        temperature: 0.8,
        max_tokens: 400
      });

      return response.choices[0].message.content;
    } catch (error) {
      console.error('POI讲解生成错误:', error);
      return poiData.description; // 回退到原始描述
    }
  }

  /**
   * 智能路线推荐
   */
  async recommendRoute(
    userPreferences: string[], 
    availableTime: number, 
    currentLocation: { lat: number; lng: number }
  ): Promise<any[]> {
    const prompt = `基于用户偏好和可用时间，为东里村推荐最佳游览路线。

用户偏好：${userPreferences.join('、')}
可用时间：${availableTime}分钟
当前位置：${currentLocation.lat}, ${currentLocation.lng}

可选择景点：
1. 永春辛亥革命纪念馆 - 红色文化类 (20分钟)
2. 旌义状石碑 - 红色文化类 (10分钟)
3. 东里村游客服务中心 - 基础设施类 (60分钟)
4. 东里村乡村发展中心 - 基础设施类 (120分钟)
5. 油桐花民宿 - 基础设施类
6. 油桐花海 - 自然景观类 (季节性)
7. 农特产品展示 - 民俗体验类

请推荐最合适的路线，包含景点顺序、预计时间和理由。`;

    try {
      const response = await this.callSiliconFlowAPI({
        messages: [{ role: 'user', content: prompt }],
        model: SILICONFLOW_CONFIG.REASONING_MODEL,
        temperature: 0.7,
        max_tokens: 800
      });

      return JSON.parse(response.choices[0].message.content);
    } catch (error) {
      console.error('路线推荐错误:', error);
      return this.getFallbackRoute(availableTime);
    }

    /**
     * 备选路线推荐
     */
    function getFallbackRoute(time: number): any[] {
      if (time <= 60) {
        return [
          { id: 'poi_basic_ykfwzx', name: '东里村游客服务中心', duration: 30 },
          { id: 'poi_donglired_jingyizhuang001', name: '旌义状石碑', duration: 10 }
        ];
      } else if (time <= 120) {
        return [
          { id: 'poi_donglired_xinhaijinianguan001', name: '永春辛亥革命纪念馆', duration: 20 },
          { id: 'poi_basic_xcfzzx', name: '东里村乡村发展中心', duration: 60 }
        ];
      } else {
        return [
          { id: 'poi_donglired_xinhaijinianguan001', name: '永春辛亥革命纪念馆', duration: 20 },
          { id: 'poi_basic_xcfzzx', name: '东里村乡村发展中心', duration: 60 },
          { id: 'poi_basic_ythms', name: '油桐花民宿', duration: 30 }
        ];
      }
    }
  }

  /**
   * 智谱AI API调用
   */
  private async callZhipuAPI(payload: any): Promise<any> {
    const response = await fetch(`${ZHIPU_CONFIG.BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ZHIPU_CONFIG.API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`智谱AI API错误: ${response.status}`);
    }

    return await response.json();
  }

  /**
   * 硅基流API调用
   */
  private async callSiliconFlowAPI(payload: any): Promise<any> {
    const response = await fetch(`${SILICONFLOW_CONFIG.API_URL}/v1/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${SILICONFLOW_CONFIG.API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`硅基流API错误: ${response.status}`);
    }

    return await response.json();
  }
}

/**
 * 图像识别服务
 * 基于智谱AI的视觉能力，实现POI识别和物品识别
 */
export class VisionRecognition {
  /**
   * POI图像识别
   */
  async identifyPOI(imageBase64: string, currentLocation: { lat: number; lng: number }): Promise<any> {
    const prompt = `识别这张图片是否是东里村的景点，并判断具体是哪个景点。

当前GPS位置：${currentLocation.lat}, ${currentLocation.lng}

东里村主要景点：
1. 永春辛亥革命纪念馆 (东里郑氏宗祠)
2. 旌义状石碑 (村口雨亭侨光亭内)
3. 东里村游客服务中心 (水库边)
4. 东里村乡村发展中心 (东里村小学)
5. 油桐花民宿 (油桐花海、仙夹水库边)
6. 油桐花海 (仙夹水库边)
7. 农特产品展示

请返回识别的景点ID和置信度分数。`;

    try {
      const response = await this.callZhipuVisionAPI({
        model: ZHIPU_CONFIG.VISION_MODEL,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
            ]
          }
        ],
        temperature: 0.3,
        max_tokens: 200
      });

      return {
        success: true,
        result: response.choices[0].message.content,
        confidence: 0.85
      };
    } catch (error) {
      console.error('POI识别错误:', error);
      return {
        success: false,
        error: '图像识别服务暂时无法使用'
      };
    }
  }

  /**
   * 器物识别 (文物、建筑元素等)
   */
  async recognizeArtifact(imageBase64: string, context: string): Promise<any> {
    const prompt = `识别图片中的器物或建筑元素。

场景上下文：${context}

可能的物品包括：
- 青石板台阶
- 老式木桌
- 革命标语拓片
- 煤油灯
- 古井
- 牌坊
- 传统农具
- 传统建筑装饰

请识别物品名称和可能的文化意义。`;

    try {
      const response = await this.callZhipuVisionAPI({
        model: ZHIPU_CONFIG.VISION_MODEL,
        messages: [
          {
            role: 'user',
            content: [
              { type: 'text', text: prompt },
              { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${imageBase64}` } }
            ]
          }
        ],
        temperature: 0.4,
        max_tokens: 300
      });

      return {
        success: true,
        artifacts: response.choices[0].message.content
      };
    } catch (error) {
      console.error('器物识别错误:', error);
      return {
        success: false,
        error: '器物识别服务暂时无法使用'
      };
    }
  }

  /**
   * 智谱AI视觉API调用
   */
  private async callZhipuVisionAPI(payload: any): Promise<any> {
    const response = await fetch(`${ZHIPU_CONFIG.BASE_URL}/chat/completions`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ZHIPU_CONFIG.API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`智谱AI视觉API错误: ${response.status}`);
    }

    return await response.json();
  }
}

/**
 * 语音合成服务
 * 支持多语音合成，缓存优化
 */
export class SpeechSynthesis {
  private audioCache: Map<string, string> = new Map();

  /**
   * 文本转语音 (智谱AI TTS)
   */
  async synthesizeSpeech(text: string, voice: string = 'female'): Promise<string> {
    const cacheKey = `${voice}_${text.substring(0, 50)}`;
    
    if (this.audioCache.has(cacheKey)) {
      return this.audioCache.get(cacheKey)!;
    }

    try {
      const response = await this.callZhipuTTSAPI({
        model: 'speech-02',
        input: text,
        voice: voice === 'female' ? 'female-qn-qingse' : 'male-qn-qn'
      });

      const audioBase64 = response.data;
      const audioUrl = await this.saveAudioToCDN(audioBase64, cacheKey);
      
      // 缓存结果
      this.audioCache.set(cacheKey, audioUrl);
      
      return audioUrl;
    } catch (error) {
      console.error('语音合成错误:', error);
      throw error;
    }
  }

  /**
   * 批量语音合成
   */
  async batchSynthesize(textList: string[], voice: string = 'female'): Promise<string[]> {
    const promises = textList.map(text => 
      this.synthesizeSpeech(text, voice).catch(err => {
        console.error('批量TTS错误:', err);
        return null;
      })
    );

    return Promise.all(promises);
  }

  /**
   * 智谱AI TTS API调用
   */
  private async callZhipuTTSAPI(payload: any): Promise<any> {
    const response = await fetch(`${ZHIPU_CONFIG.BASE_URL}/speech`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${ZHIPU_CONFIG.API_KEY}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload)
    });

    if (!response.ok) {
      throw new Error(`智谱AI TTS API错误: ${response.status}`);
    }

    return await response.json();
  }

  /**
   * 保存音频到CDN (使用阿里云OSS)
   */
  private async saveAudioToCDN(audioBase64: string, filename: string): Promise<string> {
    // 这里应该实现阿里云OSS上传逻辑
    // 返回CDN URL
    return `https://dongliwenlv.oss-cn-guangzhou.aliyuncs.com/audio/${filename}.mp3`;
  }
}

// 导出单例实例
export const smartTourGuide = new SmartTourGuide();
export const visionRecognition = new VisionRecognition();
export const speechSynthesis = new SpeechSynthesis();

// 导出默认导出
export default {
  smartTourGuide,
  visionRecognition,
  speechSynthesis
};
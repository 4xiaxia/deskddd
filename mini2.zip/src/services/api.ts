// src/services/api.ts
import { 
  mockRoutes, 
  getRouteDetail, 
  getPOIDetail, 
  getContentModel 
} from '../data/mockData';

const API_BASE_URL = 'http://localhost:3000/api';

// 模拟延迟
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

class ApiClient {
  private baseUrl: string;
  private token: string | null;
  private useMockData: boolean;

  constructor() {
    this.baseUrl = API_BASE_URL;
    this.token = localStorage.getItem('auth_token');
    // 在开发环境中使用模拟数据
    this.useMockData = true;
  }

  // 设置认证token
  setToken(token: string | null) {
    this.token = token;
    if (token) {
      localStorage.setItem('auth_token', token);
    } else {
      localStorage.removeItem('auth_token');
    }
  }

  // 获取请求头
  private getHeaders(): HeadersInit {
    const headers: HeadersInit = {
      'Content-Type': 'application/json',
    };

    if (this.token) {
      headers['Authorization'] = `Bearer ${this.token}`;
    }

    return headers;
  }

  // 发起请求
  async request(endpoint: string, options: RequestInit = {}) {
    if (this.useMockData) {
      // 使用模拟数据的逻辑
      await delay(500); // 模拟网络延迟
      return this.handleMockRequest(endpoint, options);
    }

    const url = `${this.baseUrl}${endpoint}`;
    const config: RequestInit = {
      ...options,
      headers: {
        ...this.getHeaders(),
        ...options.headers,
      },
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('API请求失败:', error);
      throw error;
    }
  }

  // 处理模拟请求
  private async handleMockRequest(endpoint: string, options: RequestInit) {
    const method = options.method || 'GET';
    const body = options.body ? JSON.parse(options.body as string) : null;

    switch (endpoint) {
      case '/users/login':
        if (method === 'POST' && body?.phone) {
          return {
            token: 'mock_token_' + Date.now(),
            user: {
              id: 'user_1',
              phone: body.phone,
              name: '游客',
              createdAt: new Date().toISOString()
            }
          };
        }
        break;

      case '/routes':
        return mockRoutes;

      default:
        // 处理带参数的路由
        if (endpoint.startsWith('/routes/')) {
          const routeId = endpoint.replace('/routes/', '');
          const detail = getRouteDetail(routeId);
          if (detail) return detail;
        } else if (endpoint.startsWith('/pois/')) {
          const poiId = endpoint.replace('/pois/', '');
          const poi = getPOIDetail(poiId);
          if (poi) return poi;
        } else if (endpoint.startsWith('/content-models/')) {
          const modelId = endpoint.replace('/content-models/', '');
          const model = getContentModel(modelId);
          if (model) return model;
        } else if (endpoint === '/guide/explain-poi' && method === 'POST') {
          // 模拟AI解释
          return {
            summary: 'AI导游为您详细介绍这个景点的历史背景和文化意义。',
            knowledge: [
              { body: '这是一个具有重要历史意义的文化景点。' },
              { body: '这里承载着深厚的历史文化底蕴。' },
              { body: '您可以在这里体验到传统的文化氛围。' }
            ]
          };
        } else if (endpoint === '/stats/record-visit' && method === 'POST') {
          return { success: true };
        } else if (endpoint === '/stats/visit-stats') {
          return {
            totalVisits: 1234,
            popularPOIs: [
              { id: 'poi_1', name: '东里村古牌坊', visits: 156 },
              { id: 'poi_2', name: '古民居群', visits: 134 }
            ]
          };
        } else if (endpoint === '/stats/popular-pois') {
          return [
            { id: 'poi_1', name: '东里村古牌坊', visits: 156 },
            { id: 'poi_2', name: '古民居群', visits: 134 },
            { id: 'poi_3', name: '古井', visits: 98 }
          ];
        } else if (endpoint === '/content/pending') {
          return [];
        }
    }

    throw new Error(`未找到对应的端点: ${endpoint}`);
  }

  // 用户认证相关API
  async login(phone: string) {
    return await this.request('/users/login', {
      method: 'POST',
      body: JSON.stringify({ phone }),
    });
  }

  async getUserProfile() {
    return await this.request('/users/profile');
  }

  // 路线相关API
  async getRoutes() {
    return await this.request('/routes');
  }

  async getRouteDetail(routeId: string) {
    return await this.request(`/routes/${routeId}`);
  }

  // 景点相关API
  async getPoiDetail(poiId: string) {
    return await this.request(`/pois/${poiId}`);
  }

  async getContentModel(modelId: string) {
    return await this.request(`/content-models/${modelId}`);
  }

  async explainPoi(poiId: string, userContext: Record<string, any> = {}) {
    return await this.request('/guide/explain-poi', {
      method: 'POST',
      body: JSON.stringify({ poiId, userContext }),
    });
  }

  // 统计相关API
  async recordVisit(poiId: string, actionType?: string) {
    return await this.request('/stats/record-visit', {
      method: 'POST',
      body: JSON.stringify({ poiId, actionType }),
    });
  }

  async getVisitStats(timeRange?: string) {
    const params = timeRange ? `?timeRange=${timeRange}` : '';
    return await this.request(`/stats/visit-stats${params}`);
  }

  async getPopularPois(limit?: number) {
    const params = limit ? `?limit=${limit}` : '';
    return await this.request(`/stats/popular-pois${params}`);
  }

  async getUserVisitDetails(timeRange?: string) {
    const params = timeRange ? `?timeRange=${timeRange}` : '';
    return await this.request(`/stats/user-visit-details${params}`);
  }

  // 内容上传相关API
  async uploadContent(file: File, contentType: string) {
    if (this.useMockData) {
      await delay(1000);
      return { success: true, url: 'mock_url', id: 'upload_1' };
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('contentType', contentType);

    const url = `${this.baseUrl}/content/upload`;
    const config: RequestInit = {
      method: 'POST',
      body: formData,
      headers: this.token ? { 'Authorization': `Bearer ${this.token}` } : {},
    };

    try {
      const response = await fetch(url, config);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `HTTP error! status: ${response.status}`);
      }
      
      return await response.json();
    } catch (error) {
      console.error('文件上传失败:', error);
      throw error;
    }
  }

  async getPendingContent() {
    return await this.request('/content/pending');
  }

  async reviewContent(contentId: number, status: string, reason?: string) {
    return await this.request(`/content/review/${contentId}`, {
      method: 'POST',
      body: JSON.stringify({ status, reason }),
    });
  }
}

export const apiClient = new ApiClient();
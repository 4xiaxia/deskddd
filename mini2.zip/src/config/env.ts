/**
 * 环境配置管理
 * 统一管理所有AI服务的API配置
 * 基于用户提供的配置信息
 */

// 智谱AI配置
export const ZHIPU_CONFIG = {
  API_KEY: 'a049afdafb1b41a0862cdc1d73d5d6eb.YuGYXVGRQEUILpog',
  BASE_URL: 'https://open.bigmodel.cn/api/paas/v4',
  TEXT_MODEL: 'glm-4.5-flash',
  VISION_MODEL: 'glm-4.1v-thinking-flash',
  IMAGE_MODEL: 'cogview-3-flash',
  VIDEO_MODEL: 'cogvideox-flash',
  SPEECH_MODEL: 'speech-02'
};

// 硅基流API配置
export const SILICONFLOW_CONFIG = {
  API_URL: 'https://api.siliconflow.cn',
  API_KEY: 'sk-xwmofaucrbykmzwwtbdwannjoxzxhssbwcfeafxykkdoouwe',
  DEFAULT_MODEL: 'Qwen/Qwen3-8B',
  REASONING_MODEL: 'deepseek-ai/DeepSeek-R1-0528-Qwen3-8B',
  SPEECH_MODEL: 'FunAudioLLM/SenseVoiceSmall',
  VECTOR_MODEL: 'BAAI/bge-m3',
  EMBEDDING_MODEL: 'netease-youdao/bce-embedding-base_v1',
  IMAGE_MODEL: 'Kwai-Kolors/Kolors'
};

// 数据库配置
export const DATABASE_CONFIG = {
  // Neon数据库
  NEON_URL: 'postgresql://user:pass@ep-cool-123456.us-east-2.aws.neon.tech/db',
  // Prisma + Neon加速配置
  PRISMA_URL: 'prisma+postgres://accelerate.prisma-data.net/?api_key=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqd3RfaWQiOjEsInNlY3VyZV9rZXkiOiJza19DQ1FIbUtDYkUwcTBiWkhtNTJiSmciLCJhcGlfa2V5IjoiMDFLOVRWMEpHQjI3MlRUUkVWWDk2UDFRTVoiLCJ0ZW5hbnRfaWQiOiJhODM1YTUwNjMwZDY1NzAzZjRmNjQxOGM3ZmNlYjdhMjE3OWRjNTcxZThmMWIxZWI3MGExNDU2NDY2MTY3OGFiIiwiaW50ZXJuYWxfc2VjcmV0IjoiZDhmZThkMjUtYTE4My00ZDBiLWFiZWEtYjQ4YTU4NGRkZTZjIn0.HNIM7JuLCLKajnvnXXPH1yjYXklnhSAu8lRqdhcdPDg'
};

// Qdrant向量数据库配置
export const QDRANT_CONFIG = {
  URL: 'https://e3f2e618-3729-4b85-beb3-8faa865cab7e.europe-west3-0.gcp.cloud.qdrant.io:6333',
  API_KEY: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJhY2Nlc3MiOiJtIn0.4ovkryhcXhKqMnbBZdVJbSlJMM-BL39lW5CrRlQZ0XU'
};

// Redis配置
export const REDIS_CONFIG = {
  HOST: 'redis-18200.c299.asia-northeast1-1.gce.cloud.redislabs.com',
  PORT: 18200,
  PASSWORD: '******' // 实际使用时需要解密
};

// 地图服务配置
export const MAP_CONFIG = {
  BAIDU_AK: 'MqHKgyBYbe7jE9XqWrTR2dcc0JhcHyO1',
  AMAP_KEY: 'your-amap-key-here',
  ATLAS_GIS_TOKEN: 'pk.eyJqdGkiOjI0OTMzLCJpYXQiOjE3NjExNTY4NDl9.qpU3dw9JoZxM0_gEOpNg79GQyy1WffrGh3TwmRukLFY',
  DIDDI_KEY: 'LpQO34wBYvoyWNBPaDYpOGzk9qmrjZRW'
};

// CDN配置 - 优先使用阿里云和字节跳动
export const CDN_CONFIG = {
  OSS_BUCKET: 'dongliwenlv.oss-cn-guangzhou.aliyuncs.com',
  BYTEDANCE_CDN: 'https://cdn.bytedance.com',
  ALIBABA_CDN: 'https://oss-cn-guangzhou.aliyuncs.com'
};

// API配置 - 隐藏敏感信息
export const API_CONFIG = {
  BASE_URL: '/api',
  TIMEOUT: 10000,
  RETRY_COUNT: 3,
  // 缓存配置
  CACHE_TTL: {
    USER_PROFILE: 3600, // 1小时
    ROUTE_DATA: 1800,   // 30分钟
    POI_DATA: 900,      // 15分钟
    AI_RESPONSE: 300    // 5分钟
  }
};

// 默认导出
export default {
  ZHIPU_CONFIG,
  SILICONFLOW_CONFIG,
  DATABASE_CONFIG,
  QDRANT_CONFIG,
  REDIS_CONFIG,
  MAP_CONFIG,
  CDN_CONFIG,
  API_CONFIG
};
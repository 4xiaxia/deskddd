import { useEffect, useState } from 'react';
import { Router, Route } from 'wouter';
import { useAuthStore } from './stores/authStore';
import { LoginPage } from './pages/LoginPage';
import { HomePage } from './pages/HomePage';
import { RoutesPage } from './pages/RoutesPage';
import { RouteDetailPage } from './pages/RouteDetailPage';
import { POIDetailPage } from './pages/POIDetailPage';
import { AIAgentDrawer } from './components/AIAgentDrawer';
import { AIMainApp } from './components/AIMainApp';
import { ErrorBoundary } from './components/ErrorBoundary';
import './App.css';

function App() {
  const { user, setUser, setToken } = useAuthStore();
  const [aiMode, setAiMode] = useState(false);

  // Initialize auth from localStorage
  useEffect(() => {
    const token = localStorage.getItem('auth_token');
    const userStr = localStorage.getItem('user');
    const aiModeStr = localStorage.getItem('ai_mode');
    
    if (token && userStr) {
      try {
        const user = JSON.parse(userStr);
        setUser(user);
        setToken(token);
      } catch (error) {
        console.error('Failed to restore auth:', error);
      }
    }
    
    // 恢复AI模式设置
    if (aiModeStr === 'true') {
      setAiMode(true);
    }
  }, [setUser, setToken]);

  // 切换AI模式
  const toggleAIMode = () => {
    const newMode = !aiMode;
    setAiMode(newMode);
    localStorage.setItem('ai_mode', newMode.toString());
  };

  // 登录页面不需要AI模式切换
  if (!user) {
    return (
      <ErrorBoundary>
        <Router>
          <div className="app-shell">
            <Route path="/login" component={LoginPage} />
            <Route path="/" component={() => window.location.href = '/login'} />
          </div>
        </Router>
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <Router>
        <div className="app-shell">
          {/* AI模式切换按钮 - 仅在已登录状态下显示 */}
          <div className="fixed top-4 right-4 z-50">
            <button
              onClick={toggleAIMode}
              className={`px-4 py-2 rounded-full text-sm font-medium transition-all duration-200 ${
                aiMode 
                  ? 'bg-blue-600 text-white shadow-lg' 
                  : 'bg-white text-gray-700 border border-gray-300 hover:bg-gray-50'
              }`}
            >
              {aiMode ? (
                <div className="flex items-center space-x-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>AI模式</span>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                    <path d="M10 2L3 7v11a2 2 0 002 2h10a2 2 0 002-2V7l-7-5zM8 15v-2a2 2 0 012-2h4a2 2 0 012 2v2" />
                  </svg>
                  <span>经典模式</span>
                </div>
              )}
            </button>
          </div>

          {/* 路由渲染 - 根据AI模式条件渲染 */}
          {aiMode ? (
            // AI增强模式
            <AIMainApp />
          ) : (
            // 经典模式 - 原有路由
            <>
              <Route path="/home" component={HomePage} />
              <Route path="/routes" component={RoutesPage} />
              <Route path="/route/:routeId" component={({ params }) => (
                <ErrorBoundary>
                  <RouteDetailPage routeId={params.routeId} />
                </ErrorBoundary>
              )} />
              <Route path="/route/:routeId/poi/:poiId" component={({ params }) => (
                <ErrorBoundary>
                  <POIDetailPage routeId={params.routeId} poiId={params.poiId} />
                </ErrorBoundary>
              )} />
              
              {/* Default route - 经典模式 */}
              <Route path="/" component={() => window.location.href = '/home'} />

              {/* AI Agent Drawer - 经典模式下显示 */}
              <AIAgentDrawer />
            </>
          )}
        </div>
      </Router>
    </ErrorBoundary>
  );
}

export default App;

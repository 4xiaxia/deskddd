/**
 * POI图像识别组件
 * 集成智谱AI视觉能力，实现景点自动识别
 * 移动端优先设计，极简交互
 */

import React, { useState, useRef, useCallback } from 'react';
import { visionRecognition } from '../services/aiService';
import type { POI } from '../types';

interface POIRecognitionProps {
  currentLocation: { lat: number; lng: number };
  onPOIIdentified: (poi: POI) => void;
  onError: (error: string) => void;
}

interface RecognitionResult {
  success: boolean;
  poiId?: string;
  confidence?: number;
  error?: string;
  artifacts?: string;
}

export const POIRecognition: React.FC<POIRecognitionProps> = ({
  currentLocation,
  onPOIIdentified,
  onError
}) => {
  const [isCapturing, setIsCapturing] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [recognitionResult, setRecognitionResult] = useState<RecognitionResult | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);

  // 启动相机
  const startCamera = useCallback(async () => {
    try {
      setIsCapturing(true);
      
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment', // 后置摄像头
          width: { ideal: 1280 },
          height: { ideal: 720 }
        }
      });
      
      streamRef.current = stream;
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
    } catch (error) {
      console.error('启动相机错误:', error);
      onError('无法启动相机，请检查权限设置');
      setIsCapturing(false);
    }
  }, [onError]);

  // 停止相机
  const stopCamera = useCallback(() => {
    if (streamRef.current) {
      streamRef.current.getTracks().forEach(track => track.stop());
      streamRef.current = null;
    }
    setIsCapturing(false);
    setPreviewImage(null);
  }, []);

  // 拍照
  const capturePhoto = useCallback(() => {
    if (!videoRef.current || !canvasRef.current) return;

    const video = videoRef.current;
    const canvas = canvasRef.current;
    const context = canvas.getContext('2d');

    if (!context) return;

    canvas.width = video.videoWidth;
    canvas.height = video.videoHeight;
    
    context.drawImage(video, 0, 0);
    
    // 转换为base64
    const imageData = canvas.toDataURL('image/jpeg', 0.8);
    setPreviewImage(imageData);
    
    // 自动开始识别
    analyzeImage(imageData);
  }, []);

  // 上传图片
  const handleFileUpload = useCallback((event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setPreviewImage(result);
      analyzeImage(result);
    };
    reader.readAsDataURL(file);
  }, []);

  // 分析图片
  const analyzeImage = useCallback(async (imageData: string) => {
    setIsAnalyzing(true);
    setRecognitionResult(null);

    try {
      const result = await visionRecognition.identifyPOI(
        imageData.split(',')[1], // 移除data:image/jpeg;base64,前缀
        currentLocation
      );

      setRecognitionResult({
        success: true,
        poiId: result.result.poiId,
        confidence: result.confidence
      });

      // 如果识别成功，可以触发POI详情显示
      if (result.result.poiId && result.confidence > 0.7) {
        // 这里可以根据poiId获取POI详细信息
        // 暂时使用模拟数据
        const mockPOI: POI = {
          id: result.result.poiId,
          name: result.result.poiName || '识别的景点',
          description: '通过AI识别到的景点',
          latitude: currentLocation.lat,
          longitude: currentLocation.lng,
          images: [imageData],
          order: 1,
          contentModelId: 'identified'
        };
        
        onPOIIdentified(mockPOI);
      }
    } catch (error) {
      console.error('POI识别错误:', error);
      setRecognitionResult({
        success: false,
        error: '识别失败，请重试'
      });
      onError('图像识别服务暂时不可用');
    } finally {
      setIsAnalyzing(false);
    }
  }, [currentLocation, onPOIIdentified, onError]);

  // 重新拍摄
  const retakePhoto = useCallback(() => {
    setPreviewImage(null);
    setRecognitionResult(null);
  }, []);

  // 选择图片
  const selectImage = useCallback(() => {
    fileInputRef.current?.click();
  }, []);

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      {/* 顶部导航 */}
      <div className="flex items-center justify-between p-4 bg-black text-white">
        <button
          onClick={() => window.history.back()}
          className="p-2 -ml-2 rounded-full hover:bg-gray-800"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
          </svg>
        </button>
        
        <h3 className="font-semibold">景点识别</h3>
        
        <div className="w-10"></div>
      </div>

      {/* 相机预览区域 */}
      <div className="flex-1 relative overflow-hidden">
        {!previewImage && !isAnalyzing && (
          <>
            {/* 相机预览 */}
            {isCapturing ? (
              <video
                ref={videoRef}
                className="w-full h-full object-cover"
                playsInline
                muted
              />
            ) : (
              <div className="w-full h-full flex items-center justify-center bg-gray-900">
                <div className="text-center text-white">
                  <div className="w-20 h-20 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                    <svg className="w-10 h-10" fill="currentColor" viewBox="0 0 20 20">
                      <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                    </svg>
                  </div>
                  <p className="text-gray-400 mb-6">点击下方按钮开始拍照</p>
                </div>
              </div>
            )}

            {/* 识别框引导 */}
            {isCapturing && (
              <div className="absolute inset-4 border-2 border-white border-dashed rounded-lg flex items-center justify-center">
                <div className="text-center text-white bg-black bg-opacity-50 px-4 py-2 rounded">
                  <p className="text-sm">请将景点置于框内</p>
                  <p className="text-xs text-gray-300 mt-1">AI将自动识别景点信息</p>
                </div>
              </div>
            )}
          </>
        )}

        {/* 预览图片 */}
        {previewImage && (
          <img
            src={previewImage}
            alt="拍照预览"
            className="w-full h-full object-cover"
          />
        )}

        {/* 分析中 */}
        {isAnalyzing && (
          <div className="absolute inset-0 bg-black bg-opacity-80 flex items-center justify-center">
            <div className="text-center text-white">
              <div className="w-16 h-16 border-4 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-lg font-semibold mb-2">AI正在识别景点...</p>
              <p className="text-sm text-gray-300">请保持设备稳定</p>
            </div>
          </div>
        )}

        {/* 识别结果 */}
        {recognitionResult && !isAnalyzing && (
          <div className="absolute bottom-4 left-4 right-4">
            <div className={`p-4 rounded-lg ${
              recognitionResult.success 
                ? 'bg-green-500 text-white' 
                : 'bg-red-500 text-white'
            }`}>
              {recognitionResult.success ? (
                <div>
                  <p className="font-semibold mb-1">识别成功！</p>
                  <p className="text-sm">
                    {recognitionResult.confidence && (
                      <span>置信度: {(recognitionResult.confidence * 100).toFixed(1)}%</span>
                    )}
                  </p>
                </div>
              ) : (
                <div>
                  <p className="font-semibold mb-1">识别失败</p>
                  <p className="text-sm">{recognitionResult.error}</p>
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 底部控制栏 */}
      <div className="p-6 bg-black">
        {!previewImage && !isAnalyzing && (
          <div className="flex justify-center space-x-8">
            {/* 上传图片 */}
            <button
              onClick={selectImage}
              className="p-3 rounded-full bg-gray-700 text-white hover:bg-gray-600"
            >
              <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
              </svg>
            </button>

            {/* 拍照按钮 */}
            {isCapturing ? (
              <button
                onClick={capturePhoto}
                className="p-4 rounded-full bg-blue-600 text-white hover:bg-blue-700"
              >
                <div className="w-8 h-8 bg-white rounded-full"></div>
              </button>
            ) : (
              <button
                onClick={startCamera}
                className="p-4 rounded-full bg-blue-600 text-white hover:bg-blue-700"
              >
                <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                </svg>
              </button>
            )}

            {/* 停止相机 */}
            {isCapturing && (
              <button
                onClick={stopCamera}
                className="p-3 rounded-full bg-red-600 text-white hover:bg-red-700"
              >
                <svg className="w-6 h-6" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM8 7a1 1 0 00-1 1v4a1 1 0 001 1h4a1 1 0 001-1V8a1 1 0 00-1-1H8z" clipRule="evenodd" />
                </svg>
              </button>
            )}
          </div>
        )}

        {/* 预览操作栏 */}
        {previewImage && !isAnalyzing && (
          <div className="flex justify-center space-x-6">
            <button
              onClick={retakePhoto}
              className="px-6 py-3 bg-gray-700 text-white rounded-full hover:bg-gray-600"
            >
              重新拍摄
            </button>
            
            {recognitionResult?.success ? (
              <button
                onClick={() => onPOIIdentified({
                  id: recognitionResult.poiId || '',
                  name: '识别的景点',
                  description: '通过AI识别的景点',
                  latitude: currentLocation.lat,
                  longitude: currentLocation.lng,
                  images: [previewImage],
                  order: 1,
                  contentModelId: 'identified'
                })}
                className="px-6 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700"
              >
                查看详情
              </button>
            ) : (
              <button
                onClick={() => analyzeImage(previewImage)}
                className="px-6 py-3 bg-blue-600 text-white rounded-full hover:bg-blue-700"
              >
                重新识别
              </button>
            )}
          </div>
        )}
      </div>

      {/* 隐藏的canvas用于拍照 */}
      <canvas ref={canvasRef} className="hidden" />
      
      {/* 隐藏的文件输入 */}
      <input
        ref={fileInputRef}
        type="file"
        accept="image/*"
        onChange={handleFileUpload}
        className="hidden"
        capture="environment"
      />
    </div>
  );
};

export default POIRecognition;
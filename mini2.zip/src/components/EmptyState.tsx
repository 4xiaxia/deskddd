interface EmptyStateProps {
  icon?: string | React.ReactNode;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({ 
  icon = '📱', 
  title, 
  description, 
  action, 
  className = '' 
}: EmptyStateProps) {
  return (
    <div className={`text-center py-12 ${className}`}>
      <div className="text-4xl mb-4">{typeof icon === 'string' ? icon : icon}</div>
      <h3 className="text-lg font-semibold text-gray-900 mb-2">{title}</h3>
      {description && (
        <p className="text-gray-600 mb-6 max-w-md mx-auto leading-relaxed">{description}</p>
      )}
      {action && <div>{action}</div>}
    </div>
  );
}

// 预设的空状态类型
export const EmptyStates = {
  noRoutes: (action?: React.ReactNode) => (
    <EmptyState
      icon="🗺️"
      title="暂无导览路线"
      description="当前没有可用的导览路线，请稍后再试或联系管理员。"
      action={action}
    />
  ),
  
  noPOIs: (action?: React.ReactNode) => (
    <EmptyState
      icon="📍"
      title="暂无景点信息"
      description="该路线下还没有添加景点信息，请稍后再试。"
      action={action}
    />
  ),
  
  networkError: (onRetry?: () => void) => (
    <EmptyState
      icon="🌐"
      title="网络连接异常"
      description="无法连接到服务器，请检查网络连接后重试。"
      action={
        onRetry && (
          <button
            onClick={onRetry}
            className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-opacity-90 transition-opacity"
          >
            重试
          </button>
        )
      }
    />
  ),
  
  noData: (title: string, description?: string, action?: React.ReactNode) => (
    <EmptyState
      icon="📊"
      title={title}
      description={description}
      action={action}
    />
  )
};
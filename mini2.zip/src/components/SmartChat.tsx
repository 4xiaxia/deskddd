/**
 * 智能导游聊天组件
 * 移动端优先设计，集成智谱AI和硅基流服务
 * 遵循极简性能美学原则
 */

import React, { useState, useRef, useEffect } from 'react';
import { smartTourGuide } from '../services/aiService';
import type { POI } from '../types';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: number;
  location?: { lat: number; lng: number };
  poiId?: string;
}

interface SmartChatProps {
  currentLocation: { lat: number; lng: number };
  nearbyPOIs: POI[];
  userId: string;
  onPOISelect?: (poiId: string) => void;
}

export const SmartChat: React.FC<SmartChatProps> = ({
  currentLocation,
  nearbyPOIs,
  userId,
  onPOISelect
}) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);

  // 自动滚动到底部
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // 发送消息
  const sendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: inputValue.trim(),
      timestamp: Date.now(),
      location: currentLocation
    };

    setMessages(prev => [...prev, userMessage]);
    setInputValue('');
    setIsLoading(true);

    try {
      const response = await smartTourGuide.chatWithLocation(
        userId,
        userMessage.content,
        currentLocation,
        nearbyPOIs.map(poi => poi.name)
      );

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: response.content,
        timestamp: Date.now()
      };

      setMessages(prev => [...prev, assistantMessage]);
    } catch (error) {
      console.error('发送消息错误:', error);
      const errorMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: '抱歉，AI导游暂时无法回应。请稍后重试或联系现场工作人员。',
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  // 语音识别
  const startVoiceInput = () => {
    if (!navigator.mediaDevices) {
      alert('您的设备不支持语音输入功能');
      return;
    }

    setIsListening(true);
    
    navigator.mediaDevices.getUserMedia({ audio: true })
      .then(stream => {
        const mediaRecorder = new MediaRecorder(stream);
        mediaRecorderRef.current = mediaRecorder;

        const audioChunks: Blob[] = [];
        
        mediaRecorder.ondataavailable = (event) => {
          audioChunks.push(event.data);
        };

        mediaRecorder.onstop = () => {
          const audioBlob = new Blob(audioChunks, { type: 'audio/wav' });
          // 这里应该调用语音转文字服务
          // 暂时用模拟文本
          setInputValue('这个景点有什么历史故事？');
          setIsListening(false);
        };

        mediaRecorder.start();
        setTimeout(() => {
          mediaRecorder.stop();
        }, 3000); // 3秒录音
      })
      .catch(error => {
        console.error('语音识别错误:', error);
        setIsListening(false);
        alert('语音识别启动失败，请检查麦克风权限');
      });
  };

  // 快捷问题
  const quickQuestions = [
    '这个景点有什么历史故事？',
    '推荐一条合适的游览路线',
    '这里有什么特色美食？',
    '附近的洗手间在哪里？',
    '拍照推荐的最佳位置？'
  ];

  return (
    <div className="fixed inset-0 flex flex-col bg-white z-50">
      {/* 顶部导航 */}
      <div className="flex items-center justify-between p-4 border-b bg-white">
        <div className="flex items-center">
          <button
            onClick={() => window.history.back()}
            className="mr-3 p-2 -ml-2 rounded-full hover:bg-gray-100"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
          </button>
          <div className="flex items-center">
            <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mr-2">
              <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">AI智能导游</h3>
              <p className="text-xs text-gray-500">
                {nearbyPOIs.length}个景点在附近
              </p>
            </div>
          </div>
        </div>
        <div className="text-xs text-gray-400">
          GPS: {currentLocation.lat.toFixed(4)}, {currentLocation.lng.toFixed(4)}
        </div>
      </div>

      {/* 消息列表 */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.length === 0 && (
          <div className="text-center py-8">
            <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                <path d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" />
              </svg>
            </div>
            <p className="text-gray-500 mb-4">我是东里村AI智能导游</p>
            <p className="text-sm text-gray-400">
              我可以为您介绍景点历史、推荐游览路线、解答各类问题
            </p>
          </div>
        )}

        {messages.map((message) => (
          <div
            key={message.id}
            className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs lg:max-w-md px-4 py-2 rounded-lg ${
                message.role === 'user'
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-900'
              }`}
            >
              <p className="text-sm">{message.content}</p>
              <p className={`text-xs mt-1 ${
                message.role === 'user' ? 'text-blue-200' : 'text-gray-500'
              }`}>
                {new Date(message.timestamp).toLocaleTimeString('zh-CN', {
                  hour: '2-digit',
                  minute: '2-digit'
                })}
              </p>
            </div>
          </div>
        ))}

        {isLoading && (
          <div className="flex justify-start">
            <div className="bg-gray-100 rounded-lg px-4 py-2">
              <div className="flex space-x-1">
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce"></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                <div className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
              </div>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* 快捷问题 */}
      {messages.length === 0 && (
        <div className="px-4 py-2 border-t bg-gray-50">
          <p className="text-xs text-gray-500 mb-2">常见问题：</p>
          <div className="flex flex-wrap gap-2">
            {quickQuestions.slice(0, 3).map((question, index) => (
              <button
                key={index}
                onClick={() => setInputValue(question)}
                className="text-xs px-3 py-1 bg-white border border-gray-200 rounded-full hover:bg-gray-50"
              >
                {question}
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 附近景点推荐 */}
      {nearbyPOIs.length > 0 && messages.length === 0 && (
        <div className="px-4 py-2 border-t bg-gray-50">
          <p className="text-xs text-gray-500 mb-2">附近景点：</p>
          <div className="flex space-x-2 overflow-x-auto">
            {nearbyPOIs.map((poi) => (
              <button
                key={poi.id}
                onClick={() => onPOISelect?.(poi.id)}
                className="flex-shrink-0 text-xs px-3 py-2 bg-white border border-gray-200 rounded-lg hover:bg-gray-50"
              >
                <div className="text-center">
                  <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-1">
                    <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3zM3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a1 1 0 00.364 0l2.818-1.15v3.957a9.026 9.026 0 00-2.878-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM3 13.582V9.397l2.818 1.15a1 1 0 00.364 0l2.818-1.15v4.185A8.987 8.987 0 0010 21a8.987 8.987 0 007-4.418z" />
                    </svg>
                  </div>
                  <p className="text-center">{poi.name}</p>
                </div>
              </button>
            ))}
          </div>
        </div>
      )}

      {/* 输入区域 */}
      <div className="border-t bg-white p-4">
        <div className="flex items-center space-x-2">
          <div className="flex-1 flex items-center bg-gray-100 rounded-full px-4 py-2">
            <input
              type="text"
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder={isListening ? '正在录音...' : '请输入您的问题'}
              className="flex-1 bg-transparent outline-none text-sm"
              disabled={isListening}
            />
            {isListening && (
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
            )}
          </div>
          
          <button
            onClick={startVoiceInput}
            disabled={isListening}
            className={`p-3 rounded-full ${
              isListening 
                ? 'bg-red-500 text-white' 
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M7 4a3 3 0 016 0v4a3 3 0 11-6 0V4zm4 10.93A7.001 7.001 0 0017 8a1 1 0 10-2 0A5 5 0 015 8a1 1 0 00-2 0 7.001 7.001 0 006 6.93V17H6a1 1 0 100 2h8a1 1 0 100-2h-3v-2.07z" clipRule="evenodd" />
            </svg>
          </button>

          <button
            onClick={sendMessage}
            disabled={!inputValue.trim() || isLoading}
            className={`p-3 rounded-full ${
              !inputValue.trim() || isLoading
                ? 'bg-gray-300 text-gray-500'
                : 'bg-blue-600 text-white hover:bg-blue-700'
            }`}
          >
            <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default SmartChat;
/**
 * AI增强的主应用组件
 * 集成智谱AI、硅基流服务，实现智能导览
 * 移动端优先设计，数据共享机制
 */

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { Route, useRoute } from 'wouter';
import { SmartChat } from '../components/SmartChat';
import { POIRecognition } from '../components/POIRecognition';
import { Loading } from '../components/Loading';
import { EmptyState } from '../components/EmptyState';
import { useAuthStore, useRoutesStore } from '../stores';
import { speechSynthesis } from '../services/aiService';
import { mockRoutes, mockPOIs, getRouteDetail } from '../data/mockData';

interface LocationState {
  lat: number;
  lng: number;
  accuracy: number;
}

interface NearbyPOI {
  id: string;
  name: string;
  distance: number;
  poi: any;
}

export const AIMainApp: React.FC = () => {
  const { user } = useAuthStore();
  const { routes, loading } = useRoutesStore();
  const [location, setLocation] = useState<LocationState | null>(null);
  const [nearbyPOIs, setNearbyPOIs] = useState<NearbyPOI[]>([]);
  const [showChat, setShowChat] = useState(false);
  const [showRecognition, setShowRecognition] = useState(false);
  const [currentView, setCurrentView] = useState<'home' | 'chat' | 'recognition' | 'route' | 'poi'>('home');
  const [selectedRoute, setSelectedRoute] = useState<string | null>(null);
  const [selectedPOI, setSelectedPOI] = useState<string | null>(null);
  const [audioPlaying, setAudioPlaying] = useState<string | null>(null);

  // 获取用户位置
  const getCurrentLocation = useCallback(async () => {
    try {
      const position = await new Promise<GeolocationPosition>((resolve, reject) => {
        navigator.geolocation.getCurrentPosition(resolve, reject, {
          enableHighAccuracy: true,
          timeout: 10000,
          maximumAge: 60000
        });
      });

      setLocation({
        lat: position.coords.latitude,
        lng: position.coords.longitude,
        accuracy: position.coords.accuracy
      });
    } catch (error) {
      console.error('获取位置错误:', error);
      // 使用东里村默认位置
      setLocation({
        lat: 25.23411225,
        lng: 118.20524049,
        accuracy: 1000
      });
    }
  }, []);

  // 计算距离 (简化版Haversine公式)
  const calculateDistance = useCallback((lat1: number, lng1: number, lat2: number, lng2: number): number => {
    const R = 6371; // 地球半径(公里)
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLng = (lng2 - lng1) * Math.PI / 180;
    const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
              Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
              Math.sin(dLng/2) * Math.sin(dLng/2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
    return R * c * 1000; // 返回米
  }, []);

  // 查找附近的POI
  const findNearbyPOIs = useCallback(() => {
    if (!location) return;

    const nearby: NearbyPOI[] = [];
    
    Object.values(mockPOIs).forEach(routePOIs => {
      routePOIs.forEach(poi => {
        const distance = calculateDistance(
          location.lat, location.lng,
          poi.latitude, poi.longitude
        );
        
        // 500米范围内的POI
        if (distance <= 500) {
          nearby.push({
            id: poi.id,
            name: poi.name,
            distance: Math.round(distance),
            poi
          });
        }
      });
    });

    // 按距离排序
    nearby.sort((a, b) => a.distance - b.distance);
    setNearbyPOIs(nearby.slice(0, 6)); // 最多显示6个
  }, [location, calculateDistance]);

  // 初始化位置
  useEffect(() => {
    getCurrentLocation();
  }, [getCurrentLocation]);

  // 查找附近POI
  useEffect(() => {
    if (location) {
      findNearbyPOIs();
    }
  }, [location, findNearbyPOIs]);

  // 语音播放
  const playAudio = useCallback(async (text: string, audioId: string) => {
    if (audioPlaying === audioId) {
      setAudioPlaying(null);
      return;
    }

    setAudioPlaying(audioId);
    
    try {
      const audioUrl = await speechSynthesis.synthesizeSpeech(text);
      const audio = new Audio(audioUrl);
      
      audio.onended = () => setAudioPlaying(null);
      audio.onerror = () => {
        setAudioPlaying(null);
        console.error('音频播放错误');
      };
      
      await audio.play();
    } catch (error) {
      console.error('语音合成错误:', error);
      setAudioPlaying(null);
    }
  }, [audioPlaying]);

  // 路线详情
  const routeDetail = useMemo(() => {
    return selectedRoute ? getRouteDetail(selectedRoute) : null;
  }, [selectedRoute]);

  // 简化版主页面
  const HomeView = () => (
    <div className="min-h-screen bg-gray-50">
      {/* 顶部用户信息 */}
      <div className="bg-white p-4 border-b">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-lg font-semibold">东里村AI导览</h2>
            <p className="text-sm text-gray-600">欢迎，{user?.name || '游客'}</p>
          </div>
          <div className="text-right">
            <p className="text-xs text-gray-500">
              {nearbyPOIs.length}个景点在附近
            </p>
            {location && (
              <p className="text-xs text-gray-400">
                GPS: {location.accuracy}m
              </p>
            )}
          </div>
        </div>
      </div>

      {/* 附近POI列表 */}
      {nearbyPOIs.length > 0 && (
        <div className="p-4">
          <h3 className="text-sm font-semibold text-gray-700 mb-3">附近景点</h3>
          <div className="space-y-2">
            {nearbyPOIs.map((nearbyPoi) => (
              <div
                key={nearbyPoi.id}
                className="bg-white p-3 rounded-lg border hover:bg-gray-50 cursor-pointer"
                onClick={() => {
                  setSelectedPOI(nearbyPoi.id);
                  setCurrentView('poi');
                }}
              >
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h4 className="font-medium text-sm">{nearbyPoi.name}</h4>
                    <p className="text-xs text-gray-500">{nearbyPoi.distance}米</p>
                  </div>
                  <div className="flex space-x-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        playAudio(nearbyPoi.poi.description, nearbyPoi.id);
                      }}
                      className="p-2 text-blue-600 hover:bg-blue-50 rounded"
                    >
                      {audioPlaying === nearbyPoi.id ? (
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zM7 8a1 1 0 012 0v4a1 1 0 11-2 0V8zm5-1a1 1 0 00-1 1v4a1 1 0 102 0V8a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                      ) : (
                        <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zM9.555 7.168A1 1 0 008 8v4a1 1 0 001.555.832l3-2a1 1 0 000-1.664l-3-2z" clipRule="evenodd" />
                        </svg>
                      )}
                    </button>
                    <div className="w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center">
                      <svg className="w-4 h-4 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                        <path fillRule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 快捷功能 */}
      <div className="p-4 space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <button
            onClick={() => setShowRecognition(true)}
            className="bg-white p-4 rounded-lg border hover:bg-gray-50"
          >
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
                  <path fillRule="evenodd" d="M4 3a2 2 0 00-2 2v10a2 2 0 002 2h12a2 2 0 002-2V5a2 2 0 00-2-2H4zm12 12H4l4-8 3 6 2-4 3 6z" clipRule="evenodd" />
                </svg>
              </div>
              <p className="text-sm font-medium">识别景点</p>
              <p className="text-xs text-gray-500">拍照识别景点</p>
            </div>
          </button>

          <button
            onClick={() => setShowChat(true)}
            className="bg-white p-4 rounded-lg border hover:bg-gray-50"
          >
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-2">
                <svg className="w-6 h-6 text-green-600" fill="currentColor" viewBox="0 0 20 20">
                  <path d="M18 10c0 3.866-3.582 7-8 7a8.841 8.841 0 01-4.083-.98L2 17l1.338-3.123C2.493 12.767 2 11.434 2 10c0-3.866 3.582-7 8-7s8 3.134 8 7zM7 9H5v2h2V9zm8 0h-2v2h2V9zM9 9h2v2H9V9z" />
                </svg>
              </div>
              <p className="text-sm font-medium">AI导游</p>
              <p className="text-xs text-gray-500">智能对话导览</p>
            </div>
          </button>
        </div>
      </div>
    </div>
  );

  // 如果位置获取中，显示加载状态
  if (!location) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Loading size="large" text="获取位置信息..." />
      </div>
    );
  }

  return (
    <>
      {/* 主视图 */}
      {currentView === 'home' && <HomeView />}
      
      {/* AI聊天界面 */}
      {showChat && (
        <SmartChat
          currentLocation={{ lat: location.lat, lng: location.lng }}
          nearbyPOIs={nearbyPOIs.map(n => n.poi)}
          userId={user?.id || 'guest'}
          onPOISelect={(poiId) => {
            setSelectedPOI(poiId);
            setCurrentView('poi');
          }}
        />
      )}

      {/* POI识别界面 */}
      {showRecognition && (
        <POIRecognition
          currentLocation={{ lat: location.lat, lng: location.lng }}
          onPOIIdentified={(poi) => {
            setSelectedPOI(poi.id);
            setCurrentView('poi');
          }}
          onError={(error) => {
            console.error('识别错误:', error);
            alert(error);
          }}
        />
      )}

      {/* 底部固定导航 */}
      {currentView === 'home' && !showChat && !showRecognition && (
        <div className="fixed bottom-0 left-0 right-0 bg-white border-t p-4">
          <div className="flex justify-center space-x-4">
            <button
              onClick={() => setShowChat(true)}
              className="flex-1 bg-blue-600 text-white py-3 rounded-full font-medium"
            >
              AI导游对话
            </button>
            <button
              onClick={() => setShowRecognition(true)}
              className="flex-1 bg-green-600 text-white py-3 rounded-full font-medium"
            >
              识别景点
            </button>
          </div>
        </div>
      )}

      {/* 返回按钮 */}
      {(showChat || showRecognition) && (
        <button
          onClick={() => {
            setShowChat(false);
            setShowRecognition(false);
          }}
          className="fixed top-4 left-4 z-50 p-3 bg-black bg-opacity-50 text-white rounded-full"
        >
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>
      )}

      {/* 底部安全区域 */}
      {currentView === 'home' && !showChat && !showRecognition && (
        <div className="h-20"></div>
      )}
    </>
  );
};

export default AIMainApp;
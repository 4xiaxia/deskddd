import { useState, useRef, useEffect } from 'react';
import { useAgentStore } from '../store/agentStore';
import { useRouteStore } from '../store/routeStore';
import { apiClient } from '../services/api';
import type { AIMessage } from '../types';

export function AIAgentDrawer() {
  const {
    isOpen,
    toggleAgent,
    conversations,
    currentConversationId,
    addMessage,
    setIsLoading,
    isLoading,
  } = useAgentStore();
  const { currentPOI, currentRoute, contentModel } = useRouteStore();

  const [input, setInput] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [conversations, currentConversationId]);

  const currentConversation = currentConversationId
    ? conversations.get(currentConversationId)
    : null;

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!input.trim() || !currentConversationId || isLoading) return;

    const userMessage: AIMessage = {
      id: `msg_${Date.now()}`,
      role: 'user',
      content: input,
      timestamp: new Date().toISOString(),
      type: 'text',
    };

    addMessage(currentConversationId, userMessage);
    setInput('');
    setIsLoading(true);

    try {
      const explanation = await apiClient.explainPoi(currentPOI?.id || currentRoute?.id || '', {
        routeId: currentRoute?.id,
        poiId: currentPOI?.id,
        routeName: currentRoute?.name,
        contentModelId: contentModel?.id,
        userMessage: input,
      });

      const knowledgeText = explanation?.knowledge?.map((entry: any) => entry.body).join('\n') || '';
      const aiMessage: AIMessage = {
        id: `msg_${Date.now()}`,
        role: 'assistant',
        content: `${explanation?.summary || '正在整理讲解内容。'}\n${knowledgeText}`.trim(),
        timestamp: new Date().toISOString(),
        type: 'text',
      };
      addMessage(currentConversationId, aiMessage);
    } catch (err) {
      const aiMessage: AIMessage = {
        id: `msg_${Date.now()}`,
        role: 'assistant',
        content: '抱歉，我暂时无法获取更详细的讲解，请稍后再试。',
        timestamp: new Date().toISOString(),
        type: 'text',
      };
      addMessage(currentConversationId, aiMessage);
      console.error('Explain POI failed:', err);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <>
      {/* Floating Button */}
      <button
        onClick={toggleAgent}
        className="fixed bottom-6 right-6 w-14 h-14 bg-brand-primary text-white rounded-full shadow-lg hover:shadow-xl hover:scale-110 transition-all floating-agent-shadow z-40 flex items-center justify-center text-2xl"
        title="AI导游助手"
      >
        🤖
      </button>

      {/* Drawer */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex flex-col">
          {/* Overlay */}
          <div
            className="absolute inset-0 bg-black bg-opacity-30"
            onClick={toggleAgent}
          />

          {/* Drawer Content */}
          <div className="absolute bottom-0 right-0 w-full sm:w-96 h-3/4 bg-white rounded-t-2xl shadow-2xl flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between p-4 border-b border-gray-200">
              <h2 className="text-lg font-semibold text-gray-900">AI导游助手</h2>
              <button
                onClick={toggleAgent}
                className="text-gray-500 hover:text-gray-700 transition-colors"
              >
                ✕
              </button>
            </div>

            {/* Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3">
              {currentConversation && currentConversation.messages.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <p className="text-sm">开始与AI导游对话</p>
                  <p className="text-xs mt-2">询问景点信息、路线建议等</p>
                </div>
              ) : (
                currentConversation?.messages.map((message) => (
                  <div
                    key={message.id}
                    className={`flex ${
                      message.role === 'user' ? 'justify-end' : 'justify-start'
                    }`}
                  >
                    <div
                      className={`max-w-xs px-3 py-2 rounded-lg ${
                        message.role === 'user'
                          ? 'bg-brand-primary text-white rounded-br-none'
                          : 'bg-gray-100 text-gray-900 rounded-bl-none'
                      }`}
                    >
                      <p className="text-sm">{message.content}</p>
                      <p
                        className={`text-xs mt-1 ${
                          message.role === 'user'
                            ? 'text-brand-accent'
                            : 'text-gray-500'
                        }`}
                      >
                        {new Date(message.timestamp).toLocaleTimeString('zh-CN', {
                          hour: '2-digit',
                          minute: '2-digit',
                        })}
                      </p>
                    </div>
                  </div>
                ))
              )}
              {isLoading && (
                <div className="flex justify-start">
                  <div className="bg-gray-100 text-gray-900 px-3 py-2 rounded-lg rounded-bl-none">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-100"></div>
                      <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce delay-200"></div>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </div>

            {/* Input */}
            <form
              onSubmit={handleSendMessage}
              className="border-t border-gray-200 p-4 flex gap-2"
            >
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder="输入您的问题..."
                disabled={isLoading}
                className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-brand-primary focus:border-transparent outline-none disabled:bg-gray-100 text-sm"
              />
              <button
                type="submit"
                disabled={isLoading || !input.trim()}
                className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-opacity-90 disabled:opacity-50 transition-opacity font-medium text-sm"
              >
                发送
              </button>
            </form>
          </div>
        </div>
      )}
    </>
  );
}

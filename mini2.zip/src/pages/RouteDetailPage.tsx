import { useEffect } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useLocation } from 'wouter';
import { useAuthStore } from '../store/authStore';

interface RouteDetailPageProps {
  routeId: string;
}

export function RouteDetailPage({ routeId }: RouteDetailPageProps) {
  const { currentRoute, pois, contentModel, fetchPOIsByRoute, fetchRouteDetail, isLoading } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }

    if (!currentRoute || currentRoute.id !== routeId) {
      fetchRouteDetail(routeId);
      setLocation('/routes');
      return;
    }

    if (pois.length === 0) {
      fetchPOIsByRoute(routeId);
    }
  }, [user, currentRoute, routeId, pois.length, setLocation, fetchPOIsByRoute]);

  if (!currentRoute) {
    return (
      <div className="app-shell min-h-screen flex items-center justify-center">
        <p className="text-gray-500">加载中...</p>
      </div>
    );
  }

  return (
    <div className="app-shell min-h-screen pb-20">
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 p-4 border-b border-gray-200 flex items-center gap-3">
        <button
          onClick={() => setLocation('/routes')}
          className="text-brand-primary hover:text-brand-secondary transition-colors"
        >
          ←
        </button>
        <h1 className="text-xl font-bold text-gray-900 flex-1">{currentRoute.name}</h1>
      </div>

      <div className="p-4 space-y-4">
        {/* Route Overview */}
        <div className="glass-panel p-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">路线概览</h2>
          <p className="text-gray-700 mb-3">{currentRoute.description}</p>
          {contentModel?.summary && (
            <p className="text-gray-600 text-sm mb-3">{contentModel.summary}</p>
          )}
          <div className="grid grid-cols-3 gap-2 text-center text-sm">
            <div className="p-2 bg-brand-muted rounded">
              <div className="font-semibold text-brand-primary">{currentRoute.duration}</div>
              <div className="text-xs text-gray-600">分钟</div>
            </div>
            <div className="p-2 bg-brand-muted rounded">
              <div className="font-semibold text-brand-primary">{currentRoute.distance}</div>
              <div className="text-xs text-gray-600">公里</div>
            </div>
            <div className="p-2 bg-brand-muted rounded">
              <div className="font-semibold text-brand-primary">{currentRoute.poiCount}</div>
              <div className="text-xs text-gray-600">景点</div>
            </div>
          </div>
        </div>

        {contentModel?.media?.length > 0 && (
          <div className="glass-panel p-4">
            <h2 className="text-lg font-semibold text-gray-900 mb-3">媒体画廊</h2>
            <div className="grid grid-cols-2 gap-3">
              {contentModel.media.slice(0, 4).map((media: any) => (
                <div key={media.id} className="aspect-video rounded-lg bg-gray-100 overflow-hidden">
                  <img src={media.url} alt={media.caption || '媒体'} className="w-full h-full object-cover" />
                </div>
              ))}
            </div>
          </div>
        )}

        {/* POI List */}
        <div>
          <h2 className="text-lg font-semibold text-gray-900 mb-3">景点列表</h2>
          {isLoading ? (
            <div className="flex justify-center py-8">
              <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-brand-primary"></div>
            </div>
          ) : pois.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <p>暂无景点</p>
            </div>
          ) : (
            <div className="space-y-2">
              {pois.map((poi, index) => (
                <div
                  key={poi.id}
                  onClick={() => setLocation(`/route/${routeId}/poi/${poi.id}`)}
                  className="glass-panel p-3 cursor-pointer hover:shadow-lg transition-shadow flex items-start gap-3"
                >
                  <div className="flex-shrink-0 w-8 h-8 bg-brand-primary text-white rounded-full flex items-center justify-center text-sm font-semibold">
                    {index + 1}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-900">{poi.name}</h3>
                    <p className="text-sm text-gray-600 line-clamp-2">{poi.description}</p>
                  </div>
                  <div className="flex-shrink-0 text-brand-secondary">→</div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Start Button */}
        <button className="w-full py-3 bg-brand-primary text-white rounded-lg font-semibold hover:bg-opacity-90 transition-opacity">
          开始导览
        </button>
      </div>
    </div>
  );
}

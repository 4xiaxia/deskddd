import { useEffect } from 'react';
import { useRouteStore } from '../store/routeStore';
import { useLocation } from 'wouter';
import { useAuthStore } from '../store/authStore';
import { SectionLoading } from '../components/Loading';
import { EmptyState, EmptyStates } from '../components/EmptyState';

export function RoutesPage() {
  const { routes, fetchRoutes, isLoading, error, setCurrentRoute } = useRouteStore();
  const { user } = useAuthStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    fetchRoutes();
  }, [user, setLocation, fetchRoutes]);

  const handleSelectRoute = (routeId: string) => {
    const route = routes.find((r) => r.id === routeId);
    if (route) {
      setCurrentRoute(route);
      setLocation(`/route/${routeId}`);
    }
  };

  const handleRetry = () => {
    fetchRoutes();
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return '简单';
      case 'medium': return '中等';
      case 'hard': return '困难';
      default: return '未知';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="app-shell min-h-screen pb-20">
      {/* Header */}
      <div className="sticky top-0 bg-white bg-opacity-90 backdrop-blur-sm z-10 border-b border-gray-200">
        <div className="p-4">
          <div className="flex items-center justify-between mb-3">
            <button
              onClick={() => setLocation('/home')}
              className="text-brand-primary hover:text-brand-secondary transition-colors"
            >
              ← 返回首页
            </button>
            <div className="text-sm text-gray-500">导览路线</div>
          </div>
          <h1 className="text-2xl font-bold text-brand-primary mb-1">选择路线</h1>
          <p className="text-sm text-gray-600">欢迎，{user?.phone}</p>
        </div>
      </div>

      <div className="p-4 space-y-4">
        {isLoading ? (
          <SectionLoading text="正在加载路线..." />
        ) : error ? (
          <div className="py-12">
            {EmptyStates.networkError(handleRetry)}
            {error && (
              <div className="mt-4 p-3 bg-red-50 border border-red-200 rounded-lg">
                <p className="text-red-700 text-sm">{error}</p>
              </div>
            )}
          </div>
        ) : routes.length === 0 ? (
          <div className="py-12">
            {EmptyStates.noRoutes(
              <button
                onClick={handleRetry}
                className="px-4 py-2 bg-brand-primary text-white rounded-lg hover:bg-opacity-90 transition-opacity"
              >
                重新加载
              </button>
            )}
          </div>
        ) : (
          <>
            {/* 统计信息 */}
            <div className="grid grid-cols-3 gap-3 mb-6">
              <div className="glass-panel p-3 text-center">
                <div className="text-2xl font-bold text-brand-primary">{routes.length}</div>
                <div className="text-xs text-gray-600">可选路线</div>
              </div>
              <div className="glass-panel p-3 text-center">
                <div className="text-2xl font-bold text-brand-primary">
                  {routes.reduce((total, route) => total + route.poiCount, 0)}
                </div>
                <div className="text-xs text-gray-600">历史景点</div>
              </div>
              <div className="glass-panel p-3 text-center">
                <div className="text-2xl font-bold text-brand-primary">
                  {Math.round(routes.reduce((total, route) => total + route.duration, 0) / routes.length) || 0}
                </div>
                <div className="text-xs text-gray-600">平均时长(分钟)</div>
              </div>
            </div>

            {/* 路线列表 */}
            {routes.map((route, index) => (
              <div
                key={route.id}
                onClick={() => handleSelectRoute(route.id)}
                className="glass-panel p-4 cursor-pointer hover:shadow-lg transition-all transform hover:scale-[1.01]"
              >
                <div className="flex items-start justify-between mb-3">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 bg-brand-primary text-white rounded-full flex items-center justify-center text-sm font-bold">
                      {index + 1}
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900">{route.name}</h3>
                  </div>
                  <span className={`px-3 py-1 text-xs rounded-full font-medium ${getDifficultyColor(route.difficulty)}`}>
                    {getDifficultyLabel(route.difficulty)}
                  </span>
                </div>
                
                <p className="text-gray-600 mb-4 leading-relaxed">{route.description}</p>
                
                <div className="grid grid-cols-3 gap-3 mb-4">
                  <div className="text-center">
                    <div className="text-sm font-semibold text-brand-primary">{route.duration}</div>
                    <div className="text-xs text-gray-500">分钟</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-brand-primary">{route.distance}</div>
                    <div className="text-xs text-gray-500">公里</div>
                  </div>
                  <div className="text-center">
                    <div className="text-sm font-semibold text-brand-primary">{route.poiCount}</div>
                    <div className="text-xs text-gray-500">景点</div>
                  </div>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                  <div className="text-xs text-gray-500">
                    难度：{getDifficultyLabel(route.difficulty)}
                  </div>
                  <div className="flex items-center gap-1 text-brand-primary text-sm font-medium">
                    开始导览
                    <span className="ml-1">→</span>
                  </div>
                </div>
              </div>
            ))}
          </>
        )}
      </div>
    </div>
  );
}

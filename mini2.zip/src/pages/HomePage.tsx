import { useEffect } from 'react';
import { useAuthStore } from '../store/authStore';
import { useLocation } from 'wouter';
import { useRouteStore } from '../store/routeStore';

export function HomePage() {
  const { user } = useAuthStore();
  const { routes, fetchRoutes, setCurrentRoute } = useRouteStore();
  const [, setLocation] = useLocation();

  useEffect(() => {
    if (!user) {
      setLocation('/login');
      return;
    }
    fetchRoutes();
  }, [user, setLocation, fetchRoutes]);

  const handleSelectRoute = (routeId: string) => {
    const route = routes.find((r) => r.id === routeId);
    if (route) {
      setCurrentRoute(route);
      setLocation(`/route/${routeId}`);
    }
  };

  const getDifficultyLabel = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return '简单';
      case 'medium': return '中等';
      case 'hard': return '困难';
      default: return '未知';
    }
  };

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'easy': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="app-shell min-h-screen pb-20">
      {/* Hero Section */}
      <div className="relative">
        <div className="h-64 bg-gradient-to-br from-brand-primary to-brand-secondary flex items-center justify-center">
          <div className="text-center text-white">
            <h1 className="text-4xl font-bold mb-2">东里村</h1>
            <p className="text-xl opacity-90">AI智能导览系统</p>
            <p className="text-sm opacity-75 mt-2">发现历史遗迹，体验传统文化</p>
          </div>
        </div>
      </div>

      {/* Welcome Section */}
      <div className="p-4">
        <div className="glass-panel p-4 mb-4">
          <h2 className="text-lg font-semibold text-gray-900 mb-2">欢迎，{user?.phone}</h2>
          <p className="text-gray-600 text-sm">选择一条路线开始您的东里村之旅，与AI导游一起探索历史文化。</p>
        </div>

        {/* Quick Stats */}
        <div className="grid grid-cols-3 gap-3 mb-6">
          <div className="glass-panel p-3 text-center">
            <div className="text-2xl font-bold text-brand-primary">{routes.length}</div>
            <div className="text-xs text-gray-600">导览路线</div>
          </div>
          <div className="glass-panel p-3 text-center">
            <div className="text-2xl font-bold text-brand-primary">
              {routes.reduce((total, route) => total + route.poiCount, 0)}
            </div>
            <div className="text-xs text-gray-600">历史景点</div>
          </div>
          <div className="glass-panel p-3 text-center">
            <div className="text-2xl font-bold text-brand-primary">AI</div>
            <div className="text-xs text-gray-600">智能导游</div>
          </div>
        </div>

        {/* Popular Routes */}
        <div className="mb-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">热门路线</h3>
          <div className="space-y-3">
            {routes.slice(0, 3).map((route) => (
              <div
                key={route.id}
                onClick={() => handleSelectRoute(route.id)}
                className="glass-panel p-4 cursor-pointer hover:shadow-lg transition-all transform hover:scale-[1.02]"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 text-sm">{route.name}</h4>
                    <p className="text-xs text-gray-600 mt-1 line-clamp-2">{route.description}</p>
                  </div>
                  <span className={`px-2 py-1 text-xs rounded-full ${getDifficultyColor(route.difficulty)}`}>
                    {getDifficultyLabel(route.difficulty)}
                  </span>
                </div>
                <div className="flex items-center justify-between mt-3">
                  <div className="flex gap-3 text-xs text-gray-500">
                    <span>⏱ {route.duration}分钟</span>
                    <span>📍 {route.distance}km</span>
                  </div>
                  <span className="text-brand-primary text-xs font-medium">开始导览 →</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* All Routes */}
        {routes.length > 3 && (
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-lg font-semibold text-gray-900">全部路线</h3>
              <button
                onClick={() => setLocation('/routes')}
                className="text-sm text-brand-primary hover:text-brand-secondary"
              >
                查看全部 →
              </button>
            </div>
            <div className="grid grid-cols-1 gap-3">
              {routes.slice(3).map((route) => (
                <div
                  key={route.id}
                  onClick={() => handleSelectRoute(route.id)}
                  className="glass-panel p-3 cursor-pointer hover:shadow-md transition-all"
                >
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900 text-sm">{route.name}</h4>
                      <p className="text-xs text-gray-600 mt-1">{route.duration}分钟 · {route.distance}km</p>
                    </div>
                    <span className={`px-2 py-1 text-xs rounded ${getDifficultyColor(route.difficulty)}`}>
                      {getDifficultyLabel(route.difficulty)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Features */}
        <div className="mt-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">服务特色</h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="glass-panel p-3">
              <div className="text-center">
                <div className="text-2xl mb-2">🤖</div>
                <h4 className="font-medium text-sm text-gray-900">AI智能导游</h4>
                <p className="text-xs text-gray-600 mt-1">24小时在线解答</p>
              </div>
            </div>
            <div className="glass-panel p-3">
              <div className="text-center">
                <div className="text-2xl mb-2">🗺️</div>
                <h4 className="font-medium text-sm text-gray-900">精准定位</h4>
                <p className="text-xs text-gray-600 mt-1">实时导航导览</p>
              </div>
            </div>
            <div className="glass-panel p-3">
              <div className="text-center">
                <div className="text-2xl mb-2">📱</div>
                <h4 className="font-medium text-sm text-gray-900">便携体验</h4>
                <p className="text-xs text-gray-600 mt-1">随时随地探索</p>
              </div>
            </div>
            <div className="glass-panel p-3">
              <div className="text-center">
                <div className="text-2xl mb-2">🎧</div>
                <h4 className="font-medium text-sm text-gray-900">语音导览</h4>
                <p className="text-xs text-gray-600 mt-1">专业讲解服务</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
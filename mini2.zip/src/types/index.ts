// User types
export interface User {
  id: string;
  phone: string;
  name?: string;
  avatar?: string;
  createdAt: string;
}

// Route/Theme types
export interface Route {
  id: string;
  name: string;
  description: string;
  thumbnail?: string;
  duration: number; // in minutes
  distance: number; // in km
  poiCount: number;
  difficulty: 'easy' | 'medium' | 'hard';
  contentModelId?: string;
}

// Point of Interest types
export interface POI {
  id: string;
  routeId: string;
  name: string;
  description: string;
  latitude: number;
  longitude: number;
  images?: string[];
  audioUrl?: string;
  order: number;
  contentModelId?: string;
}

// AI Agent types
export interface AIMessage {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: string;
  type?: 'text' | 'image' | 'voice';
}

export interface AIConversation {
  id: string;
  messages: AIMessage[];
  context?: {
    currentRoute?: string;
    currentPOI?: string;
    userLocation?: {
      latitude: number;
      longitude: number;
    };
  };
}

// Content upload types
export interface ContentUpload {
  id: string;
  userId: string;
  type: 'image' | 'audio' | 'text';
  url: string;
  metadata?: Record<string, any>;
  createdAt: string;
}

// Visitor record types
export interface VisitorRecord {
  id: string;
  userId: string;
  routeId: string;
  poiId?: string;
  timestamp: string;
  duration?: number;
}

// Auth types
export interface LoginRequest {
  phone: string;
  code?: string;
}

export interface AuthResponse {
  token: string;
  user: User;
}

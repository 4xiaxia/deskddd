import type { Route, POI } from '../types';

// 模拟路线数据
export const mockRoutes: Route[] = [
  {
    id: 'route_1',
    name: '红色文化革命之旅',
    description: '重温东里村革命历史，参观永春辛亥革命纪念馆，感受郑玉指等革命先烈的爱国情怀和奉献精神。',
    duration: 120,
    distance: 1.5,
    poiCount: 2,
    difficulty: 'easy',
    contentModelId: 'model_1'
  },
  {
    id: 'route_2',
    name: '乡村基础设施与休闲游',
    description: '游览东里村现代化基础设施，体验油桐花海的自然美景，感受乡村振兴的发展成就。',
    duration: 180,
    distance: 3.8,
    poiCount: 5,
    difficulty: 'medium',
    contentModelId: 'model_2'
  },
  {
    id: 'route_3',
    name: '民俗体验与美食探索',
    description: '体验东里村传统民俗文化，品尝地道农家美食，感受闽南侨乡的独特魅力。',
    duration: 150,
    distance: 2.2,
    poiCount: 3,
    difficulty: 'medium',
    contentModelId: 'model_3'
  }
];

// 模拟景点数据
export const mockPOIs: Record<string, POI[]> = {
  route_1: [
    {
      id: 'poi_donglired_xinhaijinianguan001',
      routeId: 'route_1',
      name: '永春辛亥革命纪念馆',
      description: '永春为闽南著名侨乡，辛亥革命时期，有大批旅居海外的永春籍华侨和留学生，感愤清廷腐败，谋求民族振兴，出资出力支持民主革命。为了缅怀先烈，教育后人，永春县归国华侨联合会、中共永春县仙夹镇委员会永春县仙夹镇人民政府在郑玉指的家乡仙夹镇东里村兴建"永春辛亥革命纪念馆"。',
      latitude: 25.23411225,
      longitude: 118.20524049,
      images: [],
      order: 1,
      contentModelId: 'model_1'
    },
    {
      id: 'poi_donglired_jingyizhuang001',
      routeId: 'route_1',
      name: '旌义状石碑',
      description: '宣统三年（1911年），广州"黄花岗起义"起义前夕，由于郑玉指等积极支持革命，孙中山为便于筹款购买和运送武器，将起义筹备会的地点选择在福建侨胞最集中的槟榔屿，得到了当地华侨的积极支持。1912年中华民国成立，孙中山就任临时大总统，对支持革命的有功人士论功嘉奖，3月，孙中山为表彰郑玉指对革命的贡献，特颁发旌义状。此旌义状于民国年间被刻于石碑，立于郑玉指的家乡—东里村。',
      latitude: 25.23566419,
      longitude: 118.20423698,
      images: [],
      order: 2,
      contentModelId: 'model_1'
    }
  ],
  route_2: [
    {
      id: 'poi_basic_ykfwzx',
      routeId: 'route_2',
      name: '东里村游客服务中心',
      description: '展示东里村及全镇特色农副产品和传统文化，介绍旅游景点，为游客提供一个特色餐饮、休闲购物的好场所，助推东里村乡村旅游发展。',
      latitude: 25.23773823,
      longitude: 118.20442982,
      images: [],
      order: 1,
      contentModelId: 'model_2'
    },
    {
      id: 'poi_basic_xcfzzx',
      routeId: 'route_2',
      name: '东里村乡村发展中心',
      description: '投入200万元建成东里村乡村发展中心，设置了乡村大舞台、餐饮、民宿、电商平台、农产品展示馆、黄文中油画工作室、乡贤郑金贵团队工作室、郑傅安油画工作室等，开展了黄文中潘登油画摄影对话展等活动，并与泉州国旅接洽，优化乡村旅游和研学的配套设施，打造研学基地。',
      latitude: 25.23525132,
      longitude: 118.20918303,
      images: [],
      order: 2,
      contentModelId: 'model_2'
    },
    {
      id: 'poi_basic_ythms',
      routeId: 'route_2',
      name: '油桐花民宿',
      description: '建筑面积700平方，设有10间民宿，1个书吧，开放式厨房配备1个大型开放式餐厅、3个独立餐厅，1个大型会客厅，2个休闲区，1个营业吧台，并辅以油桐花特色手绘、夜景、音乐等配套。项目投入运营后，将为游客提供完善的旅游配套服务。',
      latitude: 25.23843909,
      longitude: 118.20460919,
      images: [],
      order: 3,
      contentModelId: 'model_2'
    },
    {
      id: 'poi_basic_ythh',
      routeId: 'route_2',
      name: '油桐花海',
      description: '每年的三月底四月初，仙夹镇东里村水库边上成片的油桐树如期开花，一树树繁花白如雪，布满枝头，成为绿色山间的独特风景。走进仙夹镇东里村，沿着水库边蜿蜒的公路走，映入眼帘的便是公路两侧浪漫似雪的油桐花。远远望去，成片的油桐花仿佛飞雪一般落在树梢，缀在枝丫，翠绿莹白，交相映衬。',
      latitude: 25.23779533,
      longitude: 118.20362427,
      images: [],
      order: 4,
      contentModelId: 'model_2'
    }
  ],
  route_3: [
    {
      id: 'poi_agri_specialties',
      routeId: 'route_3',
      name: '东里村农特产品展示',
      description: '东里村现有芦柑、百香果、铁观音茶叶等种植区域1200多亩，羊、牛、猪、蜂蜜等养殖业也十分兴旺繁荣。饮食天然养生，有芥菜咸饭、芥菜鸭汤、屁股面等地方特色农家饭菜，有纯天然的牛、羊养殖基地，有土鸡、土鸭、竹鼠等优质无公害食材。',
      latitude: 25.23450000,
      longitude: 118.20500000,
      images: [],
      order: 1,
      contentModelId: 'model_3'
    }
  ]
};

// 模拟内容模型数据
export const mockContentModel = {
  model_1: {
    id: 'model_1',
    summary: '红色文化革命之旅带您重温东里村的革命历史。参观永春辛亥革命纪念馆，了解郑玉指等革命先烈如何感愤清廷腐败，谋求民族振兴，出资出力支持民主革命。游览旌义状石碑，聆听孙中山先生为表彰郑玉指对革命的贡献而颁发的珍贵文物故事。感受闽南侨乡儿女的爱国情怀和奉献精神，体验东里村深厚的红色文化底蕴。',
    media: [
      {
        id: 'media_1',
        url: '/img/pic/xinhai Memorial Hall.jpg',
        caption: '永春辛亥革命纪念馆'
      },
      {
        id: 'media_2',
        url: '/img/pic/jingyi Monument.jpg',
        caption: '旌义状石碑'
      }
    ]
  },
  model_2: {
    id: 'model_2',
    summary: '乡村基础设施与休闲游让您感受东里村现代化发展成就。参观游客服务中心了解当地特色农产品，游览乡村发展中心欣赏艺术工作室，体验油桐花民宿的温馨服务。每年三四月份还可欣赏成片油桐花如雪花般绽放的浪漫美景。感受乡村振兴带来的美好变化，体验现代与传统交融的乡村新貌。',
    media: []
  },
  model_3: {
    id: 'model_3',
    summary: '民俗体验与美食探索带您深入感受东里村的传统文化魅力。品尝地道农家美食，包括芥菜咸饭、芥菜鸭汤、屁股面等特色饭菜，体验纯天然的牛羊养殖基地和土鸡土鸭。了解1200多亩的芦柑、百香果、铁观音茶叶种植区和蜜蜂养殖业。感受闽南侨乡的饮食文化和农业传统，体验乡村生活的纯朴与美好。',
    media: []
  }
};

// 获取路线详情
export const getRouteDetail = (routeId: string) => {
  const route = mockRoutes.find(r => r.id === routeId);
  if (!route) return null;
  
  return {
    ...route,
    pois: mockPOIs[routeId] || []
  };
};

// 获取景点详情
export const getPOIDetail = (poiId: string) => {
  for (const routePOIs of Object.values(mockPOIs)) {
    const poi = routePOIs.find(p => p.id === poiId);
    if (poi) return poi;
  }
  return null;
};

// 获取内容模型
export const getContentModel = (modelId: string) => {
  return mockContentModel[modelId as keyof typeof mockContentModel] || null;
};